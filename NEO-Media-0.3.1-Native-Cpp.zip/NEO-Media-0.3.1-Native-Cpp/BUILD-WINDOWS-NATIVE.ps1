$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Msys = 'C:\msys64\usr\bin\bash.exe'
if (!(Test-Path $Msys)) {
  throw 'MSYS2 não encontrado em C:\msys64. Instale o MSYS2 uma vez e execute este script novamente.'
}
$UnixRoot = ($Root -replace '\\','/') -replace '^([A-Za-z]):','/$1'
$UnixRoot = $UnixRoot.Substring(0,2).ToLower() + $UnixRoot.Substring(2)
$cmd = @'
set -euo pipefail
pacman -Sy --needed --noconfirm mingw-w64-ucrt-x86_64-toolchain mingw-w64-ucrt-x86_64-cmake mingw-w64-ucrt-x86_64-ninja mingw-w64-ucrt-x86_64-pkgconf mingw-w64-ucrt-x86_64-ffmpeg mingw-w64-ucrt-x86_64-SDL2 mingw-w64-ucrt-x86_64-nsis
export PATH=/ucrt64/bin:/usr/bin:$PATH
cd '__ROOT__'
rm -rf build-native dist-native
cmake -S codigo-fonte -B build-native -G Ninja -DCMAKE_BUILD_TYPE=Release -DNEO_VIDEO_EXPERIMENTAL_HW=OFF -DNEO_VIDEO_ENABLE_ONNX=OFF
cmake --build build-native --parallel
mkdir -p dist-native/bin dist-native/licencas dist-native/musicas-incluidas
cp build-native/neo_media/NEO-Media.exe dist-native/
cp build-native/neo_media/NEO-Repair.exe dist-native/
cp build-native/neo_video/neo_video.exe dist-native/bin/
cp build-native/neo_video/neo_audio.exe dist-native/bin/
cp musicas-incluidas/Ravens-Over-the-Plains.mp3 dist-native/musicas-incluidas/ 2>/dev/null || true
cp -r licencas/* dist-native/licencas/ 2>/dev/null || true
for exe in dist-native/NEO-Media.exe dist-native/NEO-Repair.exe; do
  ldd "$exe" | awk '/\/ucrt64\// {print $3}' | while read dll; do [ -f "$dll" ] && cp -u "$dll" dist-native/ || true; done
done
for exe in dist-native/bin/neo_video.exe dist-native/bin/neo_audio.exe; do
  ldd "$exe" | awk '/\/ucrt64\// {print $3}' | while read dll; do [ -f "$dll" ] && cp -u "$dll" dist-native/bin/ || true; done
done
cp /ucrt64/bin/ffmpeg.exe /ucrt64/bin/ffprobe.exe dist-native/bin/
for exe in /ucrt64/bin/ffmpeg.exe /ucrt64/bin/ffprobe.exe; do
  ldd "$exe" | awk '/\/ucrt64\// {print $3}' | while read dll; do [ -f "$dll" ] && cp -u "$dll" dist-native/bin/ || true; done
done
if find dist-native -type f \( -iname '*.py' -o -iname 'python*.dll' -o -iname 'python*.exe' -o -iname '*.pyd' \) | grep -q .; then
  echo 'ERRO: Python vazou para o pacote nativo.' >&2; exit 1
fi
'@.Replace('__ROOT__', $UnixRoot)
& $Msys -lc $cmd
if ($LASTEXITCODE -ne 0) { throw "Build C++ falhou com código $LASTEXITCODE" }
$Makensis = @('C:\msys64\ucrt64\bin\makensis.exe','C:\msys64\usr\bin\makensis.exe') | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($Makensis) {
  Push-Location "$Root\codigo-fonte"
  & $Makensis installer.nsi
  if ($LASTEXITCODE -eq 0) { Move-Item -Force '.\NEO-Media-Setup-0.3.1.exe' "$Root\NEO-Media-Setup-0.3.1.exe" }
  Pop-Location
}
Write-Host "Build nativo concluído em: $Root\dist-native" -ForegroundColor Green
if (Test-Path "$Root\NEO-Media-Setup-0.3.1.exe") { Write-Host "Instalador: $Root\NEO-Media-Setup-0.3.1.exe" -ForegroundColor Green }
Write-Host 'O runtime final não contém Python, Tkinter, CFFI ou sounddevice.' -ForegroundColor Green
