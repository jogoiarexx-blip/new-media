NEO Media 0.3.1 — Native C++ / Win64
=====================================

Esta árvore é a migração do aplicativo para runtime 100% C++.

O que mudou
-----------
- A interface Tkinter/Python foi substituída por uma interface Win32 nativa em C++17.
- O launcher que abria runtime\pythonw.exe foi eliminado do projeto nativo.
- O motor de vídeo continua em C++/FFmpeg/SDL2 e agora faz parte do build único.
- Foi criado neo_audio.exe em C++ para músicas, rádios e áudio local, eliminando sounddevice/Python.
- Comunicação NEO Media <-> motores usa pipes nativos do Windows (CreateProcess/CreatePipe).
- Fila, favoritos, M3U/M3U8, varredura de pastas, links, rádios online, seek, volume, mute,
  repetição, aleatório, tela cheia, melhoria de imagem e legenda SRT foram migrados para C++.
- Estado do usuário é salvo em %LOCALAPPDATA%\NEO Media\state-native.txt, sem módulo Python/JSON.
- NEO-Repair.exe é um reparador C++ nativo do FFmpeg com download, SHA-256, validação PE x64,
  backup e rollback.
- Os 12 módulos C++ que existiam no repositório mas não entravam em nenhum target agora são
  compilados junto com neo_video por padrão para evitar código abandonado sem validação.
- O instalador NSIS foi alterado para empacotar somente o runtime nativo e não inclui Python.

Estrutura principal
-------------------
codigo-fonte\neo_media\       shell desktop Win32 C++
codigo-fonte\neo_video\       motores multimídia C++
  src\main.cpp               neo_video.exe
  src\audio_main.cpp         neo_audio.exe
codigo-fonte\CMakeLists.txt   build da suíte inteira
BUILD-WINDOWS-NATIVE.ps1      build local Windows/MSYS2
.github\workflows\            build automático Windows x64

Build local
-----------
1. Instale MSYS2 em C:\msys64.
2. Clique com o botão direito em BUILD-WINDOWS-NATIVE.ps1 e execute com PowerShell.
3. O script instala as dependências de compilação no MSYS2, compila C++ Release e cria:
   dist-native\NEO-Media.exe
   dist-native\NEO-Repair.exe
   dist-native\bin\neo_video.exe
   dist-native\bin\neo_audio.exe
   dist-native\bin\ffmpeg.exe / ffprobe.exe + DLLs necessárias
4. O diretório dist-native é portátil e não depende de Python.

Observação importante
---------------------
Este pacote contém o código-fonte migrado. O ambiente Linux usado para preparar esta entrega não
possui toolchain Win64/MSVC/MinGW instalado, portanto NEO-Media.exe e neo_audio.exe novos não foram
compilados aqui. O workflow e o script de build estão prontos para produzir os executáveis no Windows.
