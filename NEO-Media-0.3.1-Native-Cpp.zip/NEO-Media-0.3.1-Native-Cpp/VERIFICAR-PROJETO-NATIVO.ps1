$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$bad = Get-ChildItem $Root -Recurse -File | Where-Object {
  $_.Extension -in '.py','.pyc','.pyd' -or $_.Name -match '^python(w)?\.exe$|^python\d+.*\.dll$'
}
if($bad){
  $bad | ForEach-Object { Write-Host "Python encontrado: $($_.FullName)" -ForegroundColor Red }
  throw 'A validação nativa falhou.'
}
$cpp = Get-ChildItem "$Root\codigo-fonte" -Recurse -File | Where-Object {$_.Extension -in '.cpp','.hpp','.h'}
Write-Host "OK: nenhum runtime/arquivo Python no projeto nativo." -ForegroundColor Green
Write-Host "Arquivos C/C++: $($cpp.Count)" -ForegroundColor Green
