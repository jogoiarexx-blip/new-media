Unicode true
!include "MUI2.nsh"
Name "NEO Media 0.3.1"
OutFile "NEO-Media-Setup-0.3.1.exe"
InstallDir "$LOCALAPPDATA\Programs\NEOMedia"
RequestExecutionLevel user
SetCompressor /SOLID lzma
SetCompressorDictSize 32
!define MUI_ABORTWARNING
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "PortugueseBR"
Function .onInit
System::Call 'kernel32::OpenMutexW(i 0x100000, i 0, w "Local\NEOMediaNativeInstance") p.r0'
StrCmp $0 0 done
System::Call 'kernel32::CloseHandle(p r0)'
MessageBox MB_OK "Feche o NEO Media antes de instalar ou atualizar."
Abort
done:
FunctionEnd
Section "NEO Media"
SetOutPath "$INSTDIR\versions\0.3.1"
File /r "..\dist-native\*"
CreateDirectory "$SMPROGRAMS\NEO Media"
CreateShortcut "$SMPROGRAMS\NEO Media\NEO Media.lnk" "$INSTDIR\versions\0.3.1\NEO-Media.exe"
CreateShortcut "$SMPROGRAMS\NEO Media\Reparar FFmpeg.lnk" "$INSTDIR\versions\0.3.1\NEO-Repair.exe"
CreateShortcut "$DESKTOP\NEO Media.lnk" "$INSTDIR\versions\0.3.1\NEO-Media.exe"
WriteUninstaller "$INSTDIR\Desinstalar.exe"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NEOMedia" "DisplayName" "NEO Media"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NEOMedia" "DisplayVersion" "0.3.1"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NEOMedia" "UninstallString" '$\"$INSTDIR\Desinstalar.exe$\"'
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NEOMedia" "InstallLocation" "$INSTDIR"
WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NEOMedia" "NoModify" 1
SectionEnd
Section "Uninstall"
Delete "$DESKTOP\NEO Media.lnk"
RMDir /r "$SMPROGRAMS\NEO Media"
RMDir /r "$INSTDIR\versions\0.3.1"
Delete "$INSTDIR\Desinstalar.exe"
DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NEOMedia"
RMDir "$INSTDIR\versions"
RMDir "$INSTDIR"
SectionEnd
