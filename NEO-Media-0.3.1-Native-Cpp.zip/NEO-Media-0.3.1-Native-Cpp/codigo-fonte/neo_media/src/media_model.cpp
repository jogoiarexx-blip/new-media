#include "media_model.hpp"
#include "utf.hpp"
#include <algorithm>
#include <cwctype>
#include <fstream>
#include <set>
#include <sstream>

static std::wstring lower(std::wstring s){ for(auto& c:s)c=static_cast<wchar_t>(std::towlower(c)); return s; }

bool isRemote(const std::wstring& s){
    auto v=lower(s); return v.rfind(L"http://",0)==0||v.rfind(L"https://",0)==0||v.rfind(L"rtsp://",0)==0||v.rfind(L"rtmp://",0)==0||v.rfind(L"mms://",0)==0||v.rfind(L"udp://",0)==0||v.rfind(L"rtp://",0)==0;
}
bool isVideoSource(const std::wstring& s){
    std::filesystem::path p(s); auto ext=lower(p.extension().wstring());
    static const std::set<std::wstring> video={L".mp4",L".mkv",L".avi",L".mov",L".webm",L".wmv",L".flv",L".mpeg",L".mpg",L".m4v",L".ts",L".mts",L".m2ts",L".vob",L".ogv",L".3gp",L".rm",L".rmvb",L".mxf",L".divx"};
    return video.count(ext)!=0;
}
std::wstring titleFromSource(const std::wstring& s){
    if(isRemote(s)) return s;
    std::filesystem::path p(s); auto stem=p.stem().wstring(); return stem.empty()?p.filename().wstring():stem;
}
std::vector<MediaItem> scanFolder(const std::filesystem::path& root){
    static const std::set<std::wstring> exts={L".mp3",L".flac",L".wav",L".wave",L".aac",L".m4a",L".m4b",L".ogg",L".oga",L".opus",L".wma",L".aiff",L".aif",L".ape",L".ac3",L".dts",L".amr",L".alac",L".au",L".mid",L".midi",L".mod",L".xm",L".it",L".s3m",L".mp4",L".mkv",L".avi",L".mov",L".webm",L".wmv",L".flv",L".mpeg",L".mpg",L".m4v",L".ts",L".mts",L".m2ts",L".vob",L".ogv",L".3gp",L".rm",L".rmvb",L".divx",L".mxf"};
    std::vector<MediaItem> out; std::error_code ec;
    std::filesystem::recursive_directory_iterator it(root,std::filesystem::directory_options::skip_permission_denied,ec), end;
    for(;it!=end;it.increment(ec)){
        if(ec){ec.clear();continue;} if(!it->is_regular_file(ec))continue;
        auto ext=lower(it->path().extension().wstring()); if(!exts.count(ext))continue;
        auto path=std::filesystem::absolute(it->path(),ec).wstring(); if(!ec)out.push_back({titleFromSource(path),path});
    }
    std::sort(out.begin(),out.end(),[](const auto&a,const auto&b){return lower(a.title)<lower(b.title);}); return out;
}

static std::string readAll(const std::filesystem::path& p){std::ifstream f(p,std::ios::binary);return std::string(std::istreambuf_iterator<char>(f),{});} 
std::vector<MediaItem> readM3u(const std::filesystem::path& file){
    std::vector<MediaItem> out; auto bytes=readAll(file); if(bytes.size()>=3&&(unsigned char)bytes[0]==0xEF&&(unsigned char)bytes[1]==0xBB&&(unsigned char)bytes[2]==0xBF)bytes.erase(0,3);
    if(bytes.find("#EXT-X-")!=std::string::npos){auto s=file.wstring();return {{titleFromSource(s),s}};}
    std::istringstream in(bytes);std::string line,pending; while(std::getline(in,line)){
        if(!line.empty()&&line.back()=='\r')line.pop_back(); if(line.rfind("#EXTINF:",0)==0){auto c=line.find(',');pending=c==std::string::npos?"":line.substr(c+1);continue;} if(line.empty()||line[0]=='#')continue;
        std::wstring src=wide(line); if(!isRemote(src)){std::filesystem::path p(src);if(p.is_relative())p=file.parent_path()/p;std::error_code ec;src=std::filesystem::absolute(p,ec).wstring();}
        out.push_back({pending.empty()?titleFromSource(src):wide(pending),src});pending.clear();
    } return out;
}
bool writeM3u(const std::filesystem::path& file,const std::vector<MediaItem>& items){
    std::ofstream o(file,std::ios::binary);if(!o)return false;o<<"#EXTM3U\n";for(auto&i:items){auto t=utf8(i.title),s=utf8(i.source);std::replace(t.begin(),t.end(),'\n',' ');std::replace(t.begin(),t.end(),'\r',' ');if(s.find('\n')!=std::string::npos||s.find('\r')!=std::string::npos)continue;o<<"#EXTINF:-1,"<<t<<"\n"<<s<<"\n";}return static_cast<bool>(o);
}
std::wstring escapeState(const std::wstring& s){std::wstring o;for(wchar_t c:s){if(c==L'\\')o+=L"\\\\";else if(c==L'\t')o+=L"\\t";else if(c==L'\n')o+=L"\\n";else if(c==L'\r'){}else o+=c;}return o;}
std::wstring unescapeState(const std::wstring& s){std::wstring o;for(size_t i=0;i<s.size();++i){if(s[i]==L'\\'&&i+1<s.size()){wchar_t n=s[++i];if(n==L't')o+=L'\t';else if(n==L'n')o+=L'\n';else o+=n;}else o+=s[i];}return o;}
