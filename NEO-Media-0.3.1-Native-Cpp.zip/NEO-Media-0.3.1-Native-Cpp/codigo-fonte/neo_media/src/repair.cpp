#define UNICODE
#define _UNICODE
#include <windows.h>
#include <winhttp.h>
#include <bcrypt.h>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>
#pragma comment(lib,"winhttp.lib")
#pragma comment(lib,"bcrypt.lib")

namespace fs=std::filesystem;
static constexpr wchar_t URL[]=L"https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2026-09-11-13-20/ffmpeg-N-126497-g5b614efc7e-win64-lgpl-shared.zip";
static constexpr char SHA256_EXPECTED[]="9d4c847189e86276663dcd5a8991cb61e58a53a051e3fa9253f470a62ff639a6";

std::wstring root(){wchar_t b[32768];DWORD n=GetModuleFileNameW(nullptr,b,32768);return fs::path(std::wstring(b,n)).parent_path().wstring();}
void fail(const std::wstring&s){MessageBoxW(nullptr,s.c_str(),L"NEO Media • Reparar FFmpeg",MB_ICONERROR);}

bool download(const std::wstring& url,const fs::path& out){
    URL_COMPONENTSW u{};u.dwStructSize=sizeof(u);wchar_t host[512],path[4096];u.lpszHostName=host;u.dwHostNameLength=512;u.lpszUrlPath=path;u.dwUrlPathLength=4096;if(!WinHttpCrackUrl(url.c_str(),0,0,&u))return false;
    HINTERNET ses=WinHttpOpen(L"NEO-Media-Repair/0.3.1",WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0);if(!ses)return false;
    HINTERNET con=WinHttpConnect(ses,std::wstring(host,u.dwHostNameLength).c_str(),u.nPort,0);if(!con){WinHttpCloseHandle(ses);return false;}
    std::wstring target(path,u.dwUrlPathLength);if(u.dwExtraInfoLength)target.append(u.lpszExtraInfo,u.dwExtraInfoLength);
    HINTERNET req=WinHttpOpenRequest(con,L"GET",target.c_str(),nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,u.nScheme==INTERNET_SCHEME_HTTPS?WINHTTP_FLAG_SECURE:0);if(!req){WinHttpCloseHandle(con);WinHttpCloseHandle(ses);return false;}
    DWORD redirect=WINHTTP_OPTION_REDIRECT_POLICY_ALWAYS;WinHttpSetOption(req,WINHTTP_OPTION_REDIRECT_POLICY,&redirect,sizeof(redirect));DWORD t=30000;WinHttpSetTimeouts(req,t,t,t,t);
    bool ok=WinHttpSendRequest(req,WINHTTP_NO_ADDITIONAL_HEADERS,0,WINHTTP_NO_REQUEST_DATA,0,0,0)&&WinHttpReceiveResponse(req,nullptr);std::ofstream f(out,std::ios::binary|std::ios::trunc);if(ok&&f){for(;;){DWORD n=0;if(!WinHttpQueryDataAvailable(req,&n)||!n)break;std::vector<char>b(n);DWORD got=0;if(!WinHttpReadData(req,b.data(),n,&got)){ok=false;break;}f.write(b.data(),got);if(!f){ok=false;break;}}}else ok=false;
    f.close();WinHttpCloseHandle(req);WinHttpCloseHandle(con);WinHttpCloseHandle(ses);return ok&&fs::exists(out)&&fs::file_size(out)>50'000'000;
}

std::string sha256(const fs::path& p){
    BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;DWORD objLen=0,cb=0,hashLen=0;if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0))return {};
    BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,(PUCHAR)&objLen,sizeof(objLen),&cb,0);BCryptGetProperty(alg,BCRYPT_HASH_LENGTH,(PUCHAR)&hashLen,sizeof(hashLen),&cb,0);std::vector<UCHAR>obj(objLen),digest(hashLen);if(BCryptCreateHash(alg,&hash,obj.data(),objLen,nullptr,0,0)){BCryptCloseAlgorithmProvider(alg,0);return {};}
    std::ifstream f(p,std::ios::binary);std::vector<UCHAR>b(1024*1024);while(f){f.read((char*)b.data(),b.size());auto n=f.gcount();if(n>0)BCryptHashData(hash,b.data(),(ULONG)n,0);}BCryptFinishHash(hash,digest.data(),hashLen,0);BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(alg,0);std::ostringstream o;for(auto x:digest)o<<std::hex<<std::setw(2)<<std::setfill('0')<<(int)x;return o.str();
}

bool run(const std::wstring& cmd,const fs::path& cwd){STARTUPINFOW si{};si.cb=sizeof(si);si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;PROCESS_INFORMATION pi{};std::vector<wchar_t>b(cmd.begin(),cmd.end());b.push_back(0);if(!CreateProcessW(nullptr,b.data(),nullptr,nullptr,FALSE,CREATE_NO_WINDOW,nullptr,cwd.c_str(),&si,&pi))return false;WaitForSingleObject(pi.hProcess,120000);DWORD code=1;GetExitCodeProcess(pi.hProcess,&code);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);return code==0;}

bool validPe64(const fs::path&p){std::ifstream f(p,std::ios::binary);if(!f)return false;f.seekg(0,std::ios::end);auto size=(uint64_t)f.tellg();if(size<64)return false;f.seekg(0);char dos[64]{};f.read(dos,64);if(dos[0]!='M'||dos[1]!='Z')return false;uint32_t off=*reinterpret_cast<uint32_t*>(dos+0x3c);if(off+24>size)return false;f.seekg(off);char sig[4];f.read(sig,4);if(std::string(sig,4)!=std::string("PE\0\0",4))return false;uint16_t machine=0,sections=0,opt=0;f.read((char*)&machine,2);f.read((char*)&sections,2);f.seekg(12,std::ios::cur);f.read((char*)&opt,2);f.seekg(2,std::ios::cur);if(machine!=0x8664||!sections||sections>96)return false;uint64_t table=off+24+opt;if(table+sections*40>size)return false;f.seekg(table);uint64_t need=0;for(unsigned i=0;i<sections;++i){char h[40];f.read(h,40);uint32_t raw=*reinterpret_cast<uint32_t*>(h+16),ptr=*reinterpret_cast<uint32_t*>(h+20);if(raw&&ptr)need=std::max<uint64_t>(need,(uint64_t)raw+ptr);}return need<=size;}

int WINAPI wWinMain(HINSTANCE,HINSTANCE,PWSTR,int){
    if(MessageBoxW(nullptr,L"Este reparador nativo vai baixar o FFmpeg x64 LGPL correto (aprox. 74 MB), conferir SHA-256 e substituir somente os componentes FFmpeg.\n\nContinuar?",L"NEO Media • Reparar FFmpeg",MB_YESNO|MB_ICONINFORMATION)!=IDYES)return 0;
    fs::path base=root(),bin=base/L"bin",tmp=fs::temp_directory_path()/L"NEO-Media-FFmpeg-Repair";std::error_code ec;fs::remove_all(tmp,ec);fs::create_directories(tmp,ec);fs::path zip=tmp/L"ffmpeg.zip";
    if(!download(URL,zip)){fail(L"Falha ao baixar o pacote FFmpeg. Confira a internet e tente novamente.");return 2;}
    auto hash=sha256(zip);if(hash!=SHA256_EXPECTED){fail(L"O SHA-256 do download não confere. O arquivo não será instalado.");return 3;}
    wchar_t sys[MAX_PATH];GetSystemDirectoryW(sys,MAX_PATH);fs::path tar=fs::path(sys)/L"tar.exe";if(!fs::exists(tar)){fail(L"O tar.exe do Windows não foi encontrado. Atualize o Windows 10/11 e tente novamente.");return 4;}
    std::wstring cmd=L"\""+tar.wstring()+L"\" -xf \""+zip.wstring()+L"\" -C \""+tmp.wstring()+L"\"";if(!run(cmd,tmp)){fail(L"Não foi possível extrair o FFmpeg.");return 5;}
    fs::path sourceBin;for(auto& e:fs::recursive_directory_iterator(tmp,fs::directory_options::skip_permission_denied,ec)){if(ec){ec.clear();continue;}if(e.path().filename()==L"ffmpeg.exe"&&e.path().parent_path().filename()==L"bin"){sourceBin=e.path().parent_path();break;}}
    if(sourceBin.empty()){fail(L"Estrutura inesperada no pacote baixado.");return 6;}
    const wchar_t* files[]={L"ffmpeg.exe",L"ffprobe.exe",L"avcodec-63.dll",L"avdevice-63.dll",L"avfilter-12.dll",L"avformat-63.dll",L"avutil-61.dll",L"swresample-7.dll",L"swscale-10.dll"};for(auto name:files){fs::path src=sourceBin/name;if(!fs::exists(src)||!validPe64(src)){fail(std::wstring(L"Componente inválido no download: ")+name);return 7;}}
    fs::create_directories(bin,ec);fs::path backup=base/L"bin-backup-before-repair";fs::remove_all(backup,ec);fs::create_directories(backup,ec);for(auto name:files){fs::path dst=bin/name;if(fs::exists(dst))fs::copy_file(dst,backup/name,fs::copy_options::overwrite_existing,ec);ec.clear();if(!fs::copy_file(sourceBin/name,dst,fs::copy_options::overwrite_existing,ec)||ec){for(auto rollback:files){fs::path old=backup/rollback;if(fs::exists(old))fs::copy_file(old,bin/rollback,fs::copy_options::overwrite_existing,ec);}fail(L"Falha ao instalar o FFmpeg. O backup anterior foi restaurado.");return 8;}}
    fs::remove_all(tmp,ec);MessageBoxW(nullptr,L"FFmpeg reparado e validado com sucesso. Abra novamente o NEO Media.",L"NEO Media",MB_OK|MB_ICONINFORMATION);return 0;
}
