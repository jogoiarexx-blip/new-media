#include "player_process.hpp"
#include <algorithm>
#include <sstream>
#include <vector>

static std::wstring quote(const std::wstring& s){std::wstring o=L"\"";size_t bs=0;for(wchar_t c:s){if(c==L'\\'){++bs;continue;}if(c==L'\"'){o.append(bs*2+1,L'\\');o+=L'\"';bs=0;}else{o.append(bs,L'\\');bs=0;o+=c;}}o.append(bs*2,L'\\');o+=L'\"';return o;}

bool PlayerProcess::open(const std::wstring& exe,const std::wstring& source,HWND host,bool video,double volume,bool muted,const std::wstring& quality,const std::wstring& resolution,int audioStream,double offset,bool paused){
    stop(true); error.clear(); state="opening"; position=duration=0;
    SECURITY_ATTRIBUTES sa{sizeof(sa),nullptr,TRUE};HANDLE inRead=nullptr,outWrite=nullptr;
    if(!CreatePipe(&inRead,&inWrite_,&sa,0)||!CreatePipe(&outRead_,&outWrite,&sa,0)){error=L"Falha ao criar comunicação com o motor.";return false;}
    SetHandleInformation(inWrite_,HANDLE_FLAG_INHERIT,0);SetHandleInformation(outRead_,HANDLE_FLAG_INHERIT,0);
    std::wostringstream cmd;cmd<<quote(exe)<<L" "<<quote(source)<<L" --ipc --volume "<<volume;
    if(muted)cmd<<L" --mute";if(offset>0)cmd<<L" --start "<<offset;if(paused)cmd<<L" --paused";if(audioStream>=0)cmd<<L" --audio-stream "<<audioStream;
    if(video){cmd<<L" --window-id "<<reinterpret_cast<uintptr_t>(host)<<L" --preset "<<quality;if(resolution==L"1080p"||resolution==L"1440p"||resolution==L"4k")cmd<<L" --"<<resolution;}
    std::wstring mutableCmd=cmd.str();std::vector<wchar_t> buf(mutableCmd.begin(),mutableCmd.end());buf.push_back(0);
    STARTUPINFOW si{};si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;si.hStdInput=inRead;si.hStdOutput=outWrite;si.hStdError=outWrite;
    std::wstring cwd=exe.substr(0,exe.find_last_of(L"\\/"));
    BOOL ok=CreateProcessW(exe.c_str(),buf.data(),nullptr,nullptr,TRUE,CREATE_NO_WINDOW,nullptr,cwd.c_str(),&si,&pi_);
    CloseHandle(inRead);CloseHandle(outWrite);
    if(!ok){error=L"Não foi possível iniciar o motor multimídia (erro "+std::to_wstring(GetLastError())+L").";CloseHandle(inWrite_);CloseHandle(outRead_);inWrite_=outRead_=nullptr;state="error";return false;}
    return true;
}
void PlayerProcess::command(const std::string& line){if(!inWrite_)return;std::string x=line+"\n";DWORD w=0;WriteFile(inWrite_,x.data(),static_cast<DWORD>(x.size()),&w,nullptr);}
void PlayerProcess::poll(){
    if(!outRead_)return;DWORD avail=0;while(PeekNamedPipe(outRead_,nullptr,0,nullptr,&avail,nullptr)&&avail){char b[2048];DWORD got=0;if(!ReadFile(outRead_,b,std::min<DWORD>(avail,sizeof(b)),&got,nullptr)||!got)break;pending_.append(b,b+got);size_t pos;while((pos=pending_.find('\n'))!=std::string::npos){std::string line=pending_.substr(0,pos);pending_.erase(0,pos+1);if(!line.empty()&&line.back()=='\r')line.pop_back();std::istringstream in(line);std::string tag;if(in>>tag){if(tag=="NEO_STATUS"){in>>state>>position>>duration;}else if(tag=="NEO_END"){in>>state;}else if(line.find("Nao foi possivel")!=std::string::npos||line.find("Falha")!=std::string::npos){error=std::wstring(line.begin(),line.end());}}}}
    if(pi_.hProcess){DWORD code=STILL_ACTIVE;if(GetExitCodeProcess(pi_.hProcess,&code)&&code!=STILL_ACTIVE){if(state!="ended"&&state!="stopped"){state="error";if(error.empty())error=L"O motor multimídia foi encerrado (código "+std::to_wstring(code)+L").";}CloseHandle(pi_.hThread);CloseHandle(pi_.hProcess);pi_={};if(inWrite_)CloseHandle(inWrite_);if(outRead_)CloseHandle(outRead_);inWrite_=outRead_=nullptr;}}
}
void PlayerProcess::stop(bool force){if(pi_.hProcess){if(!force){command("stop");WaitForSingleObject(pi_.hProcess,1200);}DWORD code=STILL_ACTIVE;GetExitCodeProcess(pi_.hProcess,&code);if(code==STILL_ACTIVE)TerminateProcess(pi_.hProcess,0);WaitForSingleObject(pi_.hProcess,1000);CloseHandle(pi_.hThread);CloseHandle(pi_.hProcess);pi_={};}if(inWrite_)CloseHandle(inWrite_);if(outRead_)CloseHandle(outRead_);inWrite_=outRead_=nullptr;pending_.clear();state="stopped";position=duration=0;}
bool PlayerProcess::running()const{return pi_.hProcess!=nullptr;}
