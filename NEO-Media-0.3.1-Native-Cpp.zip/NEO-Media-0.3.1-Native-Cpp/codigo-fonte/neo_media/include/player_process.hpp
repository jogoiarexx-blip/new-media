#pragma once
#include <windows.h>
#include <string>

class PlayerProcess {
public:
    ~PlayerProcess(){ stop(true); }
    bool open(const std::wstring& exe,const std::wstring& source,HWND videoHost,bool video,double volume,bool muted,const std::wstring& quality,const std::wstring& resolution,int audioStream=-1,double offset=0.0,bool paused=false);
    void command(const std::string& line);
    void poll();
    void stop(bool force=false);
    bool running() const;
    std::string state="stopped";
    double position=0.0,duration=0.0;
    std::wstring error;
private:
    PROCESS_INFORMATION pi_{};
    HANDLE inWrite_=nullptr,outRead_=nullptr;
    std::string pending_;
};
