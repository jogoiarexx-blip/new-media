#pragma once
#include <string>
#include <vector>
#include <filesystem>
#include <random>

struct MediaItem { std::wstring title; std::wstring source; };

enum class ViewMode { Queue, Favorites, Radios };
enum class RepeatMode { Off, One, All };

bool isRemote(const std::wstring& source);
bool isVideoSource(const std::wstring& source);
std::wstring titleFromSource(const std::wstring& source);
std::vector<MediaItem> scanFolder(const std::filesystem::path& root);
std::vector<MediaItem> readM3u(const std::filesystem::path& file);
bool writeM3u(const std::filesystem::path& file, const std::vector<MediaItem>& items);
std::wstring escapeState(const std::wstring& s);
std::wstring unescapeState(const std::wstring& s);
