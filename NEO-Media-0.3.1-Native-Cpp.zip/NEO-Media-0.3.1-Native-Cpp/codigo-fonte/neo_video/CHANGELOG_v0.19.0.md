# Changelog v0.19.0

- Added anti-ringing post-upscale filter.
- Added edge-aware anti-alias filter.
- Added thin-line/text detection.
- Added line/text restoration stage.
- Added post-upscale cleanup orchestrator.
