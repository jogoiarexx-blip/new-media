# Changelog v0.21.0

- Added unified frame analysis coordinator/cache.
- Reduced duplicate content and motion analysis.
- Added A/V sync controller.
- Added pipeline sanity helpers.
- Improved state reset consistency.
- Updated project and application version metadata.
