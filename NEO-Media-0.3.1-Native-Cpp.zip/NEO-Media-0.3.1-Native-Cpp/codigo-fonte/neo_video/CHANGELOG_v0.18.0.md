# Changelog v0.18.0

- Added scene-cut detection.
- Added motion score estimation.
- Added motion-aware temporal filter.
- Added ghosting protection across cuts/high motion.
- Added low-resolution pre-upscale recovery stage.
- Added adaptive 480p/720p recovery decisions.
