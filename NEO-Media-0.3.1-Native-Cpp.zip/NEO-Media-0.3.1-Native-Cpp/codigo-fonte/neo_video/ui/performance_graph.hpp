#pragma once
#include "../core/telemetry_history.hpp"
#include <vector>

struct GraphSeries {
    std::vector<float> fps;
    std::vector<float> cpu;
    std::vector<float> gpu;
    std::vector<float> frame_ms;
};

class PerformanceGraph {
public:
    GraphSeries build(const TelemetryHistory& history) const;
};
