#pragma once
#include "../core/runtime_telemetry.hpp"
#include "../hardware/hardware_profile.hpp"
#include <string>
#include <vector>

struct OverlayLine {
    std::string label;
    std::string value;
};

class PerformanceOverlay {
public:
    void setVisible(bool visible) { visible_ = visible; }
    bool visible() const { return visible_; }
    void toggle() { visible_ = !visible_; }

    std::vector<OverlayLine> build(const RuntimeTelemetrySnapshot& rt,
                                   const HardwareProfile& profile) const;

private:
    bool visible_ = true;
};
