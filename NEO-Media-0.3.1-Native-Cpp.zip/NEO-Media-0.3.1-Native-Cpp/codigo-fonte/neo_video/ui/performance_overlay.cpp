#include "performance_overlay.hpp"
#include <iomanip>
#include <sstream>

static std::string fixed1(double v) {
    std::ostringstream ss;
    ss << std::fixed << std::setprecision(1) << v;
    return ss.str();
}

std::vector<OverlayLine> PerformanceOverlay::build(const RuntimeTelemetrySnapshot& rt,
                                                   const HardwareProfile& profile) const {
    std::vector<OverlayLine> lines;
    if (!visible_) return lines;

    lines.push_back({"PERFIL", profile.name});
    lines.push_back({"BACKEND", rt.backend});
    lines.push_back({"FPS", fixed1(rt.fps)});
    lines.push_back({"FRAME", fixed1(rt.frame_ms) + " ms"});
    lines.push_back({"CPU", fixed1(rt.cpu_percent) + "%"});
    lines.push_back({"GPU", rt.gpu_percent < 0.0 ? "N/D" : fixed1(rt.gpu_percent) + "%"});
    lines.push_back({"ENTRADA", std::to_string(rt.input_width) + "x" + std::to_string(rt.input_height)});
    lines.push_back({"SAIDA", std::to_string(rt.output_width) + "x" + std::to_string(rt.output_height)});
    lines.push_back({"DROP", std::to_string(rt.dropped_frames) + " (" + fixed1(rt.dropped_percent) + "%)"});
    lines.push_back({"HW DEC", rt.hw_decode ? "ON" : "OFF"});
    lines.push_back({"HW ENC", rt.hw_encode ? "ON" : "OFF"});
    lines.push_back({"AI", rt.ai_enabled ? "ON" : "OFF"});
    return lines;
}
