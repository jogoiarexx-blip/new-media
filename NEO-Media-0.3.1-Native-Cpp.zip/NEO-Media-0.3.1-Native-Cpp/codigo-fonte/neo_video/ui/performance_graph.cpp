#include "performance_graph.hpp"

GraphSeries PerformanceGraph::build(const TelemetryHistory& history) const {
    GraphSeries s;
    s.fps.reserve(history.size());
    s.cpu.reserve(history.size());
    s.gpu.reserve(history.size());
    s.frame_ms.reserve(history.size());

    for (std::size_t i = 0; i < history.size(); ++i) {
        const auto& p = history.atChronological(i);
        s.fps.push_back(static_cast<float>(p.fps));
        s.cpu.push_back(static_cast<float>(p.cpu_percent));
        s.gpu.push_back(static_cast<float>(p.gpu_percent));
        s.frame_ms.push_back(static_cast<float>(p.frame_ms));
    }
    return s;
}
