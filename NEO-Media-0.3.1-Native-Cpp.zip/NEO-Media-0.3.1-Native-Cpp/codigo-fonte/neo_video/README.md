# NEO Video v0.21.0

Versão de robustez e desempenho após a consolidação da v0.20.0.

## Melhorias

- análise de conteúdo/movimento centralizada;
- cache de análise para reduzir trabalho duplicado;
- menos CPU gasta repetindo análise da mesma imagem;
- sincronização A/V centralizada em `SyncController`;
- helpers de sanidade para dimensões e orçamento de frame;
- reset mais consistente de filtros temporais/análise após seek/reset;
- versão/build corrigidos para 0.21.0.

## Pipeline ativo

```text
decode
 -> análise unificada
 -> recuperação low-res
 -> upscale/multi-pass
 -> cor
 -> deblock/chroma/denoise/deband
 -> detail reconstruction
 -> temporal motion-aware
 -> anti-ringing/anti-alias/text preserve
 -> edge sharpen
 -> render/record
```

A aceleração GPU continua experimental até validação real por backend.
