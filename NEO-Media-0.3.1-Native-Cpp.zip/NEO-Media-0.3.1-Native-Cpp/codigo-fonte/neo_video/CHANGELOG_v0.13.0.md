# Changelog v0.13.0

- Added runtime telemetry core.
- Added CPU utilization sampling.
- Added GPU utilization placeholder/adaptor field.
- Added FPS and frame-time tracking.
- Added dropped-frame tracking.
- Added performance overlay model.
- Added automatic hardware profiles.
- Added weak/balanced/high-performance machine classes.
