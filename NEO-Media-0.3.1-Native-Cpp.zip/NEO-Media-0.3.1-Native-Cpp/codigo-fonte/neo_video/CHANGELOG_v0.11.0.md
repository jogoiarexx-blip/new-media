# Changelog v0.11.0

- Added hardware pixel-format negotiation.
- Added low-copy hardware-frame bridge.
- Added `av_hwframe_transfer_data` path.
- Avoids GPU->CPU copies when CPU access is unnecessary.
- Added transfer telemetry.
- Added hardware pixel format mapping for CUDA/QSV/D3D11/VAAPI.
