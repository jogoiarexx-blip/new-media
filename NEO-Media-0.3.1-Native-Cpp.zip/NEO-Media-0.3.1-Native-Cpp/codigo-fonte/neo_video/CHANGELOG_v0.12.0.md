# Changelog v0.12.0

- Added GPU scaler/color abstraction.
- Added CUDA/QSV/VAAPI filter intent.
- Added adaptive CPU/GPU backend selector.
- Added timing-history-based decision logic.
- Preserved CPU fallback.
- Added runtime truthfulness rule for reporting GPU scaling.
