# Changelog v0.14.0

- Added telemetry history ring buffer.
- Added performance graph data model.
- Added five-stage adaptive performance controller.
- Added hysteresis to prevent quality oscillation.
- Added sustained degradation / throttling heuristic.
- Added adaptive AI, denoise, deband, sharpen, tile size and target height decisions.
