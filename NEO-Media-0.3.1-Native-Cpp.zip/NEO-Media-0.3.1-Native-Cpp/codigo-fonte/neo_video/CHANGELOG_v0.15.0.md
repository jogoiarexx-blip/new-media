# Changelog v0.15.0

- Added frame pacing.
- Added reusable AVFrame pool.
- Added CPU/GPU backend cost model.
- Added adaptive luma denoise analysis.
- Added edge-aware sharpen with halo protection.
- Shifted project priority to performance and image quality.
