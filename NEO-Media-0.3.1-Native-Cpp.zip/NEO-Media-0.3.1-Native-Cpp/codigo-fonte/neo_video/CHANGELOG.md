# Changelog

## v0.8.0
- Novo modo `--export` para processamento offline em alta qualidade.
- Exportação H.264 + AAC usando o mesmo motor de melhoria do player.
- IA ONNX opcional também no exportador.
- Fallback automático para Lanczos Ultra quando ONNX/modelo não está disponível.
- Controle de CRF, preset de encoder, bitrate e filtros via linha de comando.
- Progresso de exportação, frames processados, frames por IA e tempo total.
- Player em tempo real e gravação processada preservados.
- Versão da interface atualizada para v0.8.0.
