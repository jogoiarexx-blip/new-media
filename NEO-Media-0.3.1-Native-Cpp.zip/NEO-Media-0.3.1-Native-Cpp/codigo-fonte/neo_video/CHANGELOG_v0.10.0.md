# Changelog v0.10.0

- Added FFmpeg hardware device context class.
- Added backend-to-device mapping.
- Added decoder hardware-context attachment support.
- Added encoder backend selection layer.
- Added GPU telemetry data model.
- Added strict runtime-active-vs-detected distinction.
- Preserved CPU fallback behavior.
