#pragma once

extern "C" {
#include <libavfilter/avfilter.h>
#include <libavfilter/buffersink.h>
#include <libavfilter/buffersrc.h>
#include <libavutil/frame.h>
}

#include <string>

class GpuScaleColor {
public:
    GpuScaleColor();
    ~GpuScaleColor();

    bool configure(const std::string& backend,
                   int inW, int inH,
                   int outW, int outH,
                   const std::string& outPixFmt);

    bool process(AVFrame* input, AVFrame* output);
    void reset();

    bool active() const { return graph_ != nullptr; }
    const std::string& filterDescription() const { return filter_desc_; }

private:
    AVFilterGraph* graph_ = nullptr;
    AVFilterContext* src_ = nullptr;
    AVFilterContext* sink_ = nullptr;
    std::string filter_desc_;
};
