#include "ffmpeg_hw_select.hpp"

static AVHWDeviceType typeFromBackend(const std::string& s) {
    if (s.find("cuda") != std::string::npos || s.find("cuvid") != std::string::npos || s.find("nvenc") != std::string::npos)
        return AV_HWDEVICE_TYPE_CUDA;
    if (s.find("qsv") != std::string::npos)
        return AV_HWDEVICE_TYPE_QSV;
    if (s.find("d3d11va") != std::string::npos || s.find("amf") != std::string::npos)
        return AV_HWDEVICE_TYPE_D3D11VA;
    if (s.find("vaapi") != std::string::npos)
        return AV_HWDEVICE_TYPE_VAAPI;
    return AV_HWDEVICE_TYPE_NONE;
}

FfmpegHwChoice FfmpegHwSelect::map(const HwAccelSelection& sel) {
    FfmpegHwChoice c;
    c.decoder_name = sel.decode_backend;
    c.encoder_name = sel.encode_backend;
    c.device_type = typeFromBackend(
        !sel.decode_backend.empty() ? sel.decode_backend : sel.encode_backend
    );
    return c;
}
