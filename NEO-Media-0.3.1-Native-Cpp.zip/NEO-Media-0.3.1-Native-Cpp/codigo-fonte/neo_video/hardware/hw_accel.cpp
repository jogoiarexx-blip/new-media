#include "hw_accel.hpp"

HwAccelSelection HwAccelManager::choose(const GpuCapability& cap,
                                        HwAccelMode requested,
                                        bool wantDecode,
                                        bool wantEncode) {
    HwAccelSelection s;
    s.requested = requested;

    if (requested == HwAccelMode::CPU) {
        s.status = "CPU forced";
        return s;
    }

    auto enable_first = [&]() {
        if (wantDecode && cap.supports_hw_decode && !cap.decoders.empty()) {
            s.decode_enabled = true;
            s.decode_backend = cap.decoders.front();
        }
        if (wantEncode && cap.supports_hw_encode && !cap.encoders.empty()) {
            s.encode_enabled = true;
            s.encode_backend = cap.encoders.front();
        }
    };

    if (requested == HwAccelMode::Auto) {
        enable_first();
        s.status = (s.decode_enabled || s.encode_enabled) ? "GPU auto-selected" : "CPU fallback";
        return s;
    }

    bool vendorMatch =
        (requested == HwAccelMode::NVIDIA && cap.nvidia) ||
        (requested == HwAccelMode::AMD && cap.amd) ||
        (requested == HwAccelMode::Intel && cap.intel);

    if (vendorMatch) {
        enable_first();
        s.status = "Requested GPU backend selected";
    } else {
        s.status = "Requested GPU unavailable; CPU fallback";
    }
    return s;
}
