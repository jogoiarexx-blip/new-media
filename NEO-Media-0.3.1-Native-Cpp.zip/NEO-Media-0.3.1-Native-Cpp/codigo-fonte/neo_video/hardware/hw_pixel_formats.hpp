#pragma once

extern "C" {
#include <libavutil/pixfmt.h>
#include <libavutil/hwcontext.h>
}

inline AVPixelFormat neoPreferredHwPixelFormat(AVHWDeviceType type) {
    switch (type) {
        case AV_HWDEVICE_TYPE_CUDA:    return AV_PIX_FMT_CUDA;
        case AV_HWDEVICE_TYPE_QSV:     return AV_PIX_FMT_QSV;
        case AV_HWDEVICE_TYPE_D3D11VA: return AV_PIX_FMT_D3D11;
        case AV_HWDEVICE_TYPE_VAAPI:   return AV_PIX_FMT_VAAPI;
        default:                       return AV_PIX_FMT_NONE;
    }
}
