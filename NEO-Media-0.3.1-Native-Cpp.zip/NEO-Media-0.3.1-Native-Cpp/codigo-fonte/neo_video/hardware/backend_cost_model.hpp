#pragma once
#include <string>

struct BackendCostSnapshot {
    double cpu_ms = 0.0;
    double gpu_ms = 0.0;
    double transfer_ms = 0.0;
    bool gpu_valid = false;
};

class BackendCostModel {
public:
    void sampleCpu(double ms);
    void sampleGpu(double ms);
    void sampleTransfer(double ms);

    bool preferGpu(bool frameAlreadyOnGpu, bool cpuStageRequired) const;
    BackendCostSnapshot snapshot() const { return s_; }

private:
    static double smooth(double prev, double next);
    BackendCostSnapshot s_;
};
