#include "backend_cost_model.hpp"

double BackendCostModel::smooth(double prev, double next) {
    return prev <= 0.0 ? next : prev * 0.88 + next * 0.12;
}

void BackendCostModel::sampleCpu(double ms) {
    if (ms > 0.0) s_.cpu_ms = smooth(s_.cpu_ms, ms);
}
void BackendCostModel::sampleGpu(double ms) {
    if (ms > 0.0) {
        s_.gpu_ms = smooth(s_.gpu_ms, ms);
        s_.gpu_valid = true;
    }
}
void BackendCostModel::sampleTransfer(double ms) {
    if (ms > 0.0) s_.transfer_ms = smooth(s_.transfer_ms, ms);
}

bool BackendCostModel::preferGpu(bool frameAlreadyOnGpu, bool cpuStageRequired) const {
    if (!s_.gpu_valid || s_.gpu_ms <= 0.0) return false;

    double gpuCost = s_.gpu_ms;
    if (!frameAlreadyOnGpu) gpuCost += s_.transfer_ms;
    if (cpuStageRequired) gpuCost += s_.transfer_ms;

    if (s_.cpu_ms <= 0.0) return frameAlreadyOnGpu && !cpuStageRequired;
    return gpuCost < s_.cpu_ms * 0.94;
}
