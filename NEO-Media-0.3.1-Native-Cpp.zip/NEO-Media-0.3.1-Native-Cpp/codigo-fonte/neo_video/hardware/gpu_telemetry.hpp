#pragma once
#include <string>

struct GpuTelemetrySnapshot {
    bool gpu_active = false;
    std::string backend = "CPU";
    int decode_active = 0;
    int encode_active = 0;
    long long frames_hw = 0;
    long long frames_cpu_fallback = 0;
    long long hw_to_cpu_transfers = 0;
    long long transfers_avoided = 0;
    long long transfer_failures = 0;
};

class GpuTelemetry {
public:
    void setBackend(const std::string& name, bool active);
    void setDecode(bool active);
    void setEncode(bool active);
    void noteHardwareFrame();
    void noteCpuFallback();
    void noteHwToCpuTransfer();
    void noteTransferAvoided();
    void noteTransferFailure();
    GpuTelemetrySnapshot snapshot() const;

private:
    GpuTelemetrySnapshot s_;
};
