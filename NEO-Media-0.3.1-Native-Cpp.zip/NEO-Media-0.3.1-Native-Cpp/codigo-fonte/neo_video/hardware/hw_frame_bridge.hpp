#pragma once

extern "C" {
#include <libavutil/frame.h>
#include <libavutil/pixfmt.h>
#include <libavutil/hwcontext.h>
}

#include <string>

struct HwFrameBridgeStats {
    long long hw_frames_seen = 0;
    long long transfers_to_cpu = 0;
    long long transfers_avoided = 0;
    long long transfer_failures = 0;
};

class HwFrameBridge {
public:
    bool isHardwareFrame(const AVFrame* frame) const;

    // Returns true when dst contains a CPU-readable frame.
    // If src is already software-backed, it clones/references without hw transfer.
    bool ensureCpuReadable(const AVFrame* src, AVFrame* dst);

    // Helper to decide whether a CPU transfer is required by the current processing path.
    bool needsCpuTransfer(const AVFrame* src, bool cpuFiltersEnabled, bool cpuAiEnabled) const;

    const HwFrameBridgeStats& stats() const { return stats_; }

private:
    HwFrameBridgeStats stats_;
};
