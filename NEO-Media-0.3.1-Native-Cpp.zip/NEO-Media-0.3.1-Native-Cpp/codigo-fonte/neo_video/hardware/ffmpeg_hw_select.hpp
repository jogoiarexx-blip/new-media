#pragma once

extern "C" {
#include <libavutil/hwcontext.h>
}

#include "hw_accel.hpp"
#include <string>

struct FfmpegHwChoice {
    AVHWDeviceType device_type = AV_HWDEVICE_TYPE_NONE;
    std::string decoder_name;
    std::string encoder_name;
};

class FfmpegHwSelect {
public:
    static FfmpegHwChoice map(const HwAccelSelection& sel);
};
