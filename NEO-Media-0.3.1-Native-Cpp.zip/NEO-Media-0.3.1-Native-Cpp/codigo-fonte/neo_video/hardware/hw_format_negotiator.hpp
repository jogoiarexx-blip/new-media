#pragma once

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/pixfmt.h>
}

struct HwFormatNegotiation {
    AVPixelFormat preferred_hw = AV_PIX_FMT_NONE;
    AVPixelFormat selected = AV_PIX_FMT_NONE;
    bool used_hw = false;
};

class HwFormatNegotiator {
public:
    static void setPreferred(AVPixelFormat fmt);
    static AVPixelFormat getFormat(AVCodecContext* ctx, const AVPixelFormat* pix_fmts);
    static HwFormatNegotiation last();

private:
    static AVPixelFormat preferred_;
    static HwFormatNegotiation last_;
};
