#pragma once
#include <string>

enum class ProcessingBackend {
    CPU,
    GPU
};

struct BackendMetrics {
    double cpu_ms = 0.0;
    double gpu_ms = 0.0;
    int samples = 0;
};

struct BackendDecision {
    ProcessingBackend backend = ProcessingBackend::CPU;
    std::string reason;
};

class GpuFilterSelector {
public:
    BackendDecision choose(bool gpuAvailable,
                           bool frameAlreadyOnGpu,
                           bool cpuFiltersRequired,
                           double estimatedTransferMs) const;

    void updateCpuSample(double ms);
    void updateGpuSample(double ms);
    BackendMetrics metrics() const { return metrics_; }

private:
    BackendMetrics metrics_;
};
