#include "ffmpeg_hw_context.hpp"

FfmpegHwContext::FfmpegHwContext() = default;

FfmpegHwContext::~FfmpegHwContext() {
    reset();
}

bool FfmpegHwContext::init(AVHWDeviceType type, const std::string& device) {
    reset();
    AVBufferRef* ctx = nullptr;
    const char* dev = device.empty() ? nullptr : device.c_str();

    int ret = av_hwdevice_ctx_create(&ctx, type, dev, nullptr, 0);
    if (ret < 0 || !ctx) {
        return false;
    }

    device_ctx_ = ctx;
    type_ = type;
    return true;
}

void FfmpegHwContext::reset() {
    if (device_ctx_) {
        av_buffer_unref(&device_ctx_);
    }
    type_ = AV_HWDEVICE_TYPE_NONE;
}

bool FfmpegHwContext::attachToDecoder(AVCodecContext* ctx) const {
    if (!ctx || !device_ctx_) return false;
    ctx->hw_device_ctx = av_buffer_ref(device_ctx_);
    return ctx->hw_device_ctx != nullptr;
}

AVBufferRef* FfmpegHwContext::ref() const {
    return device_ctx_;
}

std::string FfmpegHwContext::typeName() const {
    const char* n = av_hwdevice_get_type_name(type_);
    return n ? n : "none";
}
