#pragma once
#include <string>

struct ThrottleState {
    bool suspected = false;
    int severity = 0;
    std::string reason;
};

class ThrottleDetector {
public:
    ThrottleState update(double frameMs,
                         double baselineFrameMs,
                         double cpuPercent,
                         double gpuPercent,
                         double droppedPercent);

private:
    int hot_windows_ = 0;
};
