#include "gpu_telemetry.hpp"

void GpuTelemetry::setBackend(const std::string& name, bool active) {
    s_.backend = active ? name : "CPU";
    s_.gpu_active = active;
}
void GpuTelemetry::setDecode(bool active) { s_.decode_active = active ? 1 : 0; }
void GpuTelemetry::setEncode(bool active) { s_.encode_active = active ? 1 : 0; }
void GpuTelemetry::noteHardwareFrame() { ++s_.frames_hw; }
void GpuTelemetry::noteCpuFallback() { ++s_.frames_cpu_fallback; }
void GpuTelemetry::noteHwToCpuTransfer() { ++s_.hw_to_cpu_transfers; }
void GpuTelemetry::noteTransferAvoided() { ++s_.transfers_avoided; }
void GpuTelemetry::noteTransferFailure() { ++s_.transfer_failures; }
GpuTelemetrySnapshot GpuTelemetry::snapshot() const { return s_; }
