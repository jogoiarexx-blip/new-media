#pragma once
#include <string>

enum class MachineClass {
    Low,
    Balanced,
    High
};

struct HardwareProfile {
    MachineClass machine_class = MachineClass::Balanced;
    std::string name = "Balanced";
    int worker_threads = 2;
    int ai_tile = 128;
    int max_realtime_height = 1080;
    bool prefer_gpu_decode = true;
    bool prefer_gpu_scale = false;
    bool enable_heavy_denoise = false;
    bool enable_deband = true;
    double sharpen = 0.20;
};

class HardwareProfiler {
public:
    static HardwareProfile detect(int logicalThreads,
                                  bool avx2,
                                  bool avx512,
                                  bool gpuAvailable,
                                  bool gpuHardwareEncode);
};
