#include "gpu_filter_selector.hpp"

BackendDecision GpuFilterSelector::choose(bool gpuAvailable,
                                          bool frameAlreadyOnGpu,
                                          bool cpuFiltersRequired,
                                          double estimatedTransferMs) const {
    BackendDecision d;

    if (!gpuAvailable) {
        d.backend = ProcessingBackend::CPU;
        d.reason = "GPU unavailable";
        return d;
    }

    if (cpuFiltersRequired && !frameAlreadyOnGpu) {
        d.backend = ProcessingBackend::CPU;
        d.reason = "CPU filters dominate current pipeline";
        return d;
    }

    if (metrics_.samples >= 8 && metrics_.gpu_ms > 0.0 && metrics_.cpu_ms > 0.0) {
        const double gpuEffective = metrics_.gpu_ms + (frameAlreadyOnGpu ? 0.0 : estimatedTransferMs);
        if (gpuEffective < metrics_.cpu_ms * 0.95) {
            d.backend = ProcessingBackend::GPU;
            d.reason = "Measured GPU path is faster";
        } else {
            d.backend = ProcessingBackend::CPU;
            d.reason = "Measured CPU path is faster or similar";
        }
        return d;
    }

    if (frameAlreadyOnGpu) {
        d.backend = ProcessingBackend::GPU;
        d.reason = "Avoiding GPU-to-CPU transfer";
    } else {
        d.backend = ProcessingBackend::CPU;
        d.reason = "No timing history; CPU is safer baseline";
    }
    return d;
}

void GpuFilterSelector::updateCpuSample(double ms) {
    if (ms <= 0.0) return;
    metrics_.cpu_ms = metrics_.samples == 0 ? ms : (metrics_.cpu_ms * 0.85 + ms * 0.15);
    ++metrics_.samples;
}

void GpuFilterSelector::updateGpuSample(double ms) {
    if (ms <= 0.0) return;
    metrics_.gpu_ms = metrics_.gpu_ms == 0.0 ? ms : (metrics_.gpu_ms * 0.85 + ms * 0.15);
}
