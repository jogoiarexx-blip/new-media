#include "gpu_detect.hpp"
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <algorithm>

static bool contains_ci(std::string a, std::string b) {
    std::transform(a.begin(), a.end(), a.begin(), ::tolower);
    std::transform(b.begin(), b.end(), b.begin(), ::tolower);
    return a.find(b) != std::string::npos;
}

GpuCapability GpuDetector::detect() {
    GpuCapability cap;
#if defined(_WIN32)
    // Lightweight vendor hint. A production build can replace this with DXGI enumeration.
    const char* env = std::getenv("NEO_VIDEO_GPU");
    if (env) cap.name = env;
#else
    std::ifstream f("/proc/driver/nvidia/version");
    if (f.good()) cap.name = "NVIDIA";
#endif

    if (contains_ci(cap.name, "nvidia")) {
        cap.vendor = "NVIDIA"; cap.nvidia = true;
        cap.supports_hw_decode = true; cap.supports_hw_encode = true;
        cap.decoders = {"h264_cuvid","hevc_cuvid","av1_cuvid"};
        cap.encoders = {"h264_nvenc","hevc_nvenc","av1_nvenc"};
    } else if (contains_ci(cap.name, "amd") || contains_ci(cap.name, "radeon")) {
        cap.vendor = "AMD"; cap.amd = true;
        cap.supports_hw_decode = true; cap.supports_hw_encode = true;
        cap.decoders = {"d3d11va","vaapi"};
        cap.encoders = {"h264_amf","hevc_amf","av1_amf"};
    } else if (contains_ci(cap.name, "intel")) {
        cap.vendor = "Intel"; cap.intel = true;
        cap.supports_hw_decode = true; cap.supports_hw_encode = true;
        cap.decoders = {"qsv","d3d11va","vaapi"};
        cap.encoders = {"h264_qsv","hevc_qsv","av1_qsv"};
    } else {
        cap.vendor = "Unknown/CPU";
        cap.name = cap.name.empty() ? "No GPU hint detected" : cap.name;
    }
    return cap;
}
