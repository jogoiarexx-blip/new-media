#include "hardware_profile.hpp"
#include <algorithm>

HardwareProfile HardwareProfiler::detect(int logicalThreads,
                                         bool avx2,
                                         bool avx512,
                                         bool gpuAvailable,
                                         bool gpuHardwareEncode) {
    HardwareProfile p;

    int score = 0;
    if (logicalThreads >= 16) score += 3;
    else if (logicalThreads >= 8) score += 2;
    else if (logicalThreads >= 4) score += 1;

    if (avx2) score += 1;
    if (avx512) score += 1;
    if (gpuAvailable) score += 2;
    if (gpuHardwareEncode) score += 1;

    if (score <= 2) {
        p.machine_class = MachineClass::Low;
        p.name = "PC Fraco";
        p.worker_threads = std::max(1, logicalThreads > 2 ? logicalThreads - 2 : 1);
        p.ai_tile = 96;
        p.max_realtime_height = 720;
        p.prefer_gpu_decode = gpuAvailable;
        p.prefer_gpu_scale = gpuAvailable;
        p.enable_heavy_denoise = false;
        p.enable_deband = false;
        p.sharpen = 0.12;
    } else if (score <= 5) {
        p.machine_class = MachineClass::Balanced;
        p.name = "Intermediario";
        p.worker_threads = std::max(2, logicalThreads > 2 ? logicalThreads - 2 : logicalThreads);
        p.ai_tile = 160;
        p.max_realtime_height = 1080;
        p.prefer_gpu_decode = gpuAvailable;
        p.prefer_gpu_scale = gpuAvailable;
        p.enable_heavy_denoise = false;
        p.enable_deband = true;
        p.sharpen = 0.20;
    } else {
        p.machine_class = MachineClass::High;
        p.name = "Alto Desempenho";
        p.worker_threads = std::max(4, logicalThreads > 2 ? logicalThreads - 2 : logicalThreads);
        p.ai_tile = 256;
        p.max_realtime_height = 2160;
        p.prefer_gpu_decode = gpuAvailable;
        p.prefer_gpu_scale = gpuAvailable;
        p.enable_heavy_denoise = true;
        p.enable_deband = true;
        p.sharpen = 0.28;
    }

    return p;
}
