#include "throttle_detector.hpp"
#include <algorithm>

ThrottleState ThrottleDetector::update(double frameMs,
                                       double baselineFrameMs,
                                       double cpuPercent,
                                       double gpuPercent,
                                       double droppedPercent) {
    ThrottleState s;

    if (baselineFrameMs <= 0.0 || frameMs <= 0.0) {
        hot_windows_ = std::max(0, hot_windows_ - 1);
        return s;
    }

    const bool slowdown = frameMs > baselineFrameMs * 1.35;
    const bool saturated =
        cpuPercent > 92.0 ||
        (gpuPercent >= 0.0 && gpuPercent > 95.0) ||
        droppedPercent > 2.0;

    if (slowdown && saturated) ++hot_windows_;
    else hot_windows_ = std::max(0, hot_windows_ - 1);

    if (hot_windows_ >= 4) {
        s.suspected = true;
        s.severity = hot_windows_ >= 10 ? 2 : 1;
        s.reason = "sustained slowdown under high load";
    }
    return s;
}
