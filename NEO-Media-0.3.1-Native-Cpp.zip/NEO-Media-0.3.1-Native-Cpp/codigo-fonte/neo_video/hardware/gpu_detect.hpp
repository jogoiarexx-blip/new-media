#pragma once
#include <string>
#include <vector>

struct GpuCapability {
    std::string vendor;
    std::string name;
    bool nvidia = false;
    bool amd = false;
    bool intel = false;
    bool supports_hw_decode = false;
    bool supports_hw_encode = false;
    std::vector<std::string> decoders;
    std::vector<std::string> encoders;
};

class GpuDetector {
public:
    static GpuCapability detect();
};
