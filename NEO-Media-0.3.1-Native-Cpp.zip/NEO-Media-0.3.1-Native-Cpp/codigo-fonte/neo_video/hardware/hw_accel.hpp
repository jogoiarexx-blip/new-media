#pragma once
#include "gpu_detect.hpp"
#include <string>

enum class HwAccelMode { Auto, CPU, NVIDIA, AMD, Intel };

struct HwAccelSelection {
    HwAccelMode requested = HwAccelMode::Auto;
    bool decode_enabled = false;
    bool encode_enabled = false;
    std::string decode_backend;
    std::string encode_backend;
    std::string status;
};

class HwAccelManager {
public:
    static HwAccelSelection choose(const GpuCapability& cap,
                                   HwAccelMode requested,
                                   bool wantDecode,
                                   bool wantEncode);
};
