#include "hw_frame_bridge.hpp"

bool HwFrameBridge::isHardwareFrame(const AVFrame* frame) const {
    return frame && frame->hw_frames_ctx != nullptr;
}

bool HwFrameBridge::needsCpuTransfer(const AVFrame* src,
                                     bool cpuFiltersEnabled,
                                     bool cpuAiEnabled) const {
    if (!isHardwareFrame(src)) return false;
    return cpuFiltersEnabled || cpuAiEnabled;
}

bool HwFrameBridge::ensureCpuReadable(const AVFrame* src, AVFrame* dst) {
    if (!src || !dst) return false;

    av_frame_unref(dst);

    if (!isHardwareFrame(src)) {
        if (av_frame_ref(dst, src) < 0) return false;
        ++stats_.transfers_avoided;
        return true;
    }

    ++stats_.hw_frames_seen;

    if (av_hwframe_transfer_data(dst, src, 0) < 0) {
        ++stats_.transfer_failures;
        av_frame_unref(dst);
        return false;
    }

    // Preserve timing/metadata that may not be copied by a hw transfer.
    av_frame_copy_props(dst, src);
    ++stats_.transfers_to_cpu;
    return true;
}
