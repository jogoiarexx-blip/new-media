#include "system_usage.hpp"

#if defined(_WIN32)
#define NOMINMAX
#include <windows.h>

static unsigned long long fileTimeToULL(const FILETIME& ft) {
    ULARGE_INTEGER u;
    u.LowPart = ft.dwLowDateTime;
    u.HighPart = ft.dwHighDateTime;
    return u.QuadPart;
}

SystemUsageSnapshot SystemUsage::sample() {
    static unsigned long long prevIdle = 0, prevKernel = 0, prevUser = 0;
    FILETIME idle, kernel, user;
    SystemUsageSnapshot s;

    if (GetSystemTimes(&idle, &kernel, &user)) {
        auto i = fileTimeToULL(idle);
        auto k = fileTimeToULL(kernel);
        auto u = fileTimeToULL(user);

        if (prevKernel != 0) {
            auto idleDelta = i - prevIdle;
            auto totalDelta = (k - prevKernel) + (u - prevUser);
            if (totalDelta > 0) {
                s.cpu_percent = 100.0 * (1.0 - static_cast<double>(idleDelta) / static_cast<double>(totalDelta));
            }
        }

        prevIdle = i; prevKernel = k; prevUser = u;
    }
    // GPU usage remains backend-specific. Runtime adapters may overwrite this.
    s.gpu_percent = -1.0;
    return s;
}
#else
#include <fstream>
#include <sstream>
#include <string>

SystemUsageSnapshot SystemUsage::sample() {
    static unsigned long long prevIdle = 0, prevTotal = 0;
    SystemUsageSnapshot s;

    std::ifstream f("/proc/stat");
    std::string line;
    if (std::getline(f, line)) {
        std::istringstream in(line);
        std::string cpu;
        unsigned long long user=0,nice=0,system=0,idle=0,iowait=0,irq=0,softirq=0,steal=0;
        in >> cpu >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal;
        const unsigned long long idleAll = idle + iowait;
        const unsigned long long total = user + nice + system + idle + iowait + irq + softirq + steal;

        if (prevTotal != 0 && total > prevTotal) {
            const auto totalDelta = total - prevTotal;
            const auto idleDelta = idleAll - prevIdle;
            s.cpu_percent = 100.0 * (1.0 - static_cast<double>(idleDelta) / static_cast<double>(totalDelta));
        }
        prevIdle = idleAll;
        prevTotal = total;
    }
    s.gpu_percent = -1.0;
    return s;
}
#endif
