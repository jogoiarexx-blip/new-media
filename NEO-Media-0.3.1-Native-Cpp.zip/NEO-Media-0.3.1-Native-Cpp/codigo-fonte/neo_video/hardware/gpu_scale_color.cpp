#include "gpu_scale_color.hpp"
#include <sstream>

GpuScaleColor::GpuScaleColor() = default;
GpuScaleColor::~GpuScaleColor() { reset(); }

bool GpuScaleColor::configure(const std::string& backend,
                              int inW, int inH,
                              int outW, int outH,
                              const std::string& outPixFmt) {
    reset();

    std::string scale;
    if (backend == "cuda" || backend == "nvidia") {
        scale = "scale_cuda=" + std::to_string(outW) + ":" + std::to_string(outH);
    } else if (backend == "qsv" || backend == "intel") {
        scale = "scale_qsv=w=" + std::to_string(outW) + ":h=" + std::to_string(outH);
    } else if (backend == "vaapi" || backend == "amd") {
        scale = "scale_vaapi=w=" + std::to_string(outW) + ":h=" + std::to_string(outH);
    } else {
        return false;
    }

    filter_desc_ = scale;
    if (!outPixFmt.empty()) {
        filter_desc_ += ",format=" + outPixFmt;
    }

    graph_ = avfilter_graph_alloc();
    if (!graph_) return false;

    const AVFilter* buffersrc = avfilter_get_by_name("buffer");
    const AVFilter* buffersink = avfilter_get_by_name("buffersink");
    if (!buffersrc || !buffersink) {
        reset();
        return false;
    }

    std::ostringstream args;
    args << "video_size=" << inW << "x" << inH
         << ":pix_fmt=0"
         << ":time_base=1/1000"
         << ":pixel_aspect=1/1";

    if (avfilter_graph_create_filter(&src_, buffersrc, "in", args.str().c_str(), nullptr, graph_) < 0) {
        reset();
        return false;
    }

    if (avfilter_graph_create_filter(&sink_, buffersink, "out", nullptr, nullptr, graph_) < 0) {
        reset();
        return false;
    }

    AVFilterInOut* outputs = avfilter_inout_alloc();
    AVFilterInOut* inputs = avfilter_inout_alloc();
    if (!outputs || !inputs) {
        avfilter_inout_free(&outputs);
        avfilter_inout_free(&inputs);
        reset();
        return false;
    }

    outputs->name = av_strdup("in");
    outputs->filter_ctx = src_;
    outputs->pad_idx = 0;
    outputs->next = nullptr;

    inputs->name = av_strdup("out");
    inputs->filter_ctx = sink_;
    inputs->pad_idx = 0;
    inputs->next = nullptr;

    int ret = avfilter_graph_parse_ptr(graph_, filter_desc_.c_str(), &inputs, &outputs, nullptr);
    avfilter_inout_free(&inputs);
    avfilter_inout_free(&outputs);
    if (ret < 0 || avfilter_graph_config(graph_, nullptr) < 0) {
        reset();
        return false;
    }

    return true;
}

bool GpuScaleColor::process(AVFrame* input, AVFrame* output) {
    if (!graph_ || !src_ || !sink_ || !input || !output) return false;
    av_frame_unref(output);

    if (av_buffersrc_add_frame_flags(src_, input, AV_BUFFERSRC_FLAG_KEEP_REF) < 0)
        return false;

    return av_buffersink_get_frame(sink_, output) >= 0;
}

void GpuScaleColor::reset() {
    if (graph_) {
        avfilter_graph_free(&graph_);
    }
    src_ = nullptr;
    sink_ = nullptr;
    filter_desc_.clear();
}
