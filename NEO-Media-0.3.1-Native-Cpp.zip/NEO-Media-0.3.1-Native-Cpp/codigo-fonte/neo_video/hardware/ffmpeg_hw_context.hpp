#pragma once

extern "C" {
#include <libavutil/hwcontext.h>
#include <libavcodec/avcodec.h>
}

#include <string>

class FfmpegHwContext {
public:
    FfmpegHwContext();
    ~FfmpegHwContext();

    bool init(AVHWDeviceType type, const std::string& device = "");
    void reset();

    bool attachToDecoder(AVCodecContext* ctx) const;
    AVBufferRef* ref() const;

    bool active() const { return device_ctx_ != nullptr; }
    AVHWDeviceType type() const { return type_; }
    std::string typeName() const;

private:
    AVBufferRef* device_ctx_ = nullptr;
    AVHWDeviceType type_ = AV_HWDEVICE_TYPE_NONE;
};
