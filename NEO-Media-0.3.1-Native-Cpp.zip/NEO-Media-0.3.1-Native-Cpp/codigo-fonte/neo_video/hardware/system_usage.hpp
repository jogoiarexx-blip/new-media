#pragma once

struct SystemUsageSnapshot {
    double cpu_percent = 0.0;
    double gpu_percent = -1.0; // -1 when unavailable
};

class SystemUsage {
public:
    SystemUsageSnapshot sample();
};
