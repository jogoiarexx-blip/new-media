#include "hw_format_negotiator.hpp"

AVPixelFormat HwFormatNegotiator::preferred_ = AV_PIX_FMT_NONE;
HwFormatNegotiation HwFormatNegotiator::last_{};

void HwFormatNegotiator::setPreferred(AVPixelFormat fmt) {
    preferred_ = fmt;
}

AVPixelFormat HwFormatNegotiator::getFormat(AVCodecContext*,
                                            const AVPixelFormat* pix_fmts) {
    last_ = {};
    last_.preferred_hw = preferred_;

    if (!pix_fmts) return AV_PIX_FMT_NONE;

    for (const AVPixelFormat* p = pix_fmts; *p != AV_PIX_FMT_NONE; ++p) {
        if (*p == preferred_ && preferred_ != AV_PIX_FMT_NONE) {
            last_.selected = *p;
            last_.used_hw = true;
            return *p;
        }
    }

    last_.selected = pix_fmts[0];
    last_.used_hw = false;
    return pix_fmts[0];
}

HwFormatNegotiation HwFormatNegotiator::last() {
    return last_;
}
