#pragma once
#include <string>

enum class QualityStep {
    Ultra = 0,
    High = 1,
    Balanced = 2,
    Performance = 3,
    Safe = 4
};

struct AdaptiveState {
    QualityStep step = QualityStep::High;
    bool ai_enabled = true;
    bool heavy_denoise = true;
    bool deband = true;
    double sharpen = 0.25;
    int target_height = 1080;
    int ai_tile = 192;
    std::string reason = "stable";
};

struct AdaptiveInput {
    double fps = 0.0;
    double target_fps = 30.0;
    double frame_ms = 0.0;
    double cpu_percent = 0.0;
    double gpu_percent = -1.0;
    double dropped_percent = 0.0;
    bool ai_available = false;
};

class AdaptivePerformance {
public:
    AdaptiveState update(const AdaptiveInput& in);
    const AdaptiveState& state() const { return state_; }

private:
    AdaptiveState state_;
    int bad_windows_ = 0;
    int good_windows_ = 0;
    void applyStep(QualityStep step, const AdaptiveInput& in);
};
