#pragma once
#include <chrono>

class FramePacer {
public:
    void setTargetFps(double fps);
    void reset();
    void beginFrame();
    void pace();
    double lastSleepMs() const { return last_sleep_ms_; }
    double budgetMs() const { return budget_ms_; }

private:
    using Clock = std::chrono::steady_clock;
    Clock::time_point frame_start_{};
    double budget_ms_ = 16.666;
    double last_sleep_ms_ = 0.0;
};
