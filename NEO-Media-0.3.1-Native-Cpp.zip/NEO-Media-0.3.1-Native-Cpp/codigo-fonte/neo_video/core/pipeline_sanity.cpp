#include "pipeline_sanity.hpp"

PipelineSanityResult PipelineSanity::validateDimensions(int inW, int inH, int outW, int outH) {
    PipelineSanityResult r;
    if (inW <= 0 || inH <= 0 || outW <= 0 || outH <= 0) {
        r.ok = false; r.message = "invalid frame dimensions"; return r;
    }
    if ((outW & 1) || (outH & 1)) {
        r.ok = false; r.message = "YUV420 output dimensions must be even"; return r;
    }
    if (outW > 7680 || outH > 4320) {
        r.ok = false; r.message = "output dimensions exceed conservative 8K safety limit";
    }
    return r;
}

PipelineSanityResult PipelineSanity::validateFrameBudget(double processMs, double budgetMs) {
    PipelineSanityResult r;
    if (budgetMs > 0.0 && processMs >= 0.0 && processMs > budgetMs * 1.5) {
        r.ok = false; r.message = "processing exceeds frame budget by more than 50%";
    }
    return r;
}
