#include "frame_pacer.hpp"
#include <thread>

void FramePacer::setTargetFps(double fps) {
    if (fps > 1.0) budget_ms_ = 1000.0 / fps;
}

void FramePacer::reset() {
    frame_start_ = Clock::now();
    last_sleep_ms_ = 0.0;
}

void FramePacer::beginFrame() {
    frame_start_ = Clock::now();
    last_sleep_ms_ = 0.0;
}

void FramePacer::pace() {
    const auto now = Clock::now();
    const double elapsed = std::chrono::duration<double, std::milli>(now - frame_start_).count();
    const double remaining = budget_ms_ - elapsed;

    // Avoid aggressive sleep for tiny residuals where scheduler jitter is worse.
    if (remaining > 1.2) {
        const double sleep_ms = remaining - 0.6;
        std::this_thread::sleep_for(std::chrono::duration<double, std::milli>(sleep_ms));
        last_sleep_ms_ = sleep_ms;
    }
}
