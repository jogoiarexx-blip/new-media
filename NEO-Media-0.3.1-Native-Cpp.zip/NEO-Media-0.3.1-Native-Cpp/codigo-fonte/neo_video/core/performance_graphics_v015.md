# NEO Video v0.15.0 — Performance + Graphics

## Performance changes
- Frame pacing helper to reduce jitter.
- Reusable AVFrame pool to reduce alloc/free churn.
- Backend cost model that includes GPU transfer cost.
- CPU/GPU choice based on measured path cost.

## Image-quality changes
- Adaptive luma-noise estimation.
- Edge-aware sharpen with halo guard.
- Conservative denoise activation to avoid smearing clean sources.

## Philosophy
The engine should spend compute only where it improves the frame.
A clean source should not receive aggressive denoise.
A strong edge should not receive the same sharpening gain as a soft edge.
A GPU path should not be selected if transfer overhead makes it slower.
