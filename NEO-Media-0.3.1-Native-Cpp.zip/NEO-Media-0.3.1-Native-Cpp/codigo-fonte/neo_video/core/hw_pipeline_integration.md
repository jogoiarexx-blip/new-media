# Hardware integration notes — v0.10.0

This release adds the FFmpeg hardware-device layer using `av_hwdevice_ctx_create`
and support code for attaching the device to decoder contexts.

## Intended initialization flow

1. Detect requested backend.
2. Map backend to FFmpeg hardware device type.
3. Create the hardware device with `av_hwdevice_ctx_create`.
4. Attach the resulting `AVBufferRef` to `AVCodecContext::hw_device_ctx`.
5. Open the decoder.
6. If any stage fails, destroy the device and reopen in CPU mode.

## Encode flow

The encoder selection layer now exposes NVENC / AMF / QSV names. Actual
codec opening must validate `avcodec_find_encoder_by_name()` and fall back to
software H.264/H.265 if the encoder is not present in the local FFmpeg build.

## Telemetry

The new `GpuTelemetry` helper distinguishes:
- requested GPU
- active GPU device
- hardware decode
- hardware encode
- hardware frames
- CPU fallback frames

The UI should display GPU only when the runtime device was successfully created.
