# NEO Video v0.16.0 — Upscale & Temporal Quality

## Upscale
Large scale factors can use a two-pass plan instead of a single large jump.
The second stage can run detail reconstruction on luma with halo protection.

## Temporal filtering
A lightweight previous-frame filter is applied only in low-motion regions.
This reduces flicker/noise/banding while preserving moving edges.

## Performance behavior
Temporal filtering is automatically disabled when frame time exceeds budget
or dropped-frame percentage rises.

## Design goal
Improve perceived detail without inventing excessive ringing or smearing texture.
