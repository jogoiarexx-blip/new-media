# NEO Video v0.11.0 — Low-copy frame pipeline

## Goal

Avoid unnecessary GPU -> CPU transfers.

## Decision path

1. Decode frame.
2. If frame is software-backed:
   - process normally.
3. If frame is hardware-backed:
   - if all enabled stages can stay on GPU, keep it there.
   - if CPU filters or CPU ONNX are enabled, call `av_hwframe_transfer_data`.
4. Reuse destination frames instead of reallocating them per frame.
5. Track transfers so the UI can expose whether acceleration is actually helping.

## Important

This release adds the bridge and negotiation layer. Existing CPU filters still require
CPU-readable frames, so a transfer is unavoidable when those filters are enabled.
The next optimization step is to migrate selected scaler/color operations to GPU.
