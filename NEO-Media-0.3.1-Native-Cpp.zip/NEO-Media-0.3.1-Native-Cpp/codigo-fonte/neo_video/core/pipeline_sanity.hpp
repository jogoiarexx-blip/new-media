#pragma once
#include <string>

struct PipelineSanityResult {
    bool ok = true;
    std::string message = "OK";
};

class PipelineSanity {
public:
    static PipelineSanityResult validateDimensions(int inW, int inH, int outW, int outH);
    static PipelineSanityResult validateFrameBudget(double processMs, double budgetMs);
};
