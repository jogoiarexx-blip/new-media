# NEO Video v0.19.0 — Post-upscale cleanup

## Goals
- Reduce ringing/halos introduced by resize/sharpen.
- Reduce stair-stepping on diagonal lines.
- Preserve thin lines, subtitles, UI captures and text-like graphics.

## Pipeline
Upscale -> detail reconstruction -> anti-ringing -> edge antialias ->
line/text restore -> final sharpen

## Performance
These stages are lightweight spatial filters and can be disabled independently
by Auto Performance when frame budget is tight.
