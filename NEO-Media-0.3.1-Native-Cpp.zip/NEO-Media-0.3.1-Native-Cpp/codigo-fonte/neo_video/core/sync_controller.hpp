#pragma once

enum class SyncAction { None, SleepVideo, DropVideo };

struct SyncDecision {
    SyncAction action = SyncAction::None;
    double sleep_seconds = 0.0;
};

class SyncController {
public:
    SyncDecision decide(double videoPts, double audioClock) const;
};
