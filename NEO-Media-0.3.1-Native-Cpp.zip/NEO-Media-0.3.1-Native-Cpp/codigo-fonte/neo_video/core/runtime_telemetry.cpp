#include "runtime_telemetry.hpp"
#include <algorithm>

void RuntimeTelemetry::setResolution(int inW, int inH, int outW, int outH) {
    s_.input_width = inW;
    s_.input_height = inH;
    s_.output_width = outW;
    s_.output_height = outH;
}

void RuntimeTelemetry::setBackend(const std::string& backend, bool hwDecode, bool hwEncode) {
    s_.backend = backend.empty() ? "CPU" : backend;
    s_.hw_decode = hwDecode;
    s_.hw_encode = hwEncode;
}

void RuntimeTelemetry::setAiEnabled(bool value) {
    s_.ai_enabled = value;
}

void RuntimeTelemetry::beginFrame() {
    frame_start_ = Clock::now();
}

void RuntimeTelemetry::endFrame(bool rendered) {
    const auto now = Clock::now();
    const double ms = std::chrono::duration<double, std::milli>(now - frame_start_).count();

    smooth_frame_ms_ = smooth_frame_ms_ <= 0.0 ? ms : smooth_frame_ms_ * 0.90 + ms * 0.10;
    s_.frame_ms = smooth_frame_ms_;

    if (rendered) {
        ++s_.rendered_frames;
        ++window_frames_;
    }

    const double elapsed = std::chrono::duration<double>(now - window_start_).count();
    if (elapsed >= 0.5) {
        s_.fps = window_frames_ / elapsed;
        window_frames_ = 0;
        window_start_ = now;
    }

    const uint64_t total = s_.rendered_frames + s_.dropped_frames;
    s_.dropped_percent = total ? (100.0 * static_cast<double>(s_.dropped_frames) / static_cast<double>(total)) : 0.0;
}

void RuntimeTelemetry::noteDroppedFrame() {
    ++s_.dropped_frames;
    const uint64_t total = s_.rendered_frames + s_.dropped_frames;
    s_.dropped_percent = total ? (100.0 * static_cast<double>(s_.dropped_frames) / static_cast<double>(total)) : 0.0;
}

void RuntimeTelemetry::setCpuPercent(double value) {
    s_.cpu_percent = std::clamp(value, 0.0, 100.0);
}

void RuntimeTelemetry::setGpuPercent(double value) {
    s_.gpu_percent = value < 0.0 ? -1.0 : std::clamp(value, 0.0, 100.0);
}

RuntimeTelemetrySnapshot RuntimeTelemetry::snapshot() const {
    return s_;
}
