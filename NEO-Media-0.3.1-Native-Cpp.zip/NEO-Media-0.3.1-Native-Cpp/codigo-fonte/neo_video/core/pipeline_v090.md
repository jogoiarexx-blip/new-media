# NEO Video v0.9.0 pipeline

## Realtime
Input -> FFmpeg demux -> HW decode when available -> CPU/GPU frame bridge ->
Upscale / enhancement -> renderer -> optional recorder

## Recording / Export
Processed frame -> hardware encoder when selected and available ->
software encoder fallback -> mux audio/video

## Design rules
- Hardware acceleration is optional.
- If device creation, codec negotiation or frame transfer fails, the player must fall back to CPU.
- Do not call a feature "GPU accelerated" unless FFmpeg actually opened the corresponding hardware device/codec.
- Post-processing stays CPU-compatible in this release. GPU-native filters are planned later.
- AI ONNX remains independent and may continue to use CPU unless a supported execution provider is configured.
