#pragma once
#include <array>
#include <cstddef>

struct TelemetryPoint {
    double fps = 0.0;
    double frame_ms = 0.0;
    double cpu_percent = 0.0;
    double gpu_percent = -1.0;
    double dropped_percent = 0.0;
};

class TelemetryHistory {
public:
    static constexpr std::size_t Capacity = 240;

    void push(const TelemetryPoint& p);
    std::size_t size() const { return size_; }
    const TelemetryPoint& atChronological(std::size_t i) const;

private:
    std::array<TelemetryPoint, Capacity> data_{};
    std::size_t head_ = 0;
    std::size_t size_ = 0;
};
