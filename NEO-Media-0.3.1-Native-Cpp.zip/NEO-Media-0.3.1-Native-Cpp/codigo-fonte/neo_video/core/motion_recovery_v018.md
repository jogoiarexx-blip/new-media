# NEO Video v0.18.0 — Motion-aware recovery

## Main changes
- Scene-cut detection.
- Motion score estimation.
- Temporal filtering resets on scene cuts.
- Temporal blend strength drops during high motion.
- New pre-upscale recovery stage for 480p/720p sources.
- Recovery focuses on light deblocking + texture reconstruction before enlargement.

## Why
Low-resolution compressed material benefits more from cleanup before the main upscale.
Temporal filtering also causes visible ghosting if it blends across cuts or strong motion.
