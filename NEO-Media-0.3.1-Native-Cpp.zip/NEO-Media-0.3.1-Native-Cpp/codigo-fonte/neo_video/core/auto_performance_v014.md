# NEO Video v0.14.0 — Auto Performance 2

O controlador não derruba qualidade por causa de um pico isolado.

## Escada de qualidade
1. Ultra
2. High
3. Balanced
4. Performance
5. Safe

Para reduzir qualidade, são necessárias várias janelas consecutivas de sobrecarga.
Para aumentar qualidade novamente, é exigido um período maior de folga.

## Sinais usados
- ms/frame
- FPS
- frames perdidos
- CPU %
- GPU % quando disponível

## Throttling
A detecção é heurística. Ela marca "suspeita de throttling" quando existe degradação
sustentada de frame time ao mesmo tempo em que CPU/GPU continuam sob carga alta.
Não afirma temperatura real sem um sensor/backend que forneça esse dado.
