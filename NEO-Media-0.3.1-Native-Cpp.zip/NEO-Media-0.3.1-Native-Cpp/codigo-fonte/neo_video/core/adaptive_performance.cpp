#include "adaptive_performance.hpp"
#include <algorithm>

static int stepInt(QualityStep s) { return static_cast<int>(s); }

void AdaptivePerformance::applyStep(QualityStep step, const AdaptiveInput& in) {
    state_.step = step;

    switch (step) {
        case QualityStep::Ultra:
            state_.ai_enabled = in.ai_available;
            state_.heavy_denoise = true;
            state_.deband = true;
            state_.sharpen = 0.30;
            state_.target_height = 2160;
            state_.ai_tile = 256;
            break;
        case QualityStep::High:
            state_.ai_enabled = in.ai_available;
            state_.heavy_denoise = true;
            state_.deband = true;
            state_.sharpen = 0.25;
            state_.target_height = 1440;
            state_.ai_tile = 192;
            break;
        case QualityStep::Balanced:
            state_.ai_enabled = in.ai_available;
            state_.heavy_denoise = false;
            state_.deband = true;
            state_.sharpen = 0.20;
            state_.target_height = 1080;
            state_.ai_tile = 160;
            break;
        case QualityStep::Performance:
            state_.ai_enabled = false;
            state_.heavy_denoise = false;
            state_.deband = false;
            state_.sharpen = 0.14;
            state_.target_height = 1080;
            state_.ai_tile = 128;
            break;
        case QualityStep::Safe:
            state_.ai_enabled = false;
            state_.heavy_denoise = false;
            state_.deband = false;
            state_.sharpen = 0.08;
            state_.target_height = 720;
            state_.ai_tile = 96;
            break;
    }
}

AdaptiveState AdaptivePerformance::update(const AdaptiveInput& in) {
    const double budgetMs = in.target_fps > 1.0 ? 1000.0 / in.target_fps : 33.333;
    const bool overloaded =
        in.frame_ms > budgetMs * 1.08 ||
        (in.fps > 0.0 && in.fps < in.target_fps * 0.92) ||
        in.dropped_percent > 1.5 ||
        in.cpu_percent > 95.0 ||
        (in.gpu_percent >= 0.0 && in.gpu_percent > 97.0);

    const bool veryStable =
        in.frame_ms > 0.0 && in.frame_ms < budgetMs * 0.72 &&
        (in.fps <= 0.0 || in.fps >= in.target_fps * 0.98) &&
        in.dropped_percent < 0.25 &&
        in.cpu_percent < 82.0 &&
        (in.gpu_percent < 0.0 || in.gpu_percent < 88.0);

    if (overloaded) {
        ++bad_windows_;
        good_windows_ = 0;
    } else if (veryStable) {
        ++good_windows_;
        bad_windows_ = std::max(0, bad_windows_ - 1);
    } else {
        bad_windows_ = std::max(0, bad_windows_ - 1);
        good_windows_ = std::max(0, good_windows_ - 1);
    }

    if (bad_windows_ >= 3 && stepInt(state_.step) < stepInt(QualityStep::Safe)) {
        state_.reason = "sustained overload";
        applyStep(static_cast<QualityStep>(stepInt(state_.step) + 1), in);
        bad_windows_ = 0;
    } else if (good_windows_ >= 10 && stepInt(state_.step) > stepInt(QualityStep::Ultra)) {
        state_.reason = "performance headroom";
        applyStep(static_cast<QualityStep>(stepInt(state_.step) - 1), in);
        good_windows_ = 0;
    } else if (!overloaded && !veryStable) {
        state_.reason = "stable";
    }

    return state_;
}
