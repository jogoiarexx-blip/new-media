# NEO Video v0.17.0 — Source-aware quality engine

The player now analyzes source characteristics periodically instead of blindly
running every filter on every frame.

## Detected signals
- 8x8 blockiness
- luma roughness/noise
- chroma roughness/noise
- flat-region/banding tendency
- edge density

## Dynamic filter routing
- compression blocks -> adaptive deblock
- noisy luma -> denoise
- noisy chroma -> chroma cleanup/recovery
- flat/banded areas -> deband
- stable/noisy video -> temporal cleanup
- detailed compressed video -> detail reconstruction

## Performance
Analysis is scheduled every N frames, not necessarily every frame.
Under frame-time pressure, expensive cleanup stages are automatically skipped.
