# Adaptive processing — v0.12.0

The pipeline now has a backend decision layer for scaler/color-conversion work.

## Supported GPU filter intents

- NVIDIA/CUDA: `scale_cuda`
- Intel/QSV: `scale_qsv`
- VAAPI/AMD/Linux-capable paths: `scale_vaapi`

The exact availability still depends on the user's FFmpeg build.

## Selection logic

The selector considers:
1. whether a GPU backend exists;
2. whether the frame is already resident on GPU;
3. whether later filters still require CPU memory;
4. estimated GPU<->CPU transfer cost;
5. recent measured CPU/GPU processing time.

If GPU gives no meaningful benefit, CPU remains selected.

## Safety rule

The program must never claim GPU scaling is active unless the relevant FFmpeg
filter graph was created successfully and processed at least one frame.
