#pragma once
#include <chrono>
#include <cstdint>
#include <string>

struct RuntimeTelemetrySnapshot {
    double fps = 0.0;
    double frame_ms = 0.0;
    double cpu_percent = 0.0;
    double gpu_percent = -1.0;
    double dropped_percent = 0.0;
    uint64_t rendered_frames = 0;
    uint64_t dropped_frames = 0;
    int input_width = 0;
    int input_height = 0;
    int output_width = 0;
    int output_height = 0;
    std::string backend = "CPU";
    bool hw_decode = false;
    bool hw_encode = false;
    bool ai_enabled = false;
};

class RuntimeTelemetry {
public:
    void setResolution(int inW, int inH, int outW, int outH);
    void setBackend(const std::string& backend, bool hwDecode, bool hwEncode);
    void setAiEnabled(bool value);

    void beginFrame();
    void endFrame(bool rendered = true);
    void noteDroppedFrame();

    void setCpuPercent(double value);
    void setGpuPercent(double value);

    RuntimeTelemetrySnapshot snapshot() const;

private:
    using Clock = std::chrono::steady_clock;
    Clock::time_point frame_start_{};
    Clock::time_point window_start_ = Clock::now();

    RuntimeTelemetrySnapshot s_;
    uint64_t window_frames_ = 0;
    double smooth_frame_ms_ = 0.0;
};
