#include "sync_controller.hpp"

SyncDecision SyncController::decide(double videoPts, double audioClock) const {
    SyncDecision d;
    if (videoPts < 0.0 || audioClock < 0.0) return d;
    const double diff = videoPts - audioClock;
    if (diff > 0.002 && diff < 0.250) {
        d.action = SyncAction::SleepVideo;
        d.sleep_seconds = diff;
    } else if (diff < -0.080) {
        d.action = SyncAction::DropVideo;
    }
    return d;
}
