#include "telemetry_history.hpp"
#include <stdexcept>

void TelemetryHistory::push(const TelemetryPoint& p) {
    data_[head_] = p;
    head_ = (head_ + 1) % Capacity;
    if (size_ < Capacity) ++size_;
}

const TelemetryPoint& TelemetryHistory::atChronological(std::size_t i) const {
    if (i >= size_) throw std::out_of_range("TelemetryHistory index");
    const std::size_t start = (head_ + Capacity - size_) % Capacity;
    return data_[(start + i) % Capacity];
}
