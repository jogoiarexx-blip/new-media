# NEO Video v0.13.0 — Telemetria e perfis automáticos

## Objetivos
- Mostrar desempenho real no player.
- Evitar configurações pesadas demais em PCs fracos.
- Escolher um preset inicial de hardware sem impedir ajustes manuais.

## Telemetria
- FPS real renderizado.
- Tempo médio por frame.
- Uso global de CPU.
- Uso de GPU quando um backend conseguir fornecer a métrica.
- Frames perdidos.
- Resolução de entrada e saída.
- Backend de processamento.
- HW Decode / HW Encode.
- Estado da IA.

## Perfis
### PC Fraco
Prioriza 720p/1080p leve, menos filtros pesados e tiles menores.

### Intermediário
Equilibra qualidade, 1080p e recursos de GPU quando disponíveis.

### Alto Desempenho
Libera 1440p/4K, mais workers, tiles maiores e filtros pesados.

O usuário continua podendo trocar todas as opções manualmente.
