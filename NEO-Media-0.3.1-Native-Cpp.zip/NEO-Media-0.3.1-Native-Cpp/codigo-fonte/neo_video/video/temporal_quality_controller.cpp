#include "temporal_quality_controller.hpp"

TemporalQuality TemporalQualityController::choose(double frameMs,
                                                  double budgetMs,
                                                  double droppedPercent,
                                                  bool highQualityMode) const {
    TemporalQuality q;
    if (budgetMs <= 0.0) return q;

    if (frameMs > budgetMs * 1.05 || droppedPercent > 1.0) {
        q.enabled = false;
        q.denoise_strength = 0.0;
        q.deband_strength = 0.0;
        return q;
    }

    if (highQualityMode && frameMs < budgetMs * 0.75) {
        q.enabled = true;
        q.denoise_strength = 0.14;
        q.deband_strength = 0.10;
        q.motion_threshold = 14;
    } else {
        q.enabled = true;
        q.denoise_strength = 0.08;
        q.deband_strength = 0.06;
        q.motion_threshold = 10;
    }
    return q;
}
