#include "pre_upscale_recovery.hpp"
#include <algorithm>

PreUpscaleDecision PreUpscaleRecovery::decide(int width, int height,
                                              const ContentAnalysis& content,
                                              const SceneMotionInfo& motion,
                                              double frameMs, double budgetMs) const {
    PreUpscaleDecision d;
    if (width > 1280 || height > 720) return d;
    if (budgetMs > 0.0 && frameMs > budgetMs * 0.90) return d;

    d.enabled = content.likely_compressed || content.luma_noise > 15.0 || content.blockiness > 3.0;
    if (!d.enabled) return d;

    d.cfg.deblock_strength = std::clamp(content.blockiness / 18.0, 0.10, 0.35);
    d.cfg.texture_recovery = motion.high_motion ? 0.08 : 0.16;
    d.cfg.chroma_cleanup = std::clamp(content.chroma_noise / 80.0, 0.06, 0.20);
    d.cfg.aggressive = !motion.high_motion && content.blockiness > 6.0;
    return d;
}
