#include "anti_ringing.hpp"
#include <vector>
#include <algorithm>
#include <cmath>

void AntiRinging::processLuma(uint8_t* y, int width, int height, int stride, double strength) const {
    if (!y || width < 5 || height < 5 || strength <= 0.0) return;

    std::vector<uint8_t> src((size_t)stride * height);
    for (int j = 0; j < height; ++j)
        std::copy(y + j*stride, y + j*stride + stride, src.data() + j*stride);

    const double s = std::clamp(strength, 0.0, 1.0);

    for (int j = 2; j < height - 2; ++j) {
        for (int i = 2; i < width - 2; ++i) {
            const int idx = j*stride + i;
            const int c = src[idx];

            int localMin = 255, localMax = 0;
            for (int yy = -2; yy <= 2; ++yy) {
                for (int xx = -2; xx <= 2; ++xx) {
                    const int v = src[(j+yy)*stride + (i+xx)];
                    localMin = std::min(localMin, v);
                    localMax = std::max(localMax, v);
                }
            }

            // Only act on overshoot/undershoot close to strong edges.
            const int crossAvg = (
                src[idx-1] + src[idx+1] +
                src[idx-stride] + src[idx+stride]
            ) / 4;

            const int edge = std::abs(c - crossAvg);
            if (edge < 10) continue;

            int target = c;
            if (c > localMax - 2) target = std::max(localMin, localMax - 4);
            else if (c < localMin + 2) target = std::min(localMax, localMin + 4);

            y[idx] = (uint8_t)std::clamp(
                (int)std::lround(c*(1.0-s*0.35) + target*(s*0.35)), 0, 255
            );
        }
    }
}
