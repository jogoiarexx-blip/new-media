#pragma once
#include <cstdint>

class DetailReconstruction {
public:
    void enhanceLuma(uint8_t* y, int width, int height, int stride, double amount) const;
};
