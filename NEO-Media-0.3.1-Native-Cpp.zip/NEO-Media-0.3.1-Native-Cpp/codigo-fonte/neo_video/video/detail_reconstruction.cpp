#include "detail_reconstruction.hpp"
#include <vector>
#include <algorithm>
#include <cmath>

void DetailReconstruction::enhanceLuma(uint8_t* y, int width, int height, int stride, double amount) const {
    if (!y || width < 5 || height < 5 || amount <= 0.0) return;

    std::vector<uint8_t> src(static_cast<std::size_t>(stride) * height);
    for (int j = 0; j < height; ++j)
        std::copy(y + j*stride, y + j*stride + stride, src.data() + j*stride);

    const double a = std::clamp(amount, 0.0, 1.0);

    for (int j = 2; j < height - 2; ++j) {
        for (int i = 2; i < width - 2; ++i) {
            const int idx = j*stride + i;
            const int c = src[idx];

            const int blur1 = (
                src[idx-1] + src[idx+1] +
                src[idx-stride] + src[idx+stride] +
                4*c
            ) / 8;

            const int blur2 = (
                src[idx-2] + src[idx+2] +
                src[idx-2*stride] + src[idx+2*stride] +
                4*c
            ) / 8;

            int high = (c - blur1);
            int mid = (blur1 - blur2);

            const int edgeMag =
                std::max({std::abs(c-src[idx-1]), std::abs(c-src[idx+1]),
                          std::abs(c-src[idx-stride]), std::abs(c-src[idx+stride])});

            double guard = 1.0;
            if (edgeMag > 48) guard = 0.35;
            else if (edgeMag > 28) guard = 0.60;

            const double reconstructed = c + a * guard * (0.75 * high + 0.35 * mid);
            y[idx] = static_cast<uint8_t>(std::clamp(static_cast<int>(std::lround(reconstructed)), 0, 255));
        }
    }
}
