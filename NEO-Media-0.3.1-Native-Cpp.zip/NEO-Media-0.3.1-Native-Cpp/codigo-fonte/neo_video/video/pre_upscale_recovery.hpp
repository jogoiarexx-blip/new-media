#pragma once
#include "content_analyzer.hpp"
#include "scene_motion_detector.hpp"
#include "lowres_recovery.hpp"

struct PreUpscaleDecision {
    bool enabled = false;
    LowResRecoveryConfig cfg;
};

class PreUpscaleRecovery {
public:
    PreUpscaleDecision decide(int width, int height,
                              const ContentAnalysis& content,
                              const SceneMotionInfo& motion,
                              double frameMs, double budgetMs) const;
};
