#include "filter_decision_engine.hpp"
#include <algorithm>

FilterDecision FilterDecisionEngine::decide(const ContentAnalysis& a,
                                            double frameMs,
                                            double budgetMs,
                                            bool highQualityMode) const {
    FilterDecision d;
    const bool overloaded = budgetMs > 0.0 && frameMs > budgetMs * 0.95;

    d.deblock = a.blockiness > 3.5;
    d.deblock_strength = std::clamp(a.blockiness / 18.0, 0.10, 0.60);

    d.denoise = a.luma_noise > 17.0 && !overloaded;
    d.denoise_strength = std::clamp((a.luma_noise - 16.0) / 55.0, 0.08, 0.42);

    d.chroma_enhance = a.chroma_noise > 12.0 && !overloaded;
    d.chroma_denoise = std::clamp((a.chroma_noise - 10.0) / 60.0, 0.06, 0.30);
    d.chroma_recover = highQualityMode ? 0.10 : 0.05;

    d.deband = a.banding > 0.28 && !overloaded;
    d.deband_strength = std::clamp((a.banding - 0.20) * 0.35, 0.04, 0.18);

    d.temporal = !overloaded && a.luma_noise > 14.0;
    d.detail_reconstruct = highQualityMode && a.edge_density > 0.08 && !a.likely_clean;

    if (overloaded) {
        d.denoise = false;
        d.chroma_enhance = false;
        d.deband = false;
        d.temporal = false;
    }
    return d;
}
