#pragma once
#include "content_analyzer.hpp"

class AnalysisScheduler {
public:
    bool shouldAnalyze();
    void submit(const ContentAnalysis& a);
    const ContentAnalysis& latest() const { return latest_; }
    void setInterval(int frames) { interval_ = frames < 1 ? 1 : frames; }

private:
    int interval_ = 12;
    int counter_ = 0;
    ContentAnalysis latest_{};
};
