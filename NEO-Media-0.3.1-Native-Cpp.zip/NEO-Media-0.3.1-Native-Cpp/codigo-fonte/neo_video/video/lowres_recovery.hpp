#pragma once
#include <cstdint>

struct LowResRecoveryConfig {
    double deblock_strength = 0.20;
    double texture_recovery = 0.15;
    double chroma_cleanup = 0.12;
    bool aggressive = false;
};

class LowResRecovery {
public:
    bool shouldUse(int width, int height) const;
    void processLuma(uint8_t* y, int width, int height, int stride,
                     const LowResRecoveryConfig& cfg) const;
};
