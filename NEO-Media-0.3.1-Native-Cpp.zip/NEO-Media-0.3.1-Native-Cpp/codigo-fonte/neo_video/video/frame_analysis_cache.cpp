#include "frame_analysis_cache.hpp"

void FrameAnalysisCoordinator::reset() {
    motion_.reset();
    last_content_ = {};
    until_content_ = 0;
    frame_index_ = 0;
}

FrameAnalysisCache FrameAnalysisCoordinator::analyze(const uint8_t* y, int yStride,
                                                     const uint8_t* u, int uStride,
                                                     const uint8_t* v, int vStride,
                                                     int width, int height,
                                                     bool forceContent) {
    FrameAnalysisCache out;
    out.frame_index = frame_index_++;

    if (forceContent || until_content_ <= 0) {
        last_content_ = analyzer_.analyzeYuv420(y, yStride, u, uStride, v, vStride, width, height);
        until_content_ = content_interval_ - 1;
    } else {
        --until_content_;
    }

    out.content = last_content_;
    out.content_valid = true;
    out.motion = motion_.analyzeLuma(y, width, height, yStride);
    out.motion_valid = true;
    return out;
}
