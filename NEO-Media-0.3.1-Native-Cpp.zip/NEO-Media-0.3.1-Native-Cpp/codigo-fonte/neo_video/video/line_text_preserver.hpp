#pragma once
#include <cstdint>

struct LineTextStats {
    double thin_edge_ratio = 0.0;
    bool likely_text_or_graphics = false;
};

class LineTextPreserver {
public:
    LineTextStats analyze(const uint8_t* y, int width, int height, int stride) const;
    void restoreLuma(uint8_t* y, int width, int height, int stride,
                     double amount, const LineTextStats& stats) const;
};
