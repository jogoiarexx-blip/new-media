#pragma once
#include <cstdint>

class ChromaEnhancer {
public:
    void processPlane(uint8_t* c, int width, int height, int stride,
                      double denoiseStrength, double recoverStrength) const;
};
