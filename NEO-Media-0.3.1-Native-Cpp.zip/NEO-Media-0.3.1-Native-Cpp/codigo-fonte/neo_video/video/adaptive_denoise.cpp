#include "adaptive_denoise.hpp"
#include <cmath>
#include <algorithm>

DenoiseDecision AdaptiveDenoise::analyzeLuma(const uint8_t* y, int width, int height, int stride) const {
    DenoiseDecision d;
    if (!y || width < 8 || height < 8) return d;

    const int step = std::max(2, std::min(width, height) / 160);
    double accum = 0.0;
    long long samples = 0;

    for (int j = 1; j < height - 1; j += step) {
        const uint8_t* row = y + j * stride;
        const uint8_t* up  = y + (j - 1) * stride;
        const uint8_t* dn  = y + (j + 1) * stride;
        for (int i = 1; i < width - 1; i += step) {
            const int c = row[i];
            const int lap = 4*c - row[i-1] - row[i+1] - up[i] - dn[i];
            accum += std::abs(lap);
            ++samples;
        }
    }

    if (!samples) return d;
    const double roughness = accum / static_cast<double>(samples);
    d.estimated_noise = roughness;

    // Conservative thresholds to avoid smearing clean content.
    if (roughness > 18.0) {
        d.enabled = true;
        d.strength = std::clamp((roughness - 18.0) / 55.0, 0.08, 0.45);
    }
    return d;
}
