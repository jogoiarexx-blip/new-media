#include "line_text_preserver.hpp"
#include <vector>
#include <algorithm>
#include <cmath>

LineTextStats LineTextPreserver::analyze(const uint8_t* y, int width, int height, int stride) const {
    LineTextStats s;
    if (!y || width < 8 || height < 8) return s;

    const int step = std::max(1, std::min(width,height) / 240);
    long long thin = 0, samples = 0;

    for (int j=1;j<height-1;j+=step) {
        for (int i=1;i<width-1;i+=step) {
            int c = y[j*stride+i];
            int l = y[j*stride+i-1], r = y[j*stride+i+1];
            int u = y[(j-1)*stride+i], d = y[(j+1)*stride+i];

            const int h = std::abs(2*c - l - r);
            const int v = std::abs(2*c - u - d);
            if ((h > 32 && v < 18) || (v > 32 && h < 18))
                ++thin;
            ++samples;
        }
    }

    s.thin_edge_ratio = samples ? (double)thin / samples : 0.0;
    s.likely_text_or_graphics = s.thin_edge_ratio > 0.035;
    return s;
}

void LineTextPreserver::restoreLuma(uint8_t* y, int width, int height, int stride,
                                    double amount, const LineTextStats& stats) const {
    if (!y || !stats.likely_text_or_graphics || amount <= 0.0) return;

    std::vector<uint8_t> src((size_t)stride * height);
    for (int j=0;j<height;++j)
        std::copy(y+j*stride, y+j*stride+stride, src.data()+j*stride);

    const double a = std::clamp(amount, 0.0, 0.5);

    for (int j=1;j<height-1;++j) {
        for (int i=1;i<width-1;++i) {
            const int idx=j*stride+i;
            const int c=src[idx];
            const int l=src[idx-1], r=src[idx+1], u=src[idx-stride], d=src[idx+stride];

            const int h = 2*c-l-r;
            const int v = 2*c-u-d;

            int detail = 0;
            if (std::abs(h) > 28 && std::abs(v) < 20) detail = h;
            else if (std::abs(v) > 28 && std::abs(h) < 20) detail = v;
            else continue;

            const int out=(int)std::lround(c + detail*a*0.18);
            y[idx]=(uint8_t)std::clamp(out,0,255);
        }
    }
}
