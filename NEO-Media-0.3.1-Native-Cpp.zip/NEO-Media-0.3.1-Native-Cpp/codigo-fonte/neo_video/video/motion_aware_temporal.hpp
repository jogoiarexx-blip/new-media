#pragma once
#include <cstdint>
#include <vector>
#include "scene_motion_detector.hpp"

struct MotionTemporalConfig {
    double strength = 0.10;
    int pixel_threshold = 10;
};

class MotionAwareTemporal {
public:
    void reset();
    void processLuma(uint8_t* y, int width, int height, int stride,
                     const SceneMotionInfo& motion,
                     const MotionTemporalConfig& cfg);

private:
    std::vector<uint8_t> prev_;
    int prev_w_ = 0, prev_h_ = 0, prev_stride_ = 0;
};
