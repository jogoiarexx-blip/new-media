#include "edge_antialias.hpp"
#include <vector>
#include <algorithm>
#include <cmath>

void EdgeAntialias::processLuma(uint8_t* y, int width, int height, int stride, double strength) const {
    if (!y || width < 3 || height < 3 || strength <= 0.0) return;

    std::vector<uint8_t> src((size_t)stride * height);
    for (int j = 0; j < height; ++j)
        std::copy(y + j*stride, y + j*stride + stride, src.data() + j*stride);

    const double s = std::clamp(strength, 0.0, 1.0);

    for (int j = 1; j < height - 1; ++j) {
        for (int i = 1; i < width - 1; ++i) {
            const int idx = j*stride + i;

            const int gx =
                -src[(j-1)*stride+i-1] + src[(j-1)*stride+i+1] +
                -2*src[j*stride+i-1]   + 2*src[j*stride+i+1] +
                -src[(j+1)*stride+i-1] + src[(j+1)*stride+i+1];

            const int gy =
                -src[(j-1)*stride+i-1] - 2*src[(j-1)*stride+i] - src[(j-1)*stride+i+1] +
                 src[(j+1)*stride+i-1] + 2*src[(j+1)*stride+i] + src[(j+1)*stride+i+1];

            const int mag = std::abs(gx) + std::abs(gy);
            if (mag < 90) continue;

            const int c = src[idx];
            int n1, n2;
            if (std::abs(gx) > std::abs(gy)) {
                n1 = src[idx-1];
                n2 = src[idx+1];
            } else {
                n1 = src[idx-stride];
                n2 = src[idx+stride];
            }

            const int avg = (n1 + n2) / 2;
            if (std::abs(c - avg) < 20) continue;

            const double w = s * 0.18;
            const int out = (int)std::lround(c*(1.0-w) + avg*w);
            y[idx] = (uint8_t)std::clamp(out, 0, 255);
        }
    }
}
