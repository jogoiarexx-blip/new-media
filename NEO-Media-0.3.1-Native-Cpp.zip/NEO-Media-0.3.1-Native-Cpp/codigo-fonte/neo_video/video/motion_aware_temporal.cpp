#include "motion_aware_temporal.hpp"
#include <algorithm>
#include <cmath>

void MotionAwareTemporal::reset() {
    prev_.clear();
    prev_w_ = prev_h_ = prev_stride_ = 0;
}

void MotionAwareTemporal::processLuma(uint8_t* y, int width, int height, int stride,
                                     const SceneMotionInfo& motion,
                                     const MotionTemporalConfig& cfg) {
    if (!y || width <= 0 || height <= 0 || stride <= 0) return;

    const std::size_t bytes = static_cast<std::size_t>(stride) * height;

    if (motion.scene_cut) {
        prev_.assign(y, y + bytes);
        prev_w_ = width; prev_h_ = height; prev_stride_ = stride;
        return;
    }

    if (prev_.size() != bytes || prev_w_ != width || prev_h_ != height || prev_stride_ != stride) {
        prev_.assign(y, y + bytes);
        prev_w_ = width; prev_h_ = height; prev_stride_ = stride;
        return;
    }

    double base = std::clamp(cfg.strength, 0.0, 0.35);
    if (motion.high_motion) base *= 0.35;

    for (int j = 0; j < height; ++j) {
        uint8_t* row = y + j * stride;
        uint8_t* prow = prev_.data() + j * stride;
        for (int i = 0; i < width; ++i) {
            const int cur = row[i];
            const int old = prow[i];
            const int diff = std::abs(cur - old);

            double w = 0.0;
            if (diff <= cfg.pixel_threshold) {
                w = base * (1.0 - (double)diff / (cfg.pixel_threshold + 1.0));
            }

            const int out = (int)std::lround(cur * (1.0 - w) + old * w);
            row[i] = (uint8_t)std::clamp(out, 0, 255);
            prow[i] = row[i];
        }
    }
}
