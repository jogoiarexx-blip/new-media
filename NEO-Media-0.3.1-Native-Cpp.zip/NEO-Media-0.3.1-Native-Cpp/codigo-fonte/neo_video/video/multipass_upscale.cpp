#include "multipass_upscale.hpp"
#include <algorithm>
#include <cmath>

UpscalePlan MultiPassUpscale::plan(int inW, int inH, int outW, int outH, bool highQuality) const {
    UpscalePlan p;
    p.pass1_w = outW;
    p.pass1_h = outH;
    p.pass2_w = outW;
    p.pass2_h = outH;

    if (inW <= 0 || inH <= 0 || outW <= 0 || outH <= 0) return p;

    const double sx = static_cast<double>(outW) / inW;
    const double sy = static_cast<double>(outH) / inH;
    const double scale = std::max(sx, sy);

    if (highQuality && scale > 1.85) {
        p.pass_count = 2;
        const double midScale = std::sqrt(scale);
        p.pass1_w = std::max(inW + 1, static_cast<int>(std::lround(inW * midScale)));
        p.pass1_h = std::max(inH + 1, static_cast<int>(std::lround(inH * midScale)));
        p.pass2_w = outW;
        p.pass2_h = outH;
        p.detail_reconstruction = true;
    } else {
        p.pass_count = 1;
        p.detail_reconstruction = highQuality && scale > 1.2;
    }

    return p;
}
