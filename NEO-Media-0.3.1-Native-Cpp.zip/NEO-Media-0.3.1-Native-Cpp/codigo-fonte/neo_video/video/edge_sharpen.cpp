#include "edge_sharpen.hpp"
#include <vector>
#include <algorithm>
#include <cmath>

void EdgeSharpen::processLuma(uint8_t* y, int width, int height, int stride, double amount) const {
    if (!y || width < 3 || height < 3 || amount <= 0.0) return;

    std::vector<uint8_t> src(static_cast<std::size_t>(stride) * height);
    for (int j = 0; j < height; ++j)
        std::copy(y + j*stride, y + j*stride + stride, src.data() + j*stride);

    const double a = std::clamp(amount, 0.0, 1.0);

    for (int j = 1; j < height - 1; ++j) {
        for (int i = 1; i < width - 1; ++i) {
            const int idx = j*stride + i;
            const int c = src[idx];
            const int avg = (
                src[idx-1] + src[idx+1] +
                src[idx-stride] + src[idx+stride]
            ) / 4;

            const int edge = c - avg;
            const int localContrast =
                std::max({std::abs(c-src[idx-1]), std::abs(c-src[idx+1]),
                          std::abs(c-src[idx-stride]), std::abs(c-src[idx+stride])});

            // Strong edges receive less boost to reduce halos/ringing.
            const double haloGuard = localContrast > 40 ? 0.45 : (localContrast > 22 ? 0.70 : 1.0);
            const int out = static_cast<int>(std::lround(c + edge * a * haloGuard));
            y[idx] = static_cast<uint8_t>(std::clamp(out, 0, 255));
        }
    }
}
