#pragma once
#include "anti_ringing.hpp"
#include "edge_antialias.hpp"
#include "line_text_preserver.hpp"

struct PostUpscaleConfig {
    double anti_ringing = 0.30;
    double anti_alias = 0.18;
    double text_restore = 0.18;
};

class PostUpscaleCleanup {
public:
    void processLuma(uint8_t* y, int width, int height, int stride,
                     const PostUpscaleConfig& cfg);

private:
    AntiRinging anti_ringing_;
    EdgeAntialias anti_alias_;
    LineTextPreserver text_;
};
