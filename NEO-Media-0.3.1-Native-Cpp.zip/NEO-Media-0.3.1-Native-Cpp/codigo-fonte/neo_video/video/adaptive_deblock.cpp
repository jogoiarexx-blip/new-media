#include "adaptive_deblock.hpp"
#include <algorithm>
#include <cmath>

void AdaptiveDeblock::processLuma(uint8_t* y, int width, int height, int stride, double strength) const {
    if (!y || width < 16 || height < 16 || strength <= 0.0) return;
    const double s = std::clamp(strength, 0.0, 1.0);

    // Smooth only across likely 8x8 block boundaries and only when the boundary
    // discontinuity is modest enough to look like compression, not a real edge.
    for (int x = 8; x < width; x += 8) {
        for (int j = 1; j < height-1; ++j) {
            int a = y[j*stride + x-1];
            int b = y[j*stride + x];
            int diff = std::abs(a-b);
            if (diff >= 3 && diff <= 24) {
                int avg = (a+b)/2;
                y[j*stride+x-1] = (uint8_t)std::clamp((int)std::lround(a*(1.0-s*0.35)+avg*(s*0.35)),0,255);
                y[j*stride+x]   = (uint8_t)std::clamp((int)std::lround(b*(1.0-s*0.35)+avg*(s*0.35)),0,255);
            }
        }
    }

    for (int j = 8; j < height; j += 8) {
        for (int x = 1; x < width-1; ++x) {
            int a = y[(j-1)*stride + x];
            int b = y[j*stride + x];
            int diff = std::abs(a-b);
            if (diff >= 3 && diff <= 24) {
                int avg = (a+b)/2;
                y[(j-1)*stride+x] = (uint8_t)std::clamp((int)std::lround(a*(1.0-s*0.35)+avg*(s*0.35)),0,255);
                y[j*stride+x]     = (uint8_t)std::clamp((int)std::lround(b*(1.0-s*0.35)+avg*(s*0.35)),0,255);
            }
        }
    }
}
