#pragma once
#include <cstdint>

class AntiRinging {
public:
    void processLuma(uint8_t* y, int width, int height, int stride, double strength) const;
};
