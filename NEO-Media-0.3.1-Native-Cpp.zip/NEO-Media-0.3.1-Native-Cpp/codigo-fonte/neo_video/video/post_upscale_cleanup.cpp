#include "post_upscale_cleanup.hpp"

void PostUpscaleCleanup::processLuma(uint8_t* y, int width, int height, int stride,
                                     const PostUpscaleConfig& cfg) {
    if (!y) return;

    auto stats = text_.analyze(y, width, height, stride);

    if (cfg.anti_ringing > 0.0)
        anti_ringing_.processLuma(y, width, height, stride, cfg.anti_ringing);

    if (cfg.anti_alias > 0.0)
        anti_alias_.processLuma(y, width, height, stride, cfg.anti_alias);

    if (cfg.text_restore > 0.0)
        text_.restoreLuma(y, width, height, stride, cfg.text_restore, stats);
}
