#pragma once
#include <cstdint>
#include <vector>

struct SceneMotionInfo {
    double motion_score = 0.0;
    double scene_change_score = 0.0;
    bool scene_cut = false;
    bool high_motion = false;
};

class SceneMotionDetector {
public:
    SceneMotionInfo analyzeLuma(const uint8_t* y, int width, int height, int stride);
    void reset();

private:
    std::vector<uint8_t> prev_;
    int prev_w_ = 0;
    int prev_h_ = 0;
    int prev_stride_ = 0;
};
