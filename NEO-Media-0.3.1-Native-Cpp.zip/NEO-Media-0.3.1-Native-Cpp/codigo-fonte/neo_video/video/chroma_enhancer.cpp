#include "chroma_enhancer.hpp"
#include <vector>
#include <algorithm>
#include <cmath>

void ChromaEnhancer::processPlane(uint8_t* c, int width, int height, int stride,
                                  double denoiseStrength, double recoverStrength) const {
    if (!c || width < 3 || height < 3) return;

    std::vector<uint8_t> src((size_t)stride * height);
    for (int j=0;j<height;++j)
        std::copy(c+j*stride, c+j*stride+stride, src.data()+j*stride);

    const double dn = std::clamp(denoiseStrength, 0.0, 0.5);
    const double rec = std::clamp(recoverStrength, 0.0, 0.35);

    for (int j=1;j<height-1;++j) {
        for (int x=1;x<width-1;++x) {
            const int idx=j*stride+x;
            const int center=src[idx];
            const int avg=(src[idx-1]+src[idx+1]+src[idx-stride]+src[idx+stride]+4*center)/8;
            const int residual=center-avg;
            double out=center*(1.0-dn)+avg*dn + residual*rec;
            c[idx]=(uint8_t)std::clamp((int)std::lround(out),0,255);
        }
    }
}
