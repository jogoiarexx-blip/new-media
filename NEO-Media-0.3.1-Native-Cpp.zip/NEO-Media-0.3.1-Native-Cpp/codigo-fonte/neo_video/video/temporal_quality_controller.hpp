#pragma once

struct TemporalQuality {
    bool enabled = true;
    double denoise_strength = 0.10;
    double deband_strength = 0.08;
    int motion_threshold = 12;
};

class TemporalQualityController {
public:
    TemporalQuality choose(double frameMs, double budgetMs, double droppedPercent, bool highQualityMode) const;
};
