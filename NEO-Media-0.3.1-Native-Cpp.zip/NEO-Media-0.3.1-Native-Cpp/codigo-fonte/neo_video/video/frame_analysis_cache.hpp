#pragma once
#include "content_analyzer.hpp"
#include "scene_motion_detector.hpp"

struct FrameAnalysisCache {
    ContentAnalysis content{};
    SceneMotionInfo motion{};
    bool content_valid = false;
    bool motion_valid = false;
    long long frame_index = 0;
};

class FrameAnalysisCoordinator {
public:
    void reset();
    FrameAnalysisCache analyze(const uint8_t* y, int yStride,
                               const uint8_t* u, int uStride,
                               const uint8_t* v, int vStride,
                               int width, int height,
                               bool forceContent = false);

private:
    ContentAnalyzer analyzer_;
    SceneMotionDetector motion_;
    ContentAnalysis last_content_{};
    int content_interval_ = 12;
    int until_content_ = 0;
    long long frame_index_ = 0;
};
