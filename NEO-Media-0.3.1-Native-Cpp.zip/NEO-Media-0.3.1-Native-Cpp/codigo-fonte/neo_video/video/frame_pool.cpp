#include "frame_pool.hpp"
#include <algorithm>

FramePool::FramePool(std::size_t reserve) {
    free_.reserve(reserve);
    all_.reserve(reserve);
    for (std::size_t i = 0; i < reserve; ++i) {
        AVFrame* f = av_frame_alloc();
        if (f) {
            free_.push_back(f);
            all_.push_back(f);
        }
    }
}

FramePool::~FramePool() {
    for (AVFrame* f : all_) {
        av_frame_free(&f);
    }
}

AVFrame* FramePool::acquire() {
    if (!free_.empty()) {
        AVFrame* f = free_.back();
        free_.pop_back();
        av_frame_unref(f);
        return f;
    }
    AVFrame* f = av_frame_alloc();
    if (f) all_.push_back(f);
    return f;
}

void FramePool::release(AVFrame* frame) {
    if (!frame) return;
    av_frame_unref(frame);
    if (std::find(free_.begin(), free_.end(), frame) == free_.end())
        free_.push_back(frame);
}
