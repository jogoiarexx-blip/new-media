#pragma once
#include <cstdint>

class EdgeSharpen {
public:
    void processLuma(uint8_t* y, int width, int height, int stride, double amount) const;
};
