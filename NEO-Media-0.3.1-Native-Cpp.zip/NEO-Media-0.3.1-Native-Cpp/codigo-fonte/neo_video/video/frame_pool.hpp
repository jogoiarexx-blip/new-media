#pragma once
extern "C" {
#include <libavutil/frame.h>
}
#include <vector>
#include <memory>

class FramePool {
public:
    explicit FramePool(std::size_t reserve = 8);
    ~FramePool();

    AVFrame* acquire();
    void release(AVFrame* frame);
    std::size_t cached() const { return free_.size(); }

private:
    std::vector<AVFrame*> free_;
    std::vector<AVFrame*> all_;
};
