#pragma once
#include <cstdint>

struct ContentAnalysis {
    double blockiness = 0.0;
    double luma_noise = 0.0;
    double chroma_noise = 0.0;
    double banding = 0.0;
    double edge_density = 0.0;
    bool likely_compressed = false;
    bool likely_clean = false;
};

class ContentAnalyzer {
public:
    ContentAnalysis analyzeYuv420(const uint8_t* y, int yStride,
                                  const uint8_t* u, int uStride,
                                  const uint8_t* v, int vStride,
                                  int width, int height) const;
};
