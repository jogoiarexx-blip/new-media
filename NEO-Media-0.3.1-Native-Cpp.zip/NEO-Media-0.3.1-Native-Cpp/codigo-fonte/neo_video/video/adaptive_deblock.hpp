#pragma once
#include <cstdint>

class AdaptiveDeblock {
public:
    void processLuma(uint8_t* y, int width, int height, int stride, double strength) const;
};
