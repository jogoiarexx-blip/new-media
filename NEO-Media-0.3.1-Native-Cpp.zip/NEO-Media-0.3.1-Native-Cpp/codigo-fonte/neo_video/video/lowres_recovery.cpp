#include "lowres_recovery.hpp"
#include <vector>
#include <algorithm>
#include <cmath>

bool LowResRecovery::shouldUse(int width, int height) const {
    return width <= 1280 && height <= 720;
}

void LowResRecovery::processLuma(uint8_t* y, int width, int height, int stride,
                                 const LowResRecoveryConfig& cfg) const {
    if (!y || !shouldUse(width, height) || width < 5 || height < 5) return;

    std::vector<uint8_t> src((size_t)stride * height);
    for (int j=0;j<height;++j)
        std::copy(y+j*stride, y+j*stride+stride, src.data()+j*stride);

    const double rec = std::clamp(cfg.texture_recovery, 0.0, 0.35);
    const double deb = std::clamp(cfg.deblock_strength, 0.0, 0.5);
    const int softThreshold = cfg.aggressive ? 28 : 20;

    for (int j=2;j<height-2;++j) {
        for (int i=2;i<width-2;++i) {
            const int idx=j*stride+i;
            const int c=src[idx];
            const int cross=(src[idx-1]+src[idx+1]+src[idx-stride]+src[idx+stride])/4;
            const int far=(src[idx-2]+src[idx+2]+src[idx-2*stride]+src[idx+2*stride])/4;

            const int localDiff = std::max({
                std::abs(c-src[idx-1]), std::abs(c-src[idx+1]),
                std::abs(c-src[idx-stride]), std::abs(c-src[idx+stride])
            });

            double out = c;

            if ((i % 8 == 0 || j % 8 == 0) && localDiff < softThreshold) {
                out = out*(1.0-deb*0.25) + cross*(deb*0.25);
            }

            const int detail = c - cross;
            const int mid = cross - far;
            const double guard = localDiff > 36 ? 0.35 : 1.0;
            out += guard * rec * (0.70*detail + 0.30*mid);

            y[idx]=(uint8_t)std::clamp((int)std::lround(out),0,255);
        }
    }
}
