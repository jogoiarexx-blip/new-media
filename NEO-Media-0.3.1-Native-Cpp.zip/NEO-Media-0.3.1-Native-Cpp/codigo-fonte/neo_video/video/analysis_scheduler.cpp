#include "analysis_scheduler.hpp"

bool AnalysisScheduler::shouldAnalyze() {
    if (counter_ <= 0) {
        counter_ = interval_ - 1;
        return true;
    }
    --counter_;
    return false;
}

void AnalysisScheduler::submit(const ContentAnalysis& a) {
    latest_ = a;
}
