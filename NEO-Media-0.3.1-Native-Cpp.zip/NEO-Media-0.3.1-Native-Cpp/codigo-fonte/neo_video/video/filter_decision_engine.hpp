#pragma once
#include "content_analyzer.hpp"

struct FilterDecision {
    bool deblock = false;
    bool denoise = false;
    bool temporal = false;
    bool chroma_enhance = false;
    bool deband = false;
    bool detail_reconstruct = false;
    double deblock_strength = 0.0;
    double denoise_strength = 0.0;
    double chroma_denoise = 0.0;
    double chroma_recover = 0.0;
    double deband_strength = 0.0;
};

class FilterDecisionEngine {
public:
    FilterDecision decide(const ContentAnalysis& a,
                          double frameMs,
                          double budgetMs,
                          bool highQualityMode) const;
};
