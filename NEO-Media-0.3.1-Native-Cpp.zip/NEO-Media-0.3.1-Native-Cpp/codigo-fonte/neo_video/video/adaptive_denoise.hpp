#pragma once
#include <cstdint>

struct DenoiseDecision {
    double strength = 0.0;
    bool enabled = false;
    double estimated_noise = 0.0;
};

class AdaptiveDenoise {
public:
    DenoiseDecision analyzeLuma(const uint8_t* y, int width, int height, int stride) const;
};
