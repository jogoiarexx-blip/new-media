#include "content_analyzer.hpp"
#include <algorithm>
#include <cmath>

static double sampleNoise(const uint8_t* p, int stride, int w, int h) {
    if (!p || w < 4 || h < 4) return 0.0;
    const int step = std::max(2, std::min(w,h) / 128);
    double acc = 0.0; long long n = 0;
    for (int y=1; y<h-1; y+=step) {
        for (int x=1; x<w-1; x+=step) {
            const int c = p[y*stride+x];
            const int lap = 4*c - p[y*stride+x-1] - p[y*stride+x+1]
                            - p[(y-1)*stride+x] - p[(y+1)*stride+x];
            acc += std::abs(lap);
            ++n;
        }
    }
    return n ? acc / n : 0.0;
}

ContentAnalysis ContentAnalyzer::analyzeYuv420(const uint8_t* y, int yStride,
                                               const uint8_t* u, int uStride,
                                               const uint8_t* v, int vStride,
                                               int width, int height) const {
    ContentAnalysis a;
    if (!y || width < 16 || height < 16) return a;

    const int step = std::max(4, std::min(width,height) / 160);
    double block = 0.0, nonblock = 0.0, band = 0.0, edges = 0.0;
    long long bn = 0, nn = 0, bandn = 0, en = 0;

    for (int yy=1; yy<height-1; yy+=step) {
        const uint8_t* row = y + yy*yStride;
        for (int x=1; x<width-1; x+=step) {
            const int dx = std::abs((int)row[x] - (int)row[x-1]);
            const int dy = std::abs((int)y[yy*yStride+x] - (int)y[(yy-1)*yStride+x]);

            if (x % 8 == 0 || yy % 8 == 0) { block += dx + dy; ++bn; }
            else { nonblock += dx + dy; ++nn; }

            if (dx <= 2 && dy <= 2) { band += 1.0; ++bandn; }
            if (dx + dy > 24) edges += 1.0;
            ++en;
        }
    }

    const double b = bn ? block/bn : 0.0;
    const double nb = nn ? nonblock/nn : 1.0;
    a.blockiness = std::max(0.0, b - nb);
    a.luma_noise = sampleNoise(y, yStride, width, height);

    const int cw = width / 2, ch = height / 2;
    const double un = sampleNoise(u, uStride, cw, ch);
    const double vn = sampleNoise(v, vStride, cw, ch);
    a.chroma_noise = (un + vn) * 0.5;

    a.banding = en ? band / en : 0.0;
    a.edge_density = en ? edges / en : 0.0;

    a.likely_compressed = a.blockiness > 4.0 || a.chroma_noise > 16.0 || a.banding > 0.35;
    a.likely_clean = !a.likely_compressed && a.luma_noise < 14.0 && a.chroma_noise < 12.0;
    return a;
}
