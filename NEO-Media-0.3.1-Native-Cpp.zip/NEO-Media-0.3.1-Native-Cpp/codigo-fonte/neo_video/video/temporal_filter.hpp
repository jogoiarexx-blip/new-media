#pragma once
#include <cstdint>
#include <vector>

struct TemporalFilterConfig {
    double denoise_strength = 0.10;
    double deband_strength = 0.08;
    int motion_threshold = 12;
};

class TemporalFilter {
public:
    void reset();
    void processLuma(uint8_t* y, int width, int height, int stride, const TemporalFilterConfig& cfg);

private:
    std::vector<uint8_t> prev_;
    int prev_w_ = 0;
    int prev_h_ = 0;
    int prev_stride_ = 0;
};
