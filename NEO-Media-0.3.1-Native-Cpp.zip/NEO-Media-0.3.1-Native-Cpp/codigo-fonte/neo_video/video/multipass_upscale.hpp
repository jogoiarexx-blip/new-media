#pragma once

struct UpscalePlan {
    int pass_count = 1;
    int pass1_w = 0, pass1_h = 0;
    int pass2_w = 0, pass2_h = 0;
    bool detail_reconstruction = false;
};

class MultiPassUpscale {
public:
    UpscalePlan plan(int inW, int inH, int outW, int outH, bool highQuality) const;
};
