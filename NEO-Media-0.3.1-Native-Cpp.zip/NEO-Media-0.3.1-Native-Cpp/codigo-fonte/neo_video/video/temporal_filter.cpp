#include "temporal_filter.hpp"
#include <algorithm>
#include <cmath>

void TemporalFilter::reset() {
    prev_.clear();
    prev_w_ = prev_h_ = prev_stride_ = 0;
}

void TemporalFilter::processLuma(uint8_t* y, int width, int height, int stride, const TemporalFilterConfig& cfg) {
    if (!y || width <= 0 || height <= 0 || stride <= 0) return;

    const std::size_t bytes = static_cast<std::size_t>(stride) * height;
    if (prev_.size() != bytes || prev_w_ != width || prev_h_ != height || prev_stride_ != stride) {
        prev_.assign(y, y + bytes);
        prev_w_ = width;
        prev_h_ = height;
        prev_stride_ = stride;
        return;
    }

    const double dn = std::clamp(cfg.denoise_strength, 0.0, 0.45);
    const double db = std::clamp(cfg.deband_strength, 0.0, 0.30);
    const int motionT = std::max(1, cfg.motion_threshold);

    for (int j = 0; j < height; ++j) {
        uint8_t* row = y + j*stride;
        uint8_t* prow = prev_.data() + j*stride;

        for (int i = 0; i < width; ++i) {
            const int cur = row[i];
            const int old = prow[i];
            const int diff = std::abs(cur - old);

            int out = cur;
            if (diff <= motionT) {
                const double w = dn * (1.0 - static_cast<double>(diff) / (motionT + 1.0));
                out = static_cast<int>(std::lround(cur * (1.0 - w) + old * w));

                // Very small differences are often banding/noise; gently smooth them.
                if (diff <= 2 && db > 0.0) {
                    out = static_cast<int>(std::lround(out * (1.0 - db) + old * db));
                }
            }

            row[i] = static_cast<uint8_t>(std::clamp(out, 0, 255));
            prow[i] = row[i];
        }
    }
}
