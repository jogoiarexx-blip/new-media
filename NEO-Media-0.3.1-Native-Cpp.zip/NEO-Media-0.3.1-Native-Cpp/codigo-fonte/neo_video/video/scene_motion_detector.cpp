#include "scene_motion_detector.hpp"
#include <algorithm>
#include <cmath>

void SceneMotionDetector::reset() {
    prev_.clear();
    prev_w_ = prev_h_ = prev_stride_ = 0;
}

SceneMotionInfo SceneMotionDetector::analyzeLuma(const uint8_t* y, int width, int height, int stride) {
    SceneMotionInfo info;
    if (!y || width <= 0 || height <= 0 || stride <= 0) return info;

    const std::size_t bytes = static_cast<std::size_t>(stride) * height;
    if (prev_.size() != bytes || prev_w_ != width || prev_h_ != height || prev_stride_ != stride) {
        prev_.assign(y, y + bytes);
        prev_w_ = width;
        prev_h_ = height;
        prev_stride_ = stride;
        return info;
    }

    const int step = std::max(2, std::min(width, height) / 160);
    double diff_acc = 0.0;
    double changed = 0.0;
    double samples = 0.0;

    for (int j = 0; j < height; j += step) {
        for (int i = 0; i < width; i += step) {
            const int idx = j * stride + i;
            const int d = std::abs((int)y[idx] - (int)prev_[idx]);
            diff_acc += d;
            if (d > 24) changed += 1.0;
            samples += 1.0;
        }
    }

    const double meanDiff = samples > 0.0 ? diff_acc / samples : 0.0;
    const double changedRatio = samples > 0.0 ? changed / samples : 0.0;

    info.motion_score = meanDiff;
    info.scene_change_score = changedRatio;
    info.scene_cut = meanDiff > 28.0 && changedRatio > 0.55;
    info.high_motion = meanDiff > 14.0 || changedRatio > 0.25;

    prev_.assign(y, y + bytes);
    return info;
}
