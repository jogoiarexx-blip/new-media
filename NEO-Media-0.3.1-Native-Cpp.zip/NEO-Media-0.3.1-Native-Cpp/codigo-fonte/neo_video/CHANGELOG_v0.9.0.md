# Changelog v0.9.0

- Added GPU capability abstraction.
- Added NVIDIA/AMD/Intel backend selection.
- Added automatic CPU fallback.
- Split decode and encode hardware preferences.
- Added documentation for HW-accelerated realtime and export paths.
- Kept CPU enhancement filters as the compatibility baseline.
- Prepared the project for actual FFmpeg hwdevice integration in v0.10.0.
