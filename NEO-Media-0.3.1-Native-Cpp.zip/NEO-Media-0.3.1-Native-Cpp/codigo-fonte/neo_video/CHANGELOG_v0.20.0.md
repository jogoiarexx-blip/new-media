# Changelog v0.20.0

- Consolidated previously disconnected graphics modules into active FrameProcessor.
- Fixed CMake source integration.
- Updated project/application version strings to 0.20.0.
- Added low-resolution pre-upscale recovery to active path.
- Added source-aware deblock/chroma decisions to active path.
- Added multi-pass upscale and detail reconstruction to active path.
- Added scene/motion-aware temporal processing to active path.
- Added anti-ringing, anti-alias and line/text preservation to active path.
- Replaced generic unsharp with edge-aware sharpen.
- Moved GPU modules behind an explicit experimental build option until end-to-end validated.
