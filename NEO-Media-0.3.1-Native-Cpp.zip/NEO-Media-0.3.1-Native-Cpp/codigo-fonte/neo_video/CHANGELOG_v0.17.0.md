# Changelog v0.17.0

- Added source content analyzer.
- Added adaptive 8x8 deblocking.
- Added chroma enhancement/cleanup.
- Added dynamic filter decision engine.
- Added periodic analysis scheduler.
- Added automatic performance fallback for expensive cleanup filters.
