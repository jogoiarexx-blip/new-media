# Changelog v0.16.0

- Added multi-pass upscale planning.
- Added luma detail reconstruction.
- Added lightweight temporal denoise/deband.
- Added motion threshold to protect moving detail.
- Added automatic temporal filter disable under load.
