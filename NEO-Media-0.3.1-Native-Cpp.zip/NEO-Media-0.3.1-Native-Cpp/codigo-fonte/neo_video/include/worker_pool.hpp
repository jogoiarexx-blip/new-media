#pragma once
#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <functional>
#include <future>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>

class WorkerPool {
public:
    explicit WorkerPool(unsigned threads = 0);
    ~WorkerPool();
    WorkerPool(const WorkerPool&) = delete;
    WorkerPool& operator=(const WorkerPool&) = delete;

    unsigned threadCount() const { return static_cast<unsigned>(workers_.size()); }
    void parallelFor(int begin, int end, int minRows, const std::function<void(int,int)>& fn);

private:
    void loop();
    std::vector<std::thread> workers_;
    std::queue<std::function<void()>> tasks_;
    std::mutex mutex_;
    std::condition_variable cv_;
    bool stop_ = false;
};
