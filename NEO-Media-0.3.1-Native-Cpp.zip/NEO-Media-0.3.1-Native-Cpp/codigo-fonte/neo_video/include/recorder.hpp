#pragma once
extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/audio_fifo.h>
#include <libavutil/frame.h>
#include <libswresample/swresample.h>
}
#include <string>

struct RecorderOptions {
    int bitrate = 8'000'000;
    int crf = 18;
    std::string preset = "veryfast";
    int audioBitrate = 192'000;
    int audioSampleRate = 48000;
};

class Recorder {
public:
    ~Recorder();
    bool start(const std::string& path, int width, int height, AVRational fps, bool enableAudio, const RecorderOptions& options = {});
    bool writeVideo(const AVFrame* yuv420pFrame, int64_t pts);
    bool writeAudio(const AVFrame* decodedFrame);
    void stop();
    bool active() const { return started_; }
    bool audioEnabled() const { return audioEnc_ != nullptr; }
    const std::string& path() const { return path_; }
private:
    bool initAudioEncoder(const RecorderOptions& options);
    bool ensureAudioResampler(const AVFrame* frame);
    bool encodeAudioFromFifo(bool flushAll);
    bool writeEncodedPacket(AVCodecContext* enc, AVStream* stream, AVPacket* pkt);
    void cleanup(bool writeTrailer);

    AVFormatContext* fmt_ = nullptr;
    AVCodecContext* videoEnc_ = nullptr;
    AVCodecContext* audioEnc_ = nullptr;
    AVStream* videoStream_ = nullptr;
    AVStream* audioStream_ = nullptr;
    SwrContext* audioSwr_ = nullptr;
    AVAudioFifo* audioFifo_ = nullptr;
    AVChannelLayout audioInLayout_{};
    bool haveAudioInLayout_ = false;
    int audioInRate_ = 0;
    int audioInFormat_ = -1;
    int64_t audioPts_ = 0;
    bool started_ = false;
    bool wantAudio_ = false;
    std::string path_;
};
