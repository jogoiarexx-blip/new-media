#pragma once
#include "frame_processor.hpp"
#include "recorder.hpp"
#include <string>
#include <cstdint>

struct PlayerOptions {
    std::string input;
    bool ipc = false;
    bool startPaused = false;
    int audioStream = -1;
    double startSeconds = 0;
    std::string audioDevice;
    uintptr_t windowId = 0;
    std::string recordPath;
    int upscaleW = 0;
    int upscaleH = 0;
    bool autoPerformance = true;
    bool startMuted = false;
    float volume = 1.0f;
    QualityPreset preset = QualityPreset::Balanced;
    std::string aiModel;
    int aiTile = 192;
    bool aiEnabled = false;
};

class VideoPlayer {
public:
    int run(const PlayerOptions& options);
};
