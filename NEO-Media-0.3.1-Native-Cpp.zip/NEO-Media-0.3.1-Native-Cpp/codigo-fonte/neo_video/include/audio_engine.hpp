#pragma once
#include <SDL.h>
extern "C" {
#include <libavutil/frame.h>
#include <libswresample/swresample.h>
}
#include <cstdint>

class AudioEngine {
public:
    ~AudioEngine();
    bool open(int sampleRate = 48000, int channels = 2, const char* device = nullptr);
    bool queue(const AVFrame* frame, double ptsSeconds);
    void setPaused(bool paused);
    void setVolume(float volume);
    void toggleMute();
    float volume() const { return volume_; }
    bool muted() const { return muted_; }
    double clockSeconds() const;
    double queuedSeconds() const;
    void clear();
    void close();
    bool active() const { return device_ != 0; }
private:
    bool ensureResampler(const AVFrame* frame);
    SDL_AudioDeviceID device_ = 0;
    SDL_AudioSpec obtained_{};
    SwrContext* swr_ = nullptr;
    int inRate_ = 0;
    int inFormat_ = -1;
    AVChannelLayout inLayout_{};
    bool haveInLayout_ = false;
    float volume_ = 1.0f;
    bool muted_ = false;
    int64_t submittedFrames_ = 0;
    double firstPts_ = 0.0;
    bool haveFirstPts_ = false;
};
