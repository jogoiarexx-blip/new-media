#pragma once
#include "frame_processor.hpp"
#include "recorder.hpp"
#include "ai_upscaler.hpp"
#include <string>

struct ExportOptions {
    std::string input;
    std::string output;
    int targetW = 0;
    int targetH = 0;
    QualityPreset preset = QualityPreset::Ultra;
    std::string aiModel;
    int aiTile = 192;
    bool useAi = false;
    bool copyAudio = true;
    int crf = 16;
    std::string encoderPreset = "slow";
    int bitrate = 12'000'000;
    float brightness = 0.0f;
    float contrast = 1.07f;
    float saturation = 1.05f;
    float gamma = 1.0f;
    float sharpen = 0.30f;
    float denoise = 0.20f;
    float deband = 0.18f;
};

struct ExportStats {
    int64_t videoFrames = 0;
    int64_t audioFrames = 0;
    int64_t aiFrames = 0;
    double elapsedSeconds = 0.0;
    double sourceSeconds = 0.0;
};

class OfflineExporter {
public:
    int run(const ExportOptions& options);
    const ExportStats& stats() const { return stats_; }
private:
    ExportStats stats_{};
};
