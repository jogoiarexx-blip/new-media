#pragma once
#include <SDL.h>
#include <string>

struct UiState {
    bool paused=false, enhance=true, compare=false, recording=false, muted=false, autoPerformance=true, ai=false;
    float volume=1.0f, brightness=0.0f, contrast=1.06f, saturation=1.06f, gamma=1.0f, sharpen=0.25f, denoise=0.15f, deband=0.10f;
    double position=0.0, duration=0.0, processMs=0.0;
    std::string preset="BALANCED", imagePreset="NATURAL", resolution="", cpu="", aiStatus="AI OFF";
};

enum class UiActionType { None, TogglePause, ToggleEnhance, ToggleCompare, ToggleRecord, ToggleMute,
    ToggleAutoPerformance, NextPreset, NextImagePreset, ToggleFullscreen, Seek, SetVolume,
    SetBrightness, SetContrast, SetSaturation, SetGamma, SetSharpen, SetDenoise, SetDeband, ResetImage, ToggleAI };
struct UiAction { UiActionType type=UiActionType::None; double value=0.0; };

class UiOverlay {
public:
    void draw(SDL_Renderer*,int,int,const UiState&);
    UiAction hitTest(int,int,int,int,const UiState&) const;
    int reservedBottom() const { return 232; }
private:
    SDL_Rect timelineRect(int,int) const;
    SDL_Rect volumeRect(int,int) const;
};
