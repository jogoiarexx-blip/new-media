#pragma once
#include "frame_processor.hpp"
#include <memory>
#include <string>
#include <vector>

struct AiUpscaleInfo {
    bool compiled = false;
    bool modelLoaded = false;
    bool active = false;
    std::string backend = "disabled";
    std::string model;
    int scale = 1;
    int tile = 0;
    double lastMs = 0.0;
};

class AiUpscaler {
public:
    AiUpscaler();
    ~AiUpscaler();
    AiUpscaler(const AiUpscaler&) = delete;
    AiUpscaler& operator=(const AiUpscaler&) = delete;

    bool load(const std::string& modelPath, int tile = 192);
    void unload();
    FramePtr upscale(const AVFrame* src, int targetW, int targetH);
    void setEnabled(bool enabled) { enabled_ = enabled; info_.active = enabled && info_.modelLoaded; }
    bool enabled() const { return enabled_; }
    const AiUpscaleInfo& info() const { return info_; }
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
    AiUpscaleInfo info_;
    bool enabled_ = false;
};
