#pragma once
#include "worker_pool.hpp"
#include "../video/content_analyzer.hpp"
#include "../video/adaptive_deblock.hpp"
#include "../video/chroma_enhancer.hpp"
#include "../video/filter_decision_engine.hpp"
#include "../video/analysis_scheduler.hpp"
#include "../video/adaptive_denoise.hpp"
#include "../video/edge_sharpen.hpp"
#include "../video/multipass_upscale.hpp"
#include "../video/detail_reconstruction.hpp"
#include "../video/scene_motion_detector.hpp"
#include "../video/motion_aware_temporal.hpp"
#include "../video/lowres_recovery.hpp"
#include "../video/pre_upscale_recovery.hpp"
#include "../video/post_upscale_cleanup.hpp"
#include "../video/frame_analysis_cache.hpp"

extern "C" {
#include <libavutil/frame.h>
#include <libavutil/pixfmt.h>
#include <libswscale/swscale.h>
}
#include <memory>

struct FrameDeleter { void operator()(AVFrame* f) const { if (f) av_frame_free(&f); } };
using FramePtr = std::unique_ptr<AVFrame, FrameDeleter>;

enum class QualityPreset { Economy, Balanced, Quality, Ultra };

struct ProcessingOptions {
    int target_width = 0;
    int target_height = 0;
    float brightness = 0.0f;
    float contrast = 1.06f;
    float saturation = 1.06f;
    float gamma = 1.00f;
    float sharpen = 0.25f;
    float denoise = 0.15f;
    float deband = 0.10f;
    bool enabled = true;
    bool sourceAware = true;
    bool temporal = true;
    bool postUpscaleCleanup = true;
    QualityPreset preset = QualityPreset::Balanced;
};

struct ProcessingStats {
    bool sourceAwareUsed = false;
    bool deblockUsed = false;
    bool chromaUsed = false;
    bool temporalUsed = false;
    bool detailUsed = false;
    bool antiRingingUsed = false;
    bool antiAliasUsed = false;
    bool textRestoreUsed = false;
    double lastBlockiness = 0.0;
    double lastLumaNoise = 0.0;
    double lastChromaNoise = 0.0;
    double lastMotion = 0.0;
};

class FrameProcessor {
public:
    explicit FrameProcessor(unsigned workers = 0);
    ~FrameProcessor();
    FrameProcessor(const FrameProcessor&) = delete;
    FrameProcessor& operator=(const FrameProcessor&) = delete;

    FramePtr process(const AVFrame* src, const ProcessingOptions& opt);
    void reset();
    unsigned workerCount() const { return pool_.threadCount(); }
    const ProcessingStats& stats() const { return stats_; }

private:
    bool ensureScaler(int inW, int inH, AVPixelFormat inFmt, int outW, int outH, int flags);
    bool ensurePreScaler(int inW, int inH, AVPixelFormat inFmt);
    bool ensurePostScaler(int inW, int inH, int outW, int outH, int flags);

    SwsContext* sws_ = nullptr;
    SwsContext* preSws_ = nullptr;
    SwsContext* postSws_ = nullptr;

    int inW_ = 0, inH_ = 0, outW_ = 0, outH_ = 0, flags_ = 0;
    AVPixelFormat inFmt_ = AV_PIX_FMT_NONE;

    int preW_ = 0, preH_ = 0;
    AVPixelFormat preFmt_ = AV_PIX_FMT_NONE;
    int postInW_ = 0, postInH_ = 0, postOutW_ = 0, postOutH_ = 0, postFlags_ = 0;

    WorkerPool pool_;
    FrameAnalysisCoordinator analysisCoordinator_;
    AdaptiveDeblock adaptiveDeblock_;
    ChromaEnhancer chromaEnhancer_;
    FilterDecisionEngine decisionEngine_;
    AdaptiveDenoise adaptiveDenoise_;
    EdgeSharpen edgeSharpen_;
    MultiPassUpscale multiPass_;
    DetailReconstruction detailReconstruction_;
    SceneMotionDetector motionDetector_;
    MotionAwareTemporal temporalFilter_;
    LowResRecovery lowResRecovery_;
    PreUpscaleRecovery preUpscaleRecovery_;
    PostUpscaleCleanup postCleanup_;
    ContentAnalysis lastAnalysis_{};
    SceneMotionInfo lastMotionInfo_{};
    ProcessingStats stats_{};
};
