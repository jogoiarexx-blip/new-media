#pragma once
#include <string>
struct CpuCaps {
    unsigned logicalCores = 1;
    bool sse42 = false;
    bool avx = false;
    bool avx2 = false;
    bool avx512f = false;
    std::string summary() const;
};
CpuCaps detectCpuCaps();
