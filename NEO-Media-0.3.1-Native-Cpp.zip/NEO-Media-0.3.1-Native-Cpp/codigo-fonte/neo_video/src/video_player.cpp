#include "video_player.hpp"
#include "audio_engine.hpp"
#include "ui_overlay.hpp"
#include "cpu_detect.hpp"
#include "ai_upscaler.hpp"
#include "../core/sync_controller.hpp"
#include "../core/pipeline_sanity.hpp"
#include <SDL.h>
extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
}
#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>
#include <sstream>
#include <thread>
#include <mutex>
#include <deque>
#include <memory>
#include <cmath>

static const char* presetName(QualityPreset p) {
    switch (p) {
        case QualityPreset::Economy: return "ECO";
        case QualityPreset::Balanced: return "BALANCED";
        case QualityPreset::Quality: return "QUALITY";
        case QualityPreset::Ultra: return "ULTRA";
    }
    return "?";
}
static QualityPreset nextPreset(QualityPreset p) { return static_cast<QualityPreset>((static_cast<int>(p)+1)%4); }
static const char* imagePresetName(int p){ static const char* n[]={"NATURAL","CINEMA","VIVID","SOFT"}; return n[p%4]; }
static void applyImagePreset(int p, ProcessingOptions& o){
    switch(p%4){
        case 0: o.brightness=0.0f;o.contrast=1.06f;o.saturation=1.06f;o.gamma=1.0f;o.sharpen=.25f;o.denoise=.15f;o.deband=.10f;break;
        case 1: o.brightness=-.02f;o.contrast=1.12f;o.saturation=.98f;o.gamma=.96f;o.sharpen=.20f;o.denoise=.18f;o.deband=.16f;break;
        case 2: o.brightness=.02f;o.contrast=1.15f;o.saturation=1.22f;o.gamma=1.02f;o.sharpen=.34f;o.denoise=.10f;o.deband=.08f;break;
        case 3: o.brightness=.01f;o.contrast=1.02f;o.saturation=.98f;o.gamma=1.04f;o.sharpen=.10f;o.denoise=.30f;o.deband=.20f;break;
    }
}

int VideoPlayer::run(const PlayerOptions& options) {
    // Commands are queued off-thread; decoder and SDL stay on the main thread.
    struct Commands { std::mutex mutex; std::deque<std::string> lines; };
    auto commands = std::make_shared<Commands>();
    if (options.ipc) std::thread([commands] {
        std::string line;
        while (std::getline(std::cin, line)) {
            if (line.size() > 256) continue;
            std::lock_guard<std::mutex> lock(commands->mutex);
            if (commands->lines.size() < 128) commands->lines.push_back(line);
        }
    }).detach();
    avformat_network_init();
    AVFormatContext* fmt=nullptr; AVDictionary* inputOpts=nullptr;
    av_dict_set(&inputOpts,"rw_timeout","10000000",0);
    if(avformat_open_input(&fmt,options.input.c_str(),nullptr,&inputOpts)<0){ av_dict_free(&inputOpts); std::cerr<<"Nao foi possivel abrir: "<<options.input<<"\n"; return 1; }
    av_dict_free(&inputOpts);
    if(avformat_find_stream_info(fmt,nullptr)<0){ avformat_close_input(&fmt); return 2; }
    int vsi=av_find_best_stream(fmt,AVMEDIA_TYPE_VIDEO,-1,-1,nullptr,0);
    int asi=av_find_best_stream(fmt,AVMEDIA_TYPE_AUDIO,-1,-1,nullptr,0);
    if(options.audioStream>=0 && options.audioStream<static_cast<int>(fmt->nb_streams) && fmt->streams[options.audioStream]->codecpar->codec_type==AVMEDIA_TYPE_AUDIO) asi=options.audioStream;
    if(vsi<0){ avformat_close_input(&fmt); return 3; }

    AVStream* vs=fmt->streams[vsi];
    const AVCodec* vdec=avcodec_find_decoder(vs->codecpar->codec_id);
    AVCodecContext* vdc=vdec?avcodec_alloc_context3(vdec):nullptr;
    if(!vdec || !vdc){ avcodec_free_context(&vdc); avformat_close_input(&fmt); return 4; }
    avcodec_parameters_to_context(vdc,vs->codecpar); vdc->thread_count=0; vdc->thread_type=FF_THREAD_FRAME|FF_THREAD_SLICE;
    if(avcodec_open2(vdc,vdec,nullptr)<0){ avcodec_free_context(&vdc); avformat_close_input(&fmt); return 5; }

    AVCodecContext* adc=nullptr; AVStream* as=nullptr;
    if(asi>=0){
        as=fmt->streams[asi]; const AVCodec* adec=avcodec_find_decoder(as->codecpar->codec_id);
        if(adec){ adc=avcodec_alloc_context3(adec); if(adc){ avcodec_parameters_to_context(adc,as->codecpar); adc->thread_count=0; if(avcodec_open2(adc,adec,nullptr)<0) avcodec_free_context(&adc); } }
    }

    AVRational fps=av_guess_frame_rate(fmt,vs,nullptr); if(!fps.num||!fps.den) fps=AVRational{30,1};
    const double budgetMs=1000.0*fps.den/fps.num;
    int outW=options.upscaleW>0?options.upscaleW:vdc->width; int outH=options.upscaleH>0?options.upscaleH:vdc->height; 
    if (options.upscaleW > 0 && options.upscaleH > 0) {
        double ratio = std::min(static_cast<double>(outW)/vdc->width, static_cast<double>(outH)/vdc->height);
        outW = static_cast<int>(vdc->width*ratio); outH = static_cast<int>(vdc->height*ratio);
    }
    outW=std::max(2,outW&~1); outH=std::max(2,outH&~1);
    const double durationSec=(fmt->duration>0 && fmt->duration!=AV_NOPTS_VALUE)?fmt->duration/static_cast<double>(AV_TIME_BASE):0.0;
    CpuCaps cpu=detectCpuCaps();

    if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO|SDL_INIT_EVENTS|SDL_INIT_TIMER)!=0){ std::cerr<<"SDL: "<<SDL_GetError()<<"\n"; avcodec_free_context(&adc); avcodec_free_context(&vdc); avformat_close_input(&fmt); return 6; }
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY,"2");
    SDL_Window* win=options.windowId ? SDL_CreateWindowFrom(reinterpret_cast<void*>(options.windowId)) : SDL_CreateWindow("NEO Video v0.21.0",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,std::min(outW,1280),std::min(outH+232,952),SDL_WINDOW_RESIZABLE|SDL_WINDOW_ALLOW_HIGHDPI);
    SDL_Renderer* ren=win?SDL_CreateRenderer(win,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC):nullptr; if(!ren&&win) ren=SDL_CreateRenderer(win,-1,SDL_RENDERER_SOFTWARE);
    SDL_Texture* tex=ren?SDL_CreateTexture(ren,SDL_PIXELFORMAT_IYUV,SDL_TEXTUREACCESS_STREAMING,outW,outH):nullptr;
    SDL_Texture* originalTex=ren?SDL_CreateTexture(ren,SDL_PIXELFORMAT_IYUV,SDL_TEXTUREACCESS_STREAMING,outW,outH):nullptr;
    if(!win||!ren||!tex||!originalTex){ std::cerr<<"Falha ao criar janela/renderizador: "<<SDL_GetError()<<"\n"; if(originalTex)SDL_DestroyTexture(originalTex);if(tex)SDL_DestroyTexture(tex);if(ren)SDL_DestroyRenderer(ren);if(win)SDL_DestroyWindow(win);SDL_Quit();avcodec_free_context(&adc);avcodec_free_context(&vdc);avformat_close_input(&fmt);return 7; }

    AudioEngine audio; bool audioOk=false;
    if(adc){ audioOk=audio.open(48000,2,options.audioDevice.empty()?nullptr:options.audioDevice.c_str()); audio.setVolume(options.volume); if(options.startMuted) audio.toggleMute(); }

    if(adc && !audioOk){ std::cerr<<"NEO_WARNING Saida de audio indisponivel; tente a saida padrao.\n"; }
    AiUpscaler ai;
    bool aiRequested=options.aiEnabled && !options.aiModel.empty();
    if(aiRequested){ if(!ai.load(options.aiModel,options.aiTile)) std::cerr<<"AI indisponivel; usando Lanczos fallback.\n"; }
    ai.setEnabled(aiRequested && ai.info().modelLoaded);
    int aiSlowFrames=0;
    FrameProcessor processor(cpu.logicalCores), originalProcessor(1); SyncController syncController; ProcessingOptions popt; popt.target_width=outW; popt.target_height=outH; popt.preset=options.preset;
    if(options.autoPerformance && options.preset==QualityPreset::Balanced){ if(cpu.logicalCores<=4) popt.preset=QualityPreset::Economy; else if(cpu.logicalCores>=12) popt.preset=QualityPreset::Quality; }
    int imagePreset=0; applyImagePreset(imagePreset,popt);
    const QualityPreset autoMaxPreset=popt.preset;
    ProcessingOptions originalOpt=popt; originalOpt.enabled=false; originalOpt.preset=QualityPreset::Balanced;
    Recorder recorder; bool recordingWanted=!options.recordPath.empty();
    if(recordingWanted && recorder.start(options.recordPath,outW,outH,fps,adc!=nullptr)) std::cout<<"REC: "<<options.recordPath<<(recorder.audioEnabled()?" + AAC audio":" video only")<<"\n";

    UiOverlay ui;
    AVPacket* pkt=av_packet_alloc(); AVFrame* vframe=av_frame_alloc(); AVFrame* aframe=av_frame_alloc();
    bool quit=false,paused=options.startPaused,compare=false,autoPerf=options.autoPerformance,fullscreen=false;
    int64_t recVideoPts=0,renderedFrames=0; double emaProcessMs=0.0; auto wallStart=std::chrono::steady_clock::now(); double firstPtsSec=-1.0; double playbackPosition=0.0;

    if(options.startPaused) audio.setPaused(true);
    auto updateTitle=[&](){ std::ostringstream ss; ss<<"NEO Video v0.21.0 | "<<outW<<"x"<<outH<<" | "<<presetName(popt.preset)<<" | Enhance:"<<(popt.enabled?"ON":"OFF")<<" | Auto:"<<(autoPerf?"ON":"OFF")<<" | REC:"<<(recorder.active()?"ON":"OFF")<<" | Audio:"<<(adc?(audio.muted()?"MUTE":"ON"):"NONE")<<" "<<static_cast<int>(audio.volume()*100)<<"% | "<<static_cast<int>(emaProcessMs+0.5)<<"ms/frame | CPU:"<<cpu.summary(); ss<<" | AI:"<<(ai.enabled()?"ON":"OFF"); if(ai.info().modelLoaded) ss<<" "<<static_cast<int>(ai.info().lastMs+.5)<<"ms"; if(compare)ss<<" | ANTES/DEPOIS"; SDL_SetWindowTitle(win,ss.str().c_str()); };

    uint64_t seekGeneration=0; double seekMinimum=-1.0;
    auto seekTo=[&](double seconds){
        if(durationSec<=0.0 || recorder.active()) return;
        seconds=std::clamp(seconds,0.0,durationSec);
        int64_t target=static_cast<int64_t>(seconds*AV_TIME_BASE);
        if(av_seek_frame(fmt,-1,target,AVSEEK_FLAG_BACKWARD)>=0){
            ++seekGeneration; seekMinimum=seconds;
            avcodec_flush_buffers(vdc); if(adc) avcodec_flush_buffers(adc); audio.clear(); processor.reset(); originalProcessor.reset();
            firstPtsSec=-1.0; wallStart=std::chrono::steady_clock::now(); playbackPosition=seconds;
        }
    };

    auto toggleRecord=[&](){
        if(!recordingWanted) return;
        if(recorder.active()) recorder.stop();
        else { recVideoPts=0; recorder.start(options.recordPath,outW,outH,fps,adc!=nullptr); }
    };

    auto executeAction=[&](const UiAction& a){
        switch(a.type){
            case UiActionType::TogglePause: paused=!paused; audio.setPaused(paused); wallStart=std::chrono::steady_clock::now(); firstPtsSec=-1.0; break;
            case UiActionType::ToggleEnhance: popt.enabled=!popt.enabled; break;
            case UiActionType::ToggleCompare: compare=!compare; break;
            case UiActionType::ToggleRecord: toggleRecord(); break;
            case UiActionType::ToggleMute: audio.toggleMute(); break;
            case UiActionType::ToggleAutoPerformance: autoPerf=!autoPerf; break;
            case UiActionType::NextPreset: popt.preset=nextPreset(popt.preset); break;
            case UiActionType::NextImagePreset: imagePreset=(imagePreset+1)%4; applyImagePreset(imagePreset,popt); break;
            case UiActionType::ToggleFullscreen: fullscreen=!fullscreen; SDL_SetWindowFullscreen(win,fullscreen?SDL_WINDOW_FULLSCREEN_DESKTOP:0); break;
            case UiActionType::Seek: seekTo(a.value); break;
            case UiActionType::SetVolume: audio.setVolume(static_cast<float>(a.value)); break;
            case UiActionType::SetBrightness: popt.brightness=static_cast<float>(a.value); break;
            case UiActionType::SetContrast: popt.contrast=static_cast<float>(a.value); break;
            case UiActionType::SetSaturation: popt.saturation=static_cast<float>(a.value); break;
            case UiActionType::SetGamma: popt.gamma=static_cast<float>(a.value); break;
            case UiActionType::SetSharpen: popt.sharpen=static_cast<float>(a.value); break;
            case UiActionType::SetDenoise: popt.denoise=static_cast<float>(a.value); break;
            case UiActionType::SetDeband: popt.deband=static_cast<float>(a.value); break;
            case UiActionType::ResetImage: imagePreset=0; applyImagePreset(imagePreset,popt); break;
            case UiActionType::ToggleAI: if(ai.info().modelLoaded) ai.setEnabled(!ai.enabled()); break;
            default: break;
        }
        updateTitle();
    };

    auto currentUi=[&](){ UiState s; s.paused=paused;s.enhance=popt.enabled;s.compare=compare;s.recording=recorder.active();s.muted=audio.muted();s.autoPerformance=autoPerf;s.volume=audio.volume();s.position=playbackPosition;s.duration=durationSec;s.processMs=emaProcessMs;s.preset=presetName(popt.preset);s.imagePreset=imagePresetName(imagePreset);s.resolution=std::to_string(outW)+"x"+std::to_string(outH);s.cpu=cpu.summary();s.ai=ai.enabled();s.aiStatus=ai.info().modelLoaded?(ai.enabled()?"AI ON":"AI OFF"):(aiRequested?"AI FALLBACK":"AI OFF");s.brightness=popt.brightness;s.contrast=popt.contrast;s.saturation=popt.saturation;s.gamma=popt.gamma;s.sharpen=popt.sharpen;s.denoise=popt.denoise;s.deband=popt.deband;return s; };

    auto lastReport=std::chrono::steady_clock::now();
    auto report=[&](bool force=false){
        auto now=std::chrono::steady_clock::now();
        if(options.ipc && (force || now-lastReport>std::chrono::milliseconds(200))){
            std::cout << "NEO_STATUS " << (paused?"paused":"playing") << " " << playbackPosition << " " << durationSec << std::endl;
            lastReport=now;
        }
    };
    auto handleEvents=[&](){
        std::deque<std::string> pending;
        { std::lock_guard<std::mutex> lock(commands->mutex); pending.swap(commands->lines); }
        for(const auto& line:pending){
            std::istringstream input(line); std::string action; double value=0; input>>action>>value;
            if(action=="stop") quit=true;
            else if(action=="pause") executeAction({UiActionType::TogglePause,0});
            else if(action=="seek" && std::isfinite(value)) seekTo(value);
            else if(action=="volume" && std::isfinite(value)) audio.setVolume(static_cast<float>(value));
            else if(action=="mute") audio.toggleMute();
            else if(action=="preset"){ int level=std::clamp(static_cast<int>(value),0,3); popt.preset=static_cast<QualityPreset>(level); }
            else if(action=="color"){ imagePreset=std::clamp(static_cast<int>(value),0,3); applyImagePreset(imagePreset,popt); }
            else if(action=="enhance") executeAction({UiActionType::ToggleEnhance,0});
            else if(action=="fullscreen" && !options.windowId) executeAction({UiActionType::ToggleFullscreen,0});
        }
        report();
        SDL_Event e; while(SDL_PollEvent(&e)){
        if(e.type==SDL_QUIT){quit=true;continue;}
        if(e.type==SDL_MOUSEBUTTONDOWN && e.button.button==SDL_BUTTON_LEFT){if(options.windowId)continue;int ww,wh;SDL_GetRendererOutputSize(ren,&ww,&wh);executeAction(ui.hitTest(e.button.x,e.button.y,ww,wh,currentUi()));continue;}
        if(e.type!=SDL_KEYDOWN)continue; auto k=e.key.keysym.sym;
        if(k==SDLK_ESCAPE)quit=true;
        else if(k==SDLK_SPACE)executeAction({UiActionType::TogglePause,0});
        else if(k==SDLK_e)executeAction({UiActionType::ToggleEnhance,0});
        else if(k==SDLK_c)executeAction({UiActionType::ToggleCompare,0});
        else if(k==SDLK_a)executeAction({UiActionType::ToggleAutoPerformance,0});
        else if(k==SDLK_p)executeAction({UiActionType::NextPreset,0});
        else if(k==SDLK_i)executeAction({UiActionType::NextImagePreset,0});
        else if(k==SDLK_0)executeAction({UiActionType::ResetImage,0});
        else if(k==SDLK_UP)popt.sharpen=std::min(1.0f,popt.sharpen+0.05f);
        else if(k==SDLK_DOWN)popt.sharpen=std::max(0.0f,popt.sharpen-0.05f);
        else if(k==SDLK_RIGHT)popt.saturation=std::min(2.0f,popt.saturation+0.05f);
        else if(k==SDLK_LEFT)popt.saturation=std::max(0.0f,popt.saturation-0.05f);
        else if(k==SDLK_m)executeAction({UiActionType::ToggleMute,0});
        else if(k==SDLK_EQUALS||k==SDLK_KP_PLUS)audio.setVolume(audio.volume()+0.05f);
        else if(k==SDLK_MINUS||k==SDLK_KP_MINUS)audio.setVolume(audio.volume()-0.05f);
        else if(k==SDLK_x)executeAction({UiActionType::ToggleAI,0});
        else if(k==SDLK_f)executeAction({UiActionType::ToggleFullscreen,0});
        else if(k==SDLK_r)executeAction({UiActionType::ToggleRecord,0});
        else if(k==SDLK_PAGEUP && durationSec>0)seekTo(playbackPosition+10.0);
        else if(k==SDLK_PAGEDOWN && durationSec>0)seekTo(playbackPosition-10.0);
        updateTitle();
    }};

    auto renderFrame=[&](AVFrame* decoded){ auto generation=seekGeneration; handleEvents(); if(quit || generation!=seekGeneration)return; while(paused&&!quit){handleEvents();SDL_Delay(16);} if(quit || generation!=seekGeneration)return;
        if(seekMinimum>=0 && decoded->best_effort_timestamp!=AV_NOPTS_VALUE && decoded->best_effort_timestamp*av_q2d(vs->time_base)<seekMinimum)return;
        auto t0=std::chrono::steady_clock::now(); FramePtr aiFrame; const AVFrame* processSrc=decoded; if(ai.enabled()){ aiFrame=ai.upscale(decoded,outW,outH); if(aiFrame) processSrc=aiFrame.get(); } FramePtr out=processor.process(processSrc,popt); if(!out)return; FramePtr orig; if(compare)orig=originalProcessor.process(decoded,originalOpt); auto t1=std::chrono::steady_clock::now();
        double processMs=std::chrono::duration<double,std::milli>(t1-t0).count(); emaProcessMs=renderedFrames==0?processMs:emaProcessMs*0.92+processMs*0.08;
        if(ai.enabled()){ if(ai.info().lastMs>budgetMs*0.90) ++aiSlowFrames; else aiSlowFrames=std::max(0,aiSlowFrames-1); if(autoPerf && aiSlowFrames>=6){ ai.setEnabled(false); aiSlowFrames=0; std::cerr<<"AI fallback automatico: processamento acima do orcamento do frame.\n"; } }
        if(autoPerf&&renderedFrames%30==0&&renderedFrames>0){ if(emaProcessMs>budgetMs*0.92){ if(popt.preset==QualityPreset::Ultra)popt.preset=QualityPreset::Quality; else if(popt.preset==QualityPreset::Quality)popt.preset=QualityPreset::Balanced; else {popt.denoise=std::max(0.0f,popt.denoise-0.05f);popt.deband=std::max(0.0f,popt.deband-0.05f);} } else if(emaProcessMs<budgetMs*0.55&&popt.preset!=autoMaxPreset){popt.preset=nextPreset(popt.preset);if(static_cast<int>(popt.preset)>static_cast<int>(autoMaxPreset))popt.preset=autoMaxPreset;} }
        SDL_UpdateYUVTexture(tex,nullptr,out->data[0],out->linesize[0],out->data[1],out->linesize[1],out->data[2],out->linesize[2]); if(compare&&orig)SDL_UpdateYUVTexture(originalTex,nullptr,orig->data[0],orig->linesize[0],orig->data[1],orig->linesize[1],orig->data[2],orig->linesize[2]);
        int64_t ts=decoded->best_effort_timestamp; double ptsSec=(ts!=AV_NOPTS_VALUE)?ts*av_q2d(vs->time_base):-1.0; if(ptsSec>=0.0) playbackPosition=ptsSec;
        SDL_RenderClear(ren); int ww,wh;SDL_GetRendererOutputSize(ren,&ww,&wh);int videoAreaH=std::max(1,wh-(options.windowId?0:ui.reservedBottom()));double ar=static_cast<double>(outW)/outH;SDL_Rect dst{0,0,ww,videoAreaH};if(static_cast<double>(ww)/videoAreaH>ar){dst.w=static_cast<int>(videoAreaH*ar);dst.x=(ww-dst.w)/2;}else{dst.h=static_cast<int>(ww/ar);dst.y=(videoAreaH-dst.h)/2;}
        if(!compare||!orig)SDL_RenderCopy(ren,tex,nullptr,&dst);else{SDL_Rect ls{0,0,outW/2,outH},rs{outW/2,0,outW-outW/2,outH};SDL_Rect ld{dst.x,dst.y,dst.w/2,dst.h},rd{dst.x+dst.w/2,dst.y,dst.w-dst.w/2,dst.h};SDL_RenderCopy(ren,originalTex,&ls,&ld);SDL_RenderCopy(ren,tex,&rs,&rd);SDL_SetRenderDrawColor(ren,255,255,255,255);SDL_RenderDrawLine(ren,dst.x+dst.w/2,dst.y,dst.x+dst.w/2,dst.y+dst.h);}
        if(!options.windowId) ui.draw(ren,ww,wh,currentUi()); SDL_RenderPresent(ren);
        if(recorder.active()) recorder.writeVideo(out.get(),recVideoPts++);
        // Wall-clock pacing also covers seek discontinuities where audio timestamps
        // have not arrived yet. Never display the remaining video in a burst.
        if(ptsSec>=0.0){
            if(firstPtsSec<0.0){firstPtsSec=ptsSec;wallStart=std::chrono::steady_clock::now();}
            double target=ptsSec-firstPtsSec;
            while(!quit && !paused){
                double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-wallStart).count();
                if(target<=elapsed || generation!=seekGeneration)break;
                SDL_Delay(static_cast<Uint32>(std::min(10.0,(target-elapsed)*1000.0)));
                handleEvents();
            }
        } else if(processMs<budgetMs)
            std::this_thread::sleep_for(std::chrono::duration<double,std::milli>(budgetMs-processMs));
        ++renderedFrames;
        if(renderedFrames%15==0)updateTitle(); };

    if(options.startSeconds>0) seekTo(options.startSeconds);
    updateTitle();
    while(!quit && av_read_frame(fmt,pkt)>=0){ auto generation=seekGeneration; handleEvents(); if(generation!=seekGeneration){av_packet_unref(pkt);continue;}
        if(pkt->stream_index==vsi && avcodec_send_packet(vdc,pkt)>=0){ while(!quit&&avcodec_receive_frame(vdc,vframe)>=0)renderFrame(vframe); }
        else if(adc && pkt->stream_index==asi && avcodec_send_packet(adc,pkt)>=0){ while(avcodec_receive_frame(adc,aframe)>=0){ double apts=-1.0; int64_t ts=aframe->best_effort_timestamp; if(ts!=AV_NOPTS_VALUE)apts=ts*av_q2d(as->time_base); if(audioOk && (seekMinimum<0 || apts>=seekMinimum))audio.queue(aframe,apts); if(recorder.active())recorder.writeAudio(aframe); } }
        av_packet_unref(pkt);
    }
    if(!quit){ avcodec_send_packet(vdc,nullptr); while(avcodec_receive_frame(vdc,vframe)>=0)renderFrame(vframe); if(adc){avcodec_send_packet(adc,nullptr);while(avcodec_receive_frame(adc,aframe)>=0){double apts=-1.0;int64_t ts=aframe->best_effort_timestamp;if(ts!=AV_NOPTS_VALUE)apts=ts*av_q2d(as->time_base);if(audioOk && (seekMinimum<0 || apts>=seekMinimum))audio.queue(aframe,apts);if(recorder.active())recorder.writeAudio(aframe);}} }

    // Drain queued audio at EOF; otherwise the final audio packets are truncated.
    while (!quit && audioOk && audio.queuedSeconds() > 0.005) { handleEvents(); SDL_Delay(10); }
    if(options.ipc) std::cout << "NEO_END " << (quit?"stopped":"ended") << std::endl;
    recorder.stop(); audio.close(); av_frame_free(&aframe);av_frame_free(&vframe);av_packet_free(&pkt);avcodec_free_context(&adc);avcodec_free_context(&vdc);avformat_close_input(&fmt);avformat_network_deinit();SDL_DestroyTexture(originalTex);SDL_DestroyTexture(tex);SDL_DestroyRenderer(ren);SDL_DestroyWindow(win);SDL_Quit();return 0;
}
