#include "offline_exporter.hpp"
extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/avutil.h>
}
#include <algorithm>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <memory>

namespace {
struct FormatCloser { void operator()(AVFormatContext* f) const { if (f) avformat_close_input(&f); } };
struct CodecCloser { void operator()(AVCodecContext* c) const { if (c) avcodec_free_context(&c); } };
struct PacketCloser { void operator()(AVPacket* p) const { if (p) av_packet_free(&p); } };

AVRational safeFps(const AVStream* st) {
    AVRational fps = av_guess_frame_rate(nullptr, const_cast<AVStream*>(st), nullptr);
    if (!fps.num || !fps.den || av_q2d(fps) <= 1.0) fps = AVRational{30,1};
    return fps;
}

std::unique_ptr<AVCodecContext, CodecCloser> openDecoder(AVStream* st) {
    const AVCodec* dec = avcodec_find_decoder(st->codecpar->codec_id);
    if (!dec) return {};
    std::unique_ptr<AVCodecContext, CodecCloser> ctx(avcodec_alloc_context3(dec));
    if (!ctx || avcodec_parameters_to_context(ctx.get(), st->codecpar) < 0 || avcodec_open2(ctx.get(), dec, nullptr) < 0) return {};
    return ctx;
}

void printProgress(double pos, double total, int64_t frames, double elapsed) {
    if (total <= 0.0) return;
    double pct = std::clamp(pos / total * 100.0, 0.0, 100.0);
    double speed = elapsed > 0.05 ? pos / elapsed : 0.0;
    std::cerr << "\rExportando " << std::fixed << std::setprecision(1) << pct << "%"
              << " | frames " << frames << " | " << std::setprecision(2) << speed << "x tempo real   " << std::flush;
}
}

int OfflineExporter::run(const ExportOptions& opt) {
    stats_ = {};
    if (opt.input.empty() || opt.output.empty()) {
        std::cerr << "Exportacao requer entrada e saida.\n";
        return 2;
    }

    AVFormatContext* rawFmt = nullptr;
    if (avformat_open_input(&rawFmt, opt.input.c_str(), nullptr, nullptr) < 0) {
        std::cerr << "Nao foi possivel abrir: " << opt.input << "\n";
        return 3;
    }
    std::unique_ptr<AVFormatContext, FormatCloser> fmt(rawFmt);
    if (avformat_find_stream_info(fmt.get(), nullptr) < 0) {
        std::cerr << "Nao foi possivel ler informacoes do arquivo.\n";
        return 4;
    }

    int videoIndex = av_find_best_stream(fmt.get(), AVMEDIA_TYPE_VIDEO, -1, -1, nullptr, 0);
    int audioIndex = opt.copyAudio ? av_find_best_stream(fmt.get(), AVMEDIA_TYPE_AUDIO, -1, -1, nullptr, 0) : -1;
    if (videoIndex < 0) { std::cerr << "Nenhuma faixa de video encontrada.\n"; return 5; }

    AVStream* vst = fmt->streams[videoIndex];
    auto vdec = openDecoder(vst);
    auto adec = audioIndex >= 0 ? openDecoder(fmt->streams[audioIndex]) : decltype(vdec){};
    if (!vdec) { std::cerr << "Decoder de video indisponivel.\n"; return 6; }
    if (audioIndex >= 0 && !adec) { std::cerr << "Aviso: audio nao pode ser decodificado; exportando sem audio.\n"; audioIndex = -1; }

    int targetW = opt.targetW > 0 ? opt.targetW : vdec->width;
    int targetH = opt.targetH > 0 ? opt.targetH : vdec->height;
    targetW &= ~1; targetH &= ~1;
    AVRational fps = safeFps(vst);

    Recorder recorder;
    RecorderOptions ro;
    ro.crf = std::clamp(opt.crf, 0, 51);
    ro.preset = opt.encoderPreset;
    ro.bitrate = std::max(500000, opt.bitrate);
    if (!recorder.start(opt.output, targetW, targetH, fps, audioIndex >= 0, ro)) {
        std::cerr << "Nao foi possivel iniciar encoder para: " << opt.output << "\n";
        return 7;
    }

    FrameProcessor processor;
    AiUpscaler ai;
    bool aiReady = false;
    if (opt.useAi && !opt.aiModel.empty()) {
        aiReady = ai.load(opt.aiModel, opt.aiTile);
        if (!aiReady) std::cerr << "Aviso: IA indisponivel; exportacao continuara em Lanczos Ultra.\n";
    }

    ProcessingOptions po;
    po.target_width = targetW; po.target_height = targetH; po.preset = opt.preset; po.enabled = true;
    po.brightness = opt.brightness; po.contrast = opt.contrast; po.saturation = opt.saturation; po.gamma = opt.gamma;
    po.sharpen = opt.sharpen; po.denoise = opt.denoise; po.deband = opt.deband;

    const double totalSec = fmt->duration > 0 ? fmt->duration / static_cast<double>(AV_TIME_BASE) : 0.0;
    stats_.sourceSeconds = totalSec;
    auto start = std::chrono::steady_clock::now();
    int64_t outVideoPts = 0;
    double lastProgress = -1.0;

    std::unique_ptr<AVPacket, PacketCloser> pkt(av_packet_alloc());
    AVFrame* rawFrame = av_frame_alloc();
    if (!pkt || !rawFrame) { if(rawFrame) av_frame_free(&rawFrame); recorder.stop(); return 8; }

    auto drainVideo = [&](bool flush) -> bool {
        if (flush && avcodec_send_packet(vdec.get(), nullptr) < 0) return false;
        while (true) {
            int r = avcodec_receive_frame(vdec.get(), rawFrame);
            if (r == AVERROR(EAGAIN) || r == AVERROR_EOF) break;
            if (r < 0) return false;
            FramePtr neural;
            const AVFrame* filterSrc = rawFrame;
            ProcessingOptions thisPo = po;
            if (aiReady) {
                neural = ai.upscale(rawFrame, targetW, targetH);
                if (neural) {
                    filterSrc = neural.get();
                    thisPo.target_width = targetW; thisPo.target_height = targetH;
                    ++stats_.aiFrames;
                }
            }
            FramePtr processed = processor.process(filterSrc, thisPo);
            if (!processed || !recorder.writeVideo(processed.get(), outVideoPts++)) return false;
            ++stats_.videoFrames;
            double pos = 0.0;
            int64_t ts = rawFrame->best_effort_timestamp;
            if (ts != AV_NOPTS_VALUE) pos = ts * av_q2d(vst->time_base);
            double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
            if (pos - lastProgress >= 0.25 || (totalSec > 0 && pos >= totalSec - 0.25)) {
                printProgress(pos,totalSec,stats_.videoFrames,elapsed); lastProgress=pos;
            }
            av_frame_unref(rawFrame);
        }
        return true;
    };

    auto drainAudio = [&](bool flush) -> bool {
        if (!adec || audioIndex < 0) return true;
        if (flush && avcodec_send_packet(adec.get(), nullptr) < 0) return false;
        while (true) {
            int r = avcodec_receive_frame(adec.get(), rawFrame);
            if (r == AVERROR(EAGAIN) || r == AVERROR_EOF) break;
            if (r < 0) return false;
            if (!recorder.writeAudio(rawFrame)) return false;
            ++stats_.audioFrames;
            av_frame_unref(rawFrame);
        }
        return true;
    };

    bool ok = true;
    while (ok && av_read_frame(fmt.get(), pkt.get()) >= 0) {
        if (pkt->stream_index == videoIndex) {
            int r = avcodec_send_packet(vdec.get(), pkt.get());
            if (r >= 0 || r == AVERROR(EAGAIN)) ok = drainVideo(false);
            else ok = false;
        } else if (pkt->stream_index == audioIndex && adec) {
            int r = avcodec_send_packet(adec.get(), pkt.get());
            if (r >= 0 || r == AVERROR(EAGAIN)) ok = drainAudio(false);
            else ok = false;
        }
        av_packet_unref(pkt.get());
    }
    if (ok) ok = drainVideo(true);
    if (ok) ok = drainAudio(true);
    av_frame_free(&rawFrame);
    recorder.stop();

    stats_.elapsedSeconds = std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    std::cerr << "\n";
    if (!ok) { std::cerr << "Exportacao interrompida por erro de decode/processamento/encode.\n"; return 9; }
    std::cout << "Exportacao concluida: " << opt.output << "\n"
              << "Video frames: " << stats_.videoFrames << " | Audio frames: " << stats_.audioFrames
              << " | IA frames: " << stats_.aiFrames << "\n"
              << "Tempo: " << std::fixed << std::setprecision(1) << stats_.elapsedSeconds << " s\n";
    return 0;
}
