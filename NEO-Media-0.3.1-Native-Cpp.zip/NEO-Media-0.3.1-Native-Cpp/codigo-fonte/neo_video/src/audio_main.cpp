#include "audio_engine.hpp"
#include <SDL.h>
extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/avutil.h>
}
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <deque>
#include <iostream>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#include <shellapi.h>
#endif

namespace {
struct Options {
    std::string source;
    std::string audioDevice;
    double startSeconds = 0.0;
    float volume = 0.75f;
    int audioStream = -1;
    bool paused = false;
    bool muted = false;
    bool ipc = false;
};

Options parse(int argc, char** argv) {
    Options o;
    if (argc > 1) o.source = argv[1];
    for (int i = 2; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--ipc") o.ipc = true;
        else if (a == "--paused") o.paused = true;
        else if (a == "--mute") o.muted = true;
        else if (a == "--start" && i + 1 < argc) o.startSeconds = std::max(0.0, std::strtod(argv[++i], nullptr));
        else if (a == "--volume" && i + 1 < argc) o.volume = std::clamp(std::strtof(argv[++i], nullptr), 0.0f, 1.5f);
        else if (a == "--audio-device" && i + 1 < argc) o.audioDevice = argv[++i];
        else if (a == "--audio-stream" && i + 1 < argc) o.audioStream = std::atoi(argv[++i]);
    }
    return o;
}

int runAudio(const Options& opt) {
    if (opt.source.empty()) {
        std::cerr << "Uso: neo_audio <arquivo-ou-stream> [--ipc] [--volume 0..1.5] [--start segundos] [--paused]\n";
        return 2;
    }

    avformat_network_init();
    AVFormatContext* fmt = nullptr;
    AVDictionary* dict = nullptr;
    av_dict_set(&dict, "rw_timeout", "10000000", 0);
    if (avformat_open_input(&fmt, opt.source.c_str(), nullptr, &dict) < 0) {
        av_dict_free(&dict); avformat_network_deinit();
        std::cerr << "Nao foi possivel abrir a midia.\n"; return 3;
    }
    av_dict_free(&dict);
    if (avformat_find_stream_info(fmt, nullptr) < 0) {
        avformat_close_input(&fmt); avformat_network_deinit(); return 4;
    }

    int stream = av_find_best_stream(fmt, AVMEDIA_TYPE_AUDIO, -1, -1, nullptr, 0);
    if (opt.audioStream >= 0 && opt.audioStream < static_cast<int>(fmt->nb_streams) &&
        fmt->streams[opt.audioStream]->codecpar->codec_type == AVMEDIA_TYPE_AUDIO) stream = opt.audioStream;
    if (stream < 0) {
        avformat_close_input(&fmt); avformat_network_deinit();
        std::cerr << "Nenhuma faixa de audio encontrada.\n"; return 5;
    }

    AVStream* as = fmt->streams[stream];
    const AVCodec* codec = avcodec_find_decoder(as->codecpar->codec_id);
    AVCodecContext* dc = codec ? avcodec_alloc_context3(codec) : nullptr;
    if (!codec || !dc) { avcodec_free_context(&dc); avformat_close_input(&fmt); avformat_network_deinit(); return 6; }
    avcodec_parameters_to_context(dc, as->codecpar);
    dc->thread_count = 0;
    if (avcodec_open2(dc, codec, nullptr) < 0) {
        avcodec_free_context(&dc); avformat_close_input(&fmt); avformat_network_deinit(); return 7;
    }

    if (SDL_Init(SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0) {
        avcodec_free_context(&dc); avformat_close_input(&fmt); avformat_network_deinit();
        std::cerr << "SDL audio: " << SDL_GetError() << "\n"; return 8;
    }
    AudioEngine audio;
    if (!audio.open(48000, 2, opt.audioDevice.empty() ? nullptr : opt.audioDevice.c_str())) {
        SDL_Quit(); avcodec_free_context(&dc); avformat_close_input(&fmt); avformat_network_deinit();
        std::cerr << "Nao foi possivel abrir a saida de audio.\n"; return 9;
    }
    audio.setVolume(opt.volume);
    if (opt.muted) audio.toggleMute();
    bool paused = opt.paused;
    audio.setPaused(paused);

    const double duration = (fmt->duration > 0 && fmt->duration != AV_NOPTS_VALUE)
        ? fmt->duration / static_cast<double>(AV_TIME_BASE) : 0.0;

    struct Commands { std::mutex mutex; std::deque<std::string> lines; std::atomic<bool> closed{false}; };
    auto commands = std::make_shared<Commands>();
    if (opt.ipc) std::thread([commands] {
        std::string line;
        while (std::getline(std::cin, line)) {
            if (line.size() > 256) continue;
            std::lock_guard<std::mutex> lock(commands->mutex);
            if (commands->lines.size() < 128) commands->lines.push_back(line);
        }
        commands->closed = true;
    }).detach();

    bool quit = false;
    bool ended = false;
    double logicalPosition = opt.startSeconds;
    auto lastReport = std::chrono::steady_clock::now() - std::chrono::seconds(1);

    auto seekTo = [&](double seconds) {
        if (duration <= 0.0) return;
        seconds = std::clamp(seconds, 0.0, duration);
        if (av_seek_frame(fmt, -1, static_cast<int64_t>(seconds * AV_TIME_BASE), AVSEEK_FLAG_BACKWARD) >= 0) {
            avcodec_flush_buffers(dc); audio.clear(); logicalPosition = seconds;
        }
    };
    if (opt.startSeconds > 0.0) seekTo(opt.startSeconds);

    auto report = [&](bool force = false) {
        auto now = std::chrono::steady_clock::now();
        double c = audio.clockSeconds();
        if (std::isfinite(c) && c >= 0.0) logicalPosition = c;
        if (opt.ipc && (force || now - lastReport >= std::chrono::milliseconds(200))) {
            std::cout << "NEO_STATUS " << (paused ? "paused" : "playing") << " "
                      << logicalPosition << " " << duration << std::endl;
            lastReport = now;
        }
    };

    auto pumpCommands = [&] {
        std::deque<std::string> pending;
        { std::lock_guard<std::mutex> lock(commands->mutex); pending.swap(commands->lines); }
        for (const auto& line : pending) {
            std::istringstream in(line); std::string cmd; double value = 0.0; in >> cmd >> value;
            if (cmd == "stop") quit = true;
            else if (cmd == "pause") { paused = !paused; audio.setPaused(paused); }
            else if (cmd == "seek" && std::isfinite(value)) seekTo(value);
            else if (cmd == "volume" && std::isfinite(value)) audio.setVolume(static_cast<float>(value));
            else if (cmd == "mute") audio.toggleMute();
        }
        report();
    };

    AVPacket* pkt = av_packet_alloc();
    AVFrame* frame = av_frame_alloc();
    while (!quit) {
        pumpCommands();
        if (paused) { SDL_Delay(15); continue; }
        if (audio.queuedSeconds() > 1.25) { SDL_Delay(8); continue; }
        int rr = av_read_frame(fmt, pkt);
        if (rr < 0) { ended = true; break; }
        if (pkt->stream_index == stream && avcodec_send_packet(dc, pkt) >= 0) {
            while (!quit && avcodec_receive_frame(dc, frame) >= 0) {
                int64_t ts = frame->best_effort_timestamp;
                double pts = ts == AV_NOPTS_VALUE ? -1.0 : ts * av_q2d(as->time_base);
                if (pts >= 0.0 && pts + 0.05 < logicalPosition) continue;
                if (!audio.queue(frame, pts)) { quit = true; break; }
                if (pts >= 0.0) logicalPosition = pts;
                pumpCommands();
            }
        }
        av_packet_unref(pkt);
    }

    if (ended && !quit) {
        avcodec_send_packet(dc, nullptr);
        while (avcodec_receive_frame(dc, frame) >= 0) {
            int64_t ts = frame->best_effort_timestamp;
            double pts = ts == AV_NOPTS_VALUE ? -1.0 : ts * av_q2d(as->time_base);
            audio.queue(frame, pts);
        }
        while (!quit && audio.queuedSeconds() > 0.01) { pumpCommands(); SDL_Delay(10); }
    }

    report(true);
    if (opt.ipc) std::cout << "NEO_END " << (quit ? "stopped" : "ended") << std::endl;
    av_frame_free(&frame); av_packet_free(&pkt); audio.close(); SDL_Quit();
    avcodec_free_context(&dc); avformat_close_input(&fmt); avformat_network_deinit();
    return 0;
}
}

int main(int argc, char** argv) {
#ifdef _WIN32
    int count = 0; LPWSTR* wide = CommandLineToArgvW(GetCommandLineW(), &count);
    if (!wide) return 2;
    std::vector<std::string> utf8; utf8.reserve(count);
    for (int i = 0; i < count; ++i) {
        int n = WideCharToMultiByte(CP_UTF8, 0, wide[i], -1, nullptr, 0, nullptr, nullptr);
        std::string s(static_cast<size_t>(n), '\0'); WideCharToMultiByte(CP_UTF8, 0, wide[i], -1, s.data(), n, nullptr, nullptr);
        if (!s.empty()) s.pop_back(); utf8.push_back(std::move(s));
    }
    LocalFree(wide); std::vector<char*> args; for (auto& s : utf8) args.push_back(s.data());
    return runAudio(parse(count, args.data()));
#else
    return runAudio(parse(argc, argv));
#endif
}
