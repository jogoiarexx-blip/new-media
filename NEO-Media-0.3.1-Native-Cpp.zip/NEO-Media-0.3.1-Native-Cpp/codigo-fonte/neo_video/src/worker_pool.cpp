#include "worker_pool.hpp"
#include <algorithm>

WorkerPool::WorkerPool(unsigned threads) {
    if (threads == 0) threads = std::thread::hardware_concurrency();
    threads = std::clamp(threads, 1u, 16u);
    // Keep one logical core available for demux/audio/UI where possible.
    if (threads > 2) --threads;
    for (unsigned i = 0; i < threads; ++i) workers_.emplace_back([this]{ loop(); });
}

WorkerPool::~WorkerPool() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        stop_ = true;
    }
    cv_.notify_all();
    for (auto& t : workers_) if (t.joinable()) t.join();
}

void WorkerPool::loop() {
    for (;;) {
        std::function<void()> task;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait(lock, [this]{ return stop_ || !tasks_.empty(); });
            if (stop_ && tasks_.empty()) return;
            task = std::move(tasks_.front());
            tasks_.pop();
        }
        task();
    }
}

void WorkerPool::parallelFor(int begin, int end, int minRows, const std::function<void(int,int)>& fn) {
    const int total = end - begin;
    if (total <= 0) return;
    const unsigned n = threadCount();
    if (n <= 1 || total <= minRows) { fn(begin, end); return; }

    const int chunks = std::min<int>(static_cast<int>(n), std::max(1, (total + minRows - 1) / minRows));
    const int step = (total + chunks - 1) / chunks;
    std::vector<std::future<void>> waits;
    waits.reserve(chunks);

    for (int i = 0; i < chunks; ++i) {
        const int a = begin + i * step;
        const int b = std::min(end, a + step);
        if (a >= b) break;
        auto p = std::make_shared<std::promise<void>>();
        waits.push_back(p->get_future());
        {
            std::lock_guard<std::mutex> lock(mutex_);
            tasks_.push([fn, a, b, p]{
                try { fn(a,b); p->set_value(); }
                catch (...) { p->set_exception(std::current_exception()); }
            });
        }
        cv_.notify_one();
    }
    for (auto& f : waits) f.get();
}
