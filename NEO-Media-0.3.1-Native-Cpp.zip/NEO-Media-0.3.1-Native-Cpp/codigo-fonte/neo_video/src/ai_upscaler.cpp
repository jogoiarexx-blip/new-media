#include "ai_upscaler.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <array>
#include <thread>
#include <iostream>
extern "C" {
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
}
#ifdef NEO_VIDEO_ENABLE_ONNX
#include <onnxruntime_cxx_api.h>
#endif

struct AiUpscaler::Impl {
#ifdef NEO_VIDEO_ENABLE_ONNX
    Ort::Env env{ORT_LOGGING_LEVEL_WARNING, "neo-video-ai"};
    Ort::SessionOptions sessionOptions;
    std::unique_ptr<Ort::Session> session;
    std::string inputName, outputName;
    std::vector<int64_t> inputShape;
    std::vector<int64_t> outputShape;
#endif
};

AiUpscaler::AiUpscaler() : impl_(std::make_unique<Impl>()) {
#ifdef NEO_VIDEO_ENABLE_ONNX
    info_.compiled = true;
    info_.backend = "ONNX Runtime CPU";
#else
    info_.compiled = false;
    info_.backend = "Lanczos fallback";
#endif
}
AiUpscaler::~AiUpscaler() = default;

bool AiUpscaler::load(const std::string& modelPath, int tile) {
    unload();
    info_.model = modelPath;
    info_.tile = std::max(64, tile);
#ifdef NEO_VIDEO_ENABLE_ONNX
    try {
        unsigned hw = std::max(1u, std::thread::hardware_concurrency());
        impl_->sessionOptions.SetIntraOpNumThreads(static_cast<int>(std::max(1u, hw > 2 ? hw - 2 : 1u)));
        impl_->sessionOptions.SetInterOpNumThreads(1);
        impl_->sessionOptions.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);
#ifdef _WIN32
        std::wstring wide(modelPath.begin(), modelPath.end());
        impl_->session = std::make_unique<Ort::Session>(impl_->env, wide.c_str(), impl_->sessionOptions);
#else
        impl_->session = std::make_unique<Ort::Session>(impl_->env, modelPath.c_str(), impl_->sessionOptions);
#endif
        Ort::AllocatorWithDefaultOptions allocator;
        auto in = impl_->session->GetInputNameAllocated(0, allocator);
        auto out = impl_->session->GetOutputNameAllocated(0, allocator);
        impl_->inputName = in.get(); impl_->outputName = out.get();
        auto iti = impl_->session->GetInputTypeInfo(0).GetTensorTypeAndShapeInfo();
        auto oti = impl_->session->GetOutputTypeInfo(0).GetTensorTypeAndShapeInfo();
        impl_->inputShape = iti.GetShape(); impl_->outputShape = oti.GetShape();
        if (impl_->inputShape.size()!=4 || impl_->outputShape.size()!=4) throw std::runtime_error("model must use 4D NCHW tensors");
        int64_t ih=impl_->inputShape[2], iw=impl_->inputShape[3], oh=impl_->outputShape[2], ow=impl_->outputShape[3];
        int scale=1;
        if(ih>0&&iw>0&&oh>0&&ow>0){ int sy=static_cast<int>(oh/ih), sx=static_cast<int>(ow/iw); if(sx==sy&&sx>=1) scale=sx; }
        info_.scale = scale;
        info_.modelLoaded = true; enabled_ = true; info_.active = true;
        return true;
    } catch(const std::exception& e) {
        std::cerr << "ONNX load failed: " << e.what() << "\n";
        unload(); info_.model=modelPath; info_.tile=tile; return false;
    }
#else
    (void)modelPath; (void)tile;
    return false;
#endif
}

void AiUpscaler::unload() {
#ifdef NEO_VIDEO_ENABLE_ONNX
    impl_->session.reset(); impl_->inputName.clear(); impl_->outputName.clear(); impl_->inputShape.clear(); impl_->outputShape.clear();
#endif
    bool compiled=info_.compiled; std::string backend=compiled?"ONNX Runtime CPU":"Lanczos fallback";
    info_={}; info_.compiled=compiled; info_.backend=backend; enabled_=false;
}

FramePtr AiUpscaler::upscale(const AVFrame* src, int targetW, int targetH) {
#ifdef NEO_VIDEO_ENABLE_ONNX
    if(!enabled_ || !info_.modelLoaded || !impl_->session || !src) return {};
    auto started=std::chrono::steady_clock::now();
    int inW=src->width, inH=src->height;
    SwsContext* toRgb=sws_getContext(inW,inH,(AVPixelFormat)src->format,inW,inH,AV_PIX_FMT_RGB24,SWS_BILINEAR,nullptr,nullptr,nullptr);
    if(!toRgb) return {};
    std::vector<uint8_t> rgb((size_t)inW*inH*3); uint8_t* rgbData[4]={rgb.data(),nullptr,nullptr,nullptr}; int rgbLines[4]={inW*3,0,0,0};
    sws_scale(toRgb,src->data,src->linesize,0,inH,rgbData,rgbLines); sws_freeContext(toRgb);

    int tile=std::min(info_.tile,std::min(inW,inH)); int overlap=8; int guessedScale=std::max(1,info_.scale);
    int aiW=inW*guessedScale, aiH=inH*guessedScale;
    std::vector<float> outAccum((size_t)3*aiW*aiH,0.f); std::vector<float> weights((size_t)aiW*aiH,0.f);
    Ort::MemoryInfo mem=Ort::MemoryInfo::CreateCpu(OrtArenaAllocator,OrtMemTypeDefault);
    const char* ins[]={impl_->inputName.c_str()}; const char* outs[]={impl_->outputName.c_str()};
    for(int y=0;y<inH;y+=std::max(1,tile-overlap*2)) for(int x=0;x<inW;x+=std::max(1,tile-overlap*2)){
        int tw=std::min(tile,inW-x), th=std::min(tile,inH-y); if(tw<16||th<16) continue;
        std::vector<float> input((size_t)3*tw*th);
        for(int yy=0;yy<th;++yy) for(int xx=0;xx<tw;++xx){ const uint8_t* p=&rgb[((size_t)(y+yy)*inW+(x+xx))*3]; size_t q=(size_t)yy*tw+xx; input[q]=p[0]/255.f; input[(size_t)tw*th+q]=p[1]/255.f; input[(size_t)2*tw*th+q]=p[2]/255.f; }
        std::array<int64_t,4> shape{1,3,th,tw}; auto tensor=Ort::Value::CreateTensor<float>(mem,input.data(),input.size(),shape.data(),shape.size());
        auto values=impl_->session->Run(Ort::RunOptions{nullptr},ins,&tensor,1,outs,1); if(values.empty()||!values[0].IsTensor()) continue;
        auto osh=values[0].GetTensorTypeAndShapeInfo().GetShape(); if(osh.size()!=4||osh[1]!=3) continue; int oh=(int)osh[2], ow=(int)osh[3]; int sx=std::max(1,ow/tw), sy=std::max(1,oh/th); if(sx!=sy) continue; if(info_.scale==1){info_.scale=sx; guessedScale=sx; aiW=inW*sx; aiH=inH*sy; outAccum.assign((size_t)3*aiW*aiH,0.f); weights.assign((size_t)aiW*aiH,0.f);} float* op=values[0].GetTensorMutableData<float>();
        int ox=x*sx, oy=y*sy;
        for(int yy=0;yy<oh && oy+yy<aiH;++yy) for(int xx=0;xx<ow && ox+xx<aiW;++xx){ int gx=ox+xx, gy=oy+yy; size_t gi=(size_t)gy*aiW+gx, li=(size_t)yy*ow+xx; float w=1.f; weights[gi]+=w; for(int c=0;c<3;++c) outAccum[(size_t)c*aiW*aiH+gi]+=op[(size_t)c*ow*oh+li]*w; }
    }
    std::vector<uint8_t> aiRgb((size_t)aiW*aiH*3); for(size_t i=0;i<(size_t)aiW*aiH;++i){ float w=std::max(weights[i],1e-6f); for(int c=0;c<3;++c) aiRgb[i*3+c]=(uint8_t)std::clamp((int)std::lround(outAccum[(size_t)c*aiW*aiH+i]/w*255.f),0,255); }
    AVFrame* out=av_frame_alloc(); out->format=AV_PIX_FMT_YUV420P; out->width=targetW; out->height=targetH; if(av_frame_get_buffer(out,32)<0){av_frame_free(&out);return{};}
    SwsContext* toYuv=sws_getContext(aiW,aiH,AV_PIX_FMT_RGB24,targetW,targetH,AV_PIX_FMT_YUV420P,SWS_LANCZOS,nullptr,nullptr,nullptr); if(!toYuv){av_frame_free(&out);return{};} uint8_t* srcd[4]={aiRgb.data(),nullptr,nullptr,nullptr}; int srcl[4]={aiW*3,0,0,0}; sws_scale(toYuv,srcd,srcl,0,aiH,out->data,out->linesize); sws_freeContext(toYuv); out->pts=src->pts;
    info_.lastMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count(); info_.active=true; return FramePtr(out);
#else
    (void)src; (void)targetW; (void)targetH; return {};
#endif
}
