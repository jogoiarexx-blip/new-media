#include "frame_processor.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>

static inline uint8_t clamp8(int v) { return static_cast<uint8_t>(std::clamp(v, 0, 255)); }

static FramePtr allocYuv420(int w, int h, int64_t pts) {
    FramePtr f(av_frame_alloc());
    if (!f) return {};
    f->format = AV_PIX_FMT_YUV420P;
    f->width = w;
    f->height = h;
    f->pts = pts;
    if (av_frame_get_buffer(f.get(), 32) < 0) return {};
    if (av_frame_make_writable(f.get()) < 0) return {};
    return f;
}

FrameProcessor::FrameProcessor(unsigned workers) : pool_(workers) {
}

FrameProcessor::~FrameProcessor() { reset(); }

void FrameProcessor::reset() {
    if (sws_) sws_freeContext(sws_);
    if (preSws_) sws_freeContext(preSws_);
    if (postSws_) sws_freeContext(postSws_);
    sws_ = preSws_ = postSws_ = nullptr;
    inW_ = inH_ = outW_ = outH_ = flags_ = 0;
    preW_ = preH_ = 0;
    postInW_ = postInH_ = postOutW_ = postOutH_ = postFlags_ = 0;
    inFmt_ = preFmt_ = AV_PIX_FMT_NONE;
    motionDetector_.reset();
    temporalFilter_.reset();
    analysisCoordinator_.reset();
    lastAnalysis_ = {};
    lastMotionInfo_ = {};
    stats_ = {};
}

bool FrameProcessor::ensureScaler(int inW, int inH, AVPixelFormat inFmt, int outW, int outH, int flags) {
    if (sws_ && inW == inW_ && inH == inH_ && inFmt == inFmt_ && outW == outW_ && outH == outH_ && flags == flags_)
        return true;
    if (sws_) sws_freeContext(sws_);
    sws_ = sws_getContext(inW, inH, inFmt, outW, outH, AV_PIX_FMT_YUV420P, flags, nullptr, nullptr, nullptr);
    if (!sws_) return false;
    inW_ = inW; inH_ = inH; inFmt_ = inFmt; outW_ = outW; outH_ = outH; flags_ = flags;
    return true;
}

bool FrameProcessor::ensurePreScaler(int inW, int inH, AVPixelFormat inFmt) {
    if (preSws_ && inW == preW_ && inH == preH_ && inFmt == preFmt_) return true;
    if (preSws_) sws_freeContext(preSws_);
    preSws_ = sws_getContext(inW, inH, inFmt, inW, inH, AV_PIX_FMT_YUV420P,
                             SWS_BICUBIC | SWS_ACCURATE_RND, nullptr, nullptr, nullptr);
    if (!preSws_) return false;
    preW_ = inW; preH_ = inH; preFmt_ = inFmt;
    return true;
}

bool FrameProcessor::ensurePostScaler(int inW, int inH, int outW, int outH, int flags) {
    if (postSws_ && inW == postInW_ && inH == postInH_ && outW == postOutW_ &&
        outH == postOutH_ && flags == postFlags_) return true;
    if (postSws_) sws_freeContext(postSws_);
    postSws_ = sws_getContext(inW, inH, AV_PIX_FMT_YUV420P, outW, outH, AV_PIX_FMT_YUV420P,
                              flags, nullptr, nullptr, nullptr);
    if (!postSws_) return false;
    postInW_ = inW; postInH_ = inH; postOutW_ = outW; postOutH_ = outH; postFlags_ = flags;
    return true;
}

FramePtr FrameProcessor::process(const AVFrame* src, const ProcessingOptions& opt) {
    if (!src || src->width <= 0 || src->height <= 0) return {};

    stats_ = {};
    int outW = opt.target_width > 0 ? opt.target_width : src->width;
    int outH = opt.target_height > 0 ? opt.target_height : src->height;
    outW &= ~1; outH &= ~1;
    if (outW < 2 || outH < 2) return {};

    int scaleFlags = SWS_BICUBIC | SWS_ACCURATE_RND;
    switch (opt.preset) {
        case QualityPreset::Economy:  scaleFlags = SWS_FAST_BILINEAR; break;
        case QualityPreset::Balanced: scaleFlags = SWS_BICUBIC | SWS_ACCURATE_RND; break;
        case QualityPreset::Quality:  scaleFlags = SWS_LANCZOS | SWS_ACCURATE_RND; break;
        case QualityPreset::Ultra:    scaleFlags = SWS_LANCZOS | SWS_ACCURATE_RND | SWS_FULL_CHR_H_INT; break;
    }

    const bool highQuality = opt.preset == QualityPreset::Quality || opt.preset == QualityPreset::Ultra;
    const bool lowResSource = src->width <= 1280 && src->height <= 720 && (outW > src->width || outH > src->height);

    FramePtr pre;
    const AVFrame* scaleSource = src;

    if (opt.enabled && opt.sourceAware && lowResSource && ensurePreScaler(src->width, src->height, static_cast<AVPixelFormat>(src->format))) {
        pre = allocYuv420(src->width & ~1, src->height & ~1, src->pts);
        if (pre) {
            sws_scale(preSws_, src->data, src->linesize, 0, src->height, pre->data, pre->linesize);

            auto cached = analysisCoordinator_.analyze(
                pre->data[0], pre->linesize[0],
                pre->data[1], pre->linesize[1],
                pre->data[2], pre->linesize[2],
                pre->width, pre->height
            );
            lastAnalysis_ = cached.content;
            lastMotionInfo_ = cached.motion;
            stats_.lastMotion = lastMotionInfo_.motion_score;

            auto recovery = preUpscaleRecovery_.decide(
                pre->width, pre->height, lastAnalysis_, lastMotionInfo_, 0.0, 0.0
            );
            if (recovery.enabled) {
                lowResRecovery_.processLuma(pre->data[0], pre->width, pre->height, pre->linesize[0], recovery.cfg);
            }

            scaleSource = pre.get();
            stats_.sourceAwareUsed = true;
        }
    }

    const auto plan = multiPass_.plan(scaleSource->width, scaleSource->height, outW, outH, highQuality);
    FramePtr out;

    if (plan.pass_count == 2 && scaleSource->format == AV_PIX_FMT_YUV420P) {
        FramePtr mid = allocYuv420(plan.pass1_w & ~1, plan.pass1_h & ~1, src->pts);
        if (mid && ensurePostScaler(scaleSource->width, scaleSource->height, mid->width, mid->height, scaleFlags)) {
            sws_scale(postSws_, scaleSource->data, scaleSource->linesize, 0, scaleSource->height, mid->data, mid->linesize);
            out = allocYuv420(outW, outH, src->pts);
            if (out && ensurePostScaler(mid->width, mid->height, outW, outH, scaleFlags)) {
                sws_scale(postSws_, mid->data, mid->linesize, 0, mid->height, out->data, out->linesize);
            }
        }
    }

    if (!out) {
        if (!ensureScaler(scaleSource->width, scaleSource->height,
                          static_cast<AVPixelFormat>(scaleSource->format),
                          outW, outH, scaleFlags)) return {};
        out = allocYuv420(outW, outH, src->pts);
        if (!out) return {};
        sws_scale(sws_, scaleSource->data, scaleSource->linesize, 0, scaleSource->height, out->data, out->linesize);
    }

    if (!opt.enabled) return out;

    if (opt.sourceAware) {
        auto cached = analysisCoordinator_.analyze(
            out->data[0], out->linesize[0],
            out->data[1], out->linesize[1],
            out->data[2], out->linesize[2],
            outW, outH
        );
        lastAnalysis_ = cached.content;
        lastMotionInfo_ = cached.motion;
        stats_.lastBlockiness = lastAnalysis_.blockiness;
        stats_.lastLumaNoise = lastAnalysis_.luma_noise;
        stats_.lastChromaNoise = lastAnalysis_.chroma_noise;
        stats_.lastMotion = lastMotionInfo_.motion_score;
        stats_.sourceAwareUsed = true;
    }

    const float c = std::clamp(opt.contrast, 0.0f, 2.0f);
    const float s = std::clamp(opt.saturation, 0.0f, 2.0f);
    const float g = std::clamp(opt.gamma, 0.5f, 2.0f);
    const int b = static_cast<int>(std::clamp(opt.brightness, -1.0f, 1.0f) * 64.0f);

    uint8_t yLut[256];
    for (int i = 0; i < 256; ++i) {
        float normalized = std::clamp((i - 16) / 219.0f, 0.0f, 1.0f);
        normalized = std::pow(normalized, 1.0f / g);
        int yy = static_cast<int>((normalized * 219.0f) * c + 16.0f + b - (c - 1.0f) * 109.5f);
        yLut[i] = clamp8(yy);
    }

    pool_.parallelFor(0, outH, 64, [&](int y0, int y1) {
        for (int y = y0; y < y1; ++y) {
            uint8_t* row = out->data[0] + y * out->linesize[0];
            for (int x = 0; x < outW; ++x) row[x] = yLut[row[x]];
        }
    });

    for (int plane = 1; plane <= 2; ++plane) {
        pool_.parallelFor(0, outH / 2, 32, [&](int y0, int y1) {
            for (int y = y0; y < y1; ++y) {
                uint8_t* row = out->data[plane] + y * out->linesize[plane];
                for (int x = 0; x < outW / 2; ++x)
                    row[x] = clamp8(static_cast<int>((row[x] - 128) * s + 128));
            }
        });
    }

    FilterDecision fd{};
    if (opt.sourceAware) fd = decisionEngine_.decide(lastAnalysis_, 0.0, 0.0, highQuality);

    if (fd.deblock) {
        adaptiveDeblock_.processLuma(out->data[0], outW, outH, out->linesize[0], fd.deblock_strength);
        stats_.deblockUsed = true;
    }

    if (fd.chroma_enhance) {
        const int cw = outW / 2, ch = outH / 2;
        chromaEnhancer_.processPlane(out->data[1], cw, ch, out->linesize[1], fd.chroma_denoise, fd.chroma_recover);
        chromaEnhancer_.processPlane(out->data[2], cw, ch, out->linesize[2], fd.chroma_denoise, fd.chroma_recover);
        stats_.chromaUsed = true;
    }

    float denoise = (opt.preset == QualityPreset::Economy) ? 0.0f : std::clamp(opt.denoise, 0.0f, 1.0f);
    if (opt.sourceAware) {
        auto dd = adaptiveDenoise_.analyzeLuma(out->data[0], outW, outH, out->linesize[0]);
        if (!dd.enabled) denoise *= 0.35f;
        else denoise = std::min(denoise, static_cast<float>(dd.strength));
    }

    if (denoise > 0.001f && outW > 2 && outH > 2) {
        std::vector<uint8_t> srcY(static_cast<size_t>(outW) * outH);
        for (int y = 0; y < outH; ++y)
            std::memcpy(srcY.data() + static_cast<size_t>(y) * outW,
                        out->data[0] + y * out->linesize[0], outW);
        const float mix = 0.35f * denoise;
        pool_.parallelFor(1, outH - 1, 48, [&](int y0, int y1) {
            for (int y = y0; y < y1; ++y) {
                uint8_t* dst = out->data[0] + y * out->linesize[0];
                for (int x = 1; x < outW - 1; ++x) {
                    const int i = y * outW + x;
                    const int center = srcY[i];
                    int sum = center * 4, weight = 4;
                    const int ns[4] = {srcY[i-1], srcY[i+1], srcY[i-outW], srcY[i+outW]};
                    for (int n : ns) if (std::abs(n-center) < 18) { sum += n; ++weight; }
                    const int avg = sum / weight;
                    dst[x] = clamp8(static_cast<int>(center * (1.0f-mix) + avg * mix));
                }
            }
        });
    }

    float deband = (opt.preset == QualityPreset::Ultra || opt.preset == QualityPreset::Quality)
        ? std::clamp(opt.deband, 0.0f, 1.0f) : 0.0f;
    if (opt.sourceAware && !fd.deband) deband *= 0.35f;

    if (deband > 0.001f) {
        std::vector<uint8_t> debandSrc(static_cast<size_t>(outW) * outH);
        for (int y = 0; y < outH; ++y)
            std::memcpy(debandSrc.data() + static_cast<size_t>(y) * outW,
                        out->data[0] + y * out->linesize[0], outW);
        pool_.parallelFor(1, outH - 1, 48, [&](int y0, int y1) {
            for (int y = y0; y < y1; ++y) {
                uint8_t* row = out->data[0] + y * out->linesize[0];
                for (int x = 1; x < outW - 1; ++x) {
                    const int i = y * outW + x;
                    const int center = debandSrc[i];
                    const int avg = (debandSrc[i-1] + debandSrc[i+1] +
                                     debandSrc[i-outW] + debandSrc[i+outW]) / 4;
                    if (std::abs(center - avg) <= 3)
                        row[x] = clamp8(static_cast<int>(
                            center*(1.0f-0.25f*deband) + avg*(0.25f*deband)));
                }
            }
        });
    }

    if (plan.detail_reconstruction || fd.detail_reconstruct) {
        const double amount = highQuality ? 0.22 : 0.12;
        detailReconstruction_.enhanceLuma(out->data[0], outW, outH, out->linesize[0], amount);
        stats_.detailUsed = true;
    }

    if (opt.temporal) {
        MotionTemporalConfig tc;
        tc.strength = highQuality ? 0.10 : 0.06;
        tc.pixel_threshold = lastMotionInfo_.high_motion ? 6 : 10;
        temporalFilter_.processLuma(out->data[0], outW, outH, out->linesize[0], lastMotionInfo_, tc);
        stats_.temporalUsed = !lastMotionInfo_.scene_cut;
    }

    if (opt.postUpscaleCleanup && highQuality) {
        PostUpscaleConfig pc;
        pc.anti_ringing = opt.preset == QualityPreset::Ultra ? 0.36 : 0.26;
        pc.anti_alias = opt.preset == QualityPreset::Ultra ? 0.20 : 0.14;
        pc.text_restore = 0.16;
        postCleanup_.processLuma(out->data[0], outW, outH, out->linesize[0], pc);
        stats_.antiRingingUsed = true;
        stats_.antiAliasUsed = true;
        stats_.textRestoreUsed = true;
    }

    const float amount = std::clamp(opt.sharpen, 0.0f, 1.0f);
    if (amount > 0.001f && outW > 2 && outH > 2) {
        edgeSharpen_.processLuma(out->data[0], outW, outH, out->linesize[0], amount);
    }

    return out;
}
