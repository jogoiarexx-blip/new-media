#include "audio_engine.hpp"
extern "C" {
#include <libavutil/channel_layout.h>
#include <libavutil/samplefmt.h>
}
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>

AudioEngine::~AudioEngine() { close(); }

bool AudioEngine::open(int sampleRate, int channels, const char* device) {
    close();
    SDL_AudioSpec want{};
    want.freq = sampleRate;
    want.format = AUDIO_F32SYS;
    want.channels = static_cast<Uint8>(channels);
    want.samples = 2048;
    want.callback = nullptr;
    device_ = SDL_OpenAudioDevice(device, 0, &want, &obtained_, SDL_AUDIO_ALLOW_FREQUENCY_CHANGE);
    if (!device_) return false;
    SDL_PauseAudioDevice(device_, 0);
    return true;
}

bool AudioEngine::ensureResampler(const AVFrame* frame) {
    if (!frame || !device_) return false;
    AVChannelLayout layout{};
    if (frame->ch_layout.nb_channels > 0) av_channel_layout_copy(&layout, &frame->ch_layout);
    else av_channel_layout_default(&layout, 2);
    const int fmt = frame->format;
    const int rate = frame->sample_rate > 0 ? frame->sample_rate : 48000;
    bool same = swr_ && inRate_ == rate && inFormat_ == fmt && haveInLayout_ && av_channel_layout_compare(&inLayout_, &layout) == 0;
    if (same) { av_channel_layout_uninit(&layout); return true; }

    swr_free(&swr_);
    if (haveInLayout_) av_channel_layout_uninit(&inLayout_);
    av_channel_layout_copy(&inLayout_, &layout); haveInLayout_ = true;
    inRate_ = rate; inFormat_ = fmt;
    AVChannelLayout outLayout{}; av_channel_layout_default(&outLayout, obtained_.channels);
    int ret = swr_alloc_set_opts2(&swr_, &outLayout, AV_SAMPLE_FMT_FLT, obtained_.freq,
                                  &layout, static_cast<AVSampleFormat>(fmt), rate, 0, nullptr);
    av_channel_layout_uninit(&outLayout);
    av_channel_layout_uninit(&layout);
    if (ret < 0 || !swr_) return false;
    return swr_init(swr_) >= 0;
}

bool AudioEngine::queue(const AVFrame* frame, double ptsSeconds) {
    if (!ensureResampler(frame)) return false;
    if (!haveFirstPts_ && std::isfinite(ptsSeconds) && ptsSeconds >= 0.0) { firstPts_ = ptsSeconds; haveFirstPts_ = true; }
    const int outMax = av_rescale_rnd(swr_get_delay(swr_, inRate_) + frame->nb_samples,
                                     obtained_.freq, inRate_, AV_ROUND_UP);
    std::vector<float> pcm(static_cast<size_t>(outMax) * obtained_.channels);
    uint8_t* outData[1] = { reinterpret_cast<uint8_t*>(pcm.data()) };
    int outSamples = swr_convert(swr_, outData, outMax,
                                 const_cast<const uint8_t**>(frame->extended_data), frame->nb_samples);
    if (outSamples <= 0) return false;

    float gain = muted_ ? 0.0f : volume_;
    if (gain != 1.0f) {
        const size_t n = static_cast<size_t>(outSamples) * obtained_.channels;
        for (size_t i=0; i<n; ++i) pcm[i] = std::clamp(pcm[i] * gain, -1.0f, 1.0f);
    }
    const Uint32 bytes = static_cast<Uint32>(outSamples * obtained_.channels * sizeof(float));
    if (SDL_QueueAudio(device_, pcm.data(), bytes) != 0) return false;
    submittedFrames_ += outSamples;
    return true;
}

void AudioEngine::setPaused(bool paused) { if (device_) SDL_PauseAudioDevice(device_, paused ? 1 : 0); }
void AudioEngine::setVolume(float volume) { volume_ = std::clamp(volume, 0.0f, 1.5f); }
void AudioEngine::toggleMute() { muted_ = !muted_; }

void AudioEngine::clear() {
    if (device_) SDL_ClearQueuedAudio(device_);
    submittedFrames_ = 0; haveFirstPts_ = false; firstPts_ = 0.0;
    if (swr_) swr_close(swr_), swr_init(swr_);
}

double AudioEngine::clockSeconds() const {
    if (!device_ || !haveFirstPts_ || obtained_.freq <= 0 || obtained_.channels <= 0) return -1.0;
    const Uint32 queued = SDL_GetQueuedAudioSize(device_);
    const int bytesPerFrame = obtained_.channels * static_cast<int>(sizeof(float));
    const int64_t queuedFrames = bytesPerFrame > 0 ? queued / bytesPerFrame : 0;
    const int64_t played = std::max<int64_t>(0, submittedFrames_ - queuedFrames);
    return firstPts_ + static_cast<double>(played) / obtained_.freq;
}

void AudioEngine::close() {
    if (device_) { SDL_ClearQueuedAudio(device_); SDL_CloseAudioDevice(device_); device_ = 0; }
    swr_free(&swr_);
    if (haveInLayout_) { av_channel_layout_uninit(&inLayout_); haveInLayout_ = false; }
    submittedFrames_ = 0; haveFirstPts_ = false;
}

double AudioEngine::queuedSeconds() const {
    if (!device_ || obtained_.freq <= 0) return 0.0;
    return static_cast<double>(SDL_GetQueuedAudioSize(device_)) / (obtained_.freq * obtained_.channels * sizeof(float));
}
