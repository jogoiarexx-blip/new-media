#include "recorder.hpp"
extern "C" {
#include <libavutil/channel_layout.h>
#include <libavutil/opt.h>
#include <libavutil/samplefmt.h>
}
#include <algorithm>
#include <cstring>
#include <iostream>

Recorder::~Recorder(){ stop(); }

bool Recorder::writeEncodedPacket(AVCodecContext* enc, AVStream* stream, AVPacket* pkt) {
    av_packet_rescale_ts(pkt, enc->time_base, stream->time_base);
    pkt->stream_index = stream->index;
    return av_interleaved_write_frame(fmt_, pkt) >= 0;
}

void Recorder::cleanup(bool writeTrailer) {
    if (writeTrailer && fmt_ && started_) av_write_trailer(fmt_);
    if (fmt_ && !(fmt_->oformat->flags & AVFMT_NOFILE) && fmt_->pb) avio_closep(&fmt_->pb);
    swr_free(&audioSwr_);
    if (audioFifo_) av_audio_fifo_free(audioFifo_);
    audioFifo_ = nullptr;
    if (haveAudioInLayout_) { av_channel_layout_uninit(&audioInLayout_); haveAudioInLayout_ = false; }
    avcodec_free_context(&videoEnc_); avcodec_free_context(&audioEnc_);
    if (fmt_) avformat_free_context(fmt_);
    fmt_ = nullptr; videoStream_ = nullptr; audioStream_ = nullptr; started_ = false;
    audioInRate_ = 0; audioInFormat_ = -1; audioPts_ = 0;
}

bool Recorder::initAudioEncoder(const RecorderOptions& options) {
    const AVCodec* codec = avcodec_find_encoder(AV_CODEC_ID_AAC);
    if (!codec) return false;
    audioStream_ = avformat_new_stream(fmt_, nullptr);
    audioEnc_ = avcodec_alloc_context3(codec);
    if (!audioStream_ || !audioEnc_) return false;
    audioEnc_->sample_rate = options.audioSampleRate;
    audioEnc_->bit_rate = options.audioBitrate;
#if LIBAVCODEC_VERSION_MAJOR >= 61
    const void* configs = nullptr; int count = 0;
    audioEnc_->sample_fmt = AV_SAMPLE_FMT_FLTP;
    if (avcodec_get_supported_config(audioEnc_, codec, AV_CODEC_CONFIG_SAMPLE_FORMAT, 0, &configs, &count) >= 0 && configs && count > 0)
        audioEnc_->sample_fmt = static_cast<const AVSampleFormat*>(configs)[0];
#else
    audioEnc_->sample_fmt = codec->sample_fmts ? codec->sample_fmts[0] : AV_SAMPLE_FMT_FLTP;
#endif
    av_channel_layout_default(&audioEnc_->ch_layout, 2);
    audioEnc_->time_base = AVRational{1, audioEnc_->sample_rate};
    if (fmt_->oformat->flags & AVFMT_GLOBALHEADER) audioEnc_->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;
    if (avcodec_open2(audioEnc_, codec, nullptr) < 0) return false;
    if (avcodec_parameters_from_context(audioStream_->codecpar, audioEnc_) < 0) return false;
    audioStream_->time_base = audioEnc_->time_base;
    audioFifo_ = av_audio_fifo_alloc(audioEnc_->sample_fmt, audioEnc_->ch_layout.nb_channels, 1);
    return audioFifo_ != nullptr;
}

bool Recorder::start(const std::string& path, int width, int height, AVRational fps, bool enableAudio, const RecorderOptions& options) {
    stop(); path_ = path; wantAudio_ = enableAudio;
    if (avformat_alloc_output_context2(&fmt_, nullptr, nullptr, path.c_str()) < 0 || !fmt_) return false;
    const AVCodec* codec = avcodec_find_encoder_by_name("libx264");
    if (!codec) codec = avcodec_find_encoder(AV_CODEC_ID_H264);
    if (!codec) { cleanup(false); return false; }
    videoStream_ = avformat_new_stream(fmt_, nullptr); videoEnc_ = avcodec_alloc_context3(codec);
    if (!videoStream_ || !videoEnc_) { cleanup(false); return false; }
    if (!fps.num || !fps.den) fps = AVRational{30,1};
    videoEnc_->codec_id=codec->id; videoEnc_->codec_type=AVMEDIA_TYPE_VIDEO; videoEnc_->width=width&~1; videoEnc_->height=height&~1;
    videoEnc_->pix_fmt=AV_PIX_FMT_YUV420P; videoEnc_->time_base=av_inv_q(fps); videoEnc_->framerate=fps;
    videoEnc_->bit_rate=options.bitrate; videoEnc_->gop_size=60; videoEnc_->max_b_frames=2;
    if (fmt_->oformat->flags & AVFMT_GLOBALHEADER) videoEnc_->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;
    AVDictionary* opts=nullptr; av_dict_set(&opts,"preset",options.preset.c_str(),0); av_dict_set_int(&opts,"crf",options.crf,0);
    int ret=avcodec_open2(videoEnc_,codec,&opts); av_dict_free(&opts);
    if (ret<0 || avcodec_parameters_from_context(videoStream_->codecpar,videoEnc_)<0) { cleanup(false); return false; }
    videoStream_->time_base=videoEnc_->time_base;
    if (enableAudio && !initAudioEncoder(options)) {
        std::cerr << "Aviso: encoder AAC indisponivel; gravacao seguira somente com video.\n";
        avcodec_free_context(&audioEnc_); audioStream_ = nullptr; wantAudio_ = false;
    }
    if (!(fmt_->oformat->flags & AVFMT_NOFILE) && avio_open(&fmt_->pb,path.c_str(),AVIO_FLAG_WRITE)<0) { cleanup(false); return false; }
    if (avformat_write_header(fmt_,nullptr)<0) { cleanup(false); return false; }
    started_=true; return true;
}

bool Recorder::writeVideo(const AVFrame* frame, int64_t pts) {
    if (!started_ || !videoEnc_ || !frame) return false;
    AVFrame* f=av_frame_clone(frame); if(!f) return false; f->pts=pts;
    int ret=avcodec_send_frame(videoEnc_,f); av_frame_free(&f); if(ret<0) return false;
    AVPacket* pkt=av_packet_alloc(); if(!pkt) return false; bool ok=true;
    while((ret=avcodec_receive_packet(videoEnc_,pkt))>=0){ if(!writeEncodedPacket(videoEnc_,videoStream_,pkt)) ok=false; av_packet_unref(pkt); if(!ok) break; }
    av_packet_free(&pkt); return ok && (ret==AVERROR(EAGAIN)||ret==AVERROR_EOF);
}

bool Recorder::ensureAudioResampler(const AVFrame* frame) {
    if (!audioEnc_ || !frame) return false;
    AVChannelLayout in{}; if(frame->ch_layout.nb_channels>0) av_channel_layout_copy(&in,&frame->ch_layout); else av_channel_layout_default(&in,2);
    int rate=frame->sample_rate>0?frame->sample_rate:audioEnc_->sample_rate; int fmt=frame->format;
    bool same=audioSwr_ && audioInRate_==rate && audioInFormat_==fmt && haveAudioInLayout_ && av_channel_layout_compare(&audioInLayout_,&in)==0;
    if(same){ av_channel_layout_uninit(&in); return true; }
    swr_free(&audioSwr_); if(haveAudioInLayout_) av_channel_layout_uninit(&audioInLayout_);
    av_channel_layout_copy(&audioInLayout_,&in); haveAudioInLayout_=true; audioInRate_=rate; audioInFormat_=fmt;
    int ret=swr_alloc_set_opts2(&audioSwr_,&audioEnc_->ch_layout,audioEnc_->sample_fmt,audioEnc_->sample_rate,&in,static_cast<AVSampleFormat>(fmt),rate,0,nullptr);
    av_channel_layout_uninit(&in); return ret>=0 && audioSwr_ && swr_init(audioSwr_)>=0;
}

bool Recorder::encodeAudioFromFifo(bool flushAll) {
    if(!audioEnc_||!audioFifo_) return true;
    const int frameSize=audioEnc_->frame_size>0?audioEnc_->frame_size:1024;
    while(av_audio_fifo_size(audioFifo_)>=frameSize || (flushAll && av_audio_fifo_size(audioFifo_)>0)){
        int available=av_audio_fifo_size(audioFifo_); int take=std::min(frameSize,available);
        AVFrame* out=av_frame_alloc(); if(!out) return false;
        out->nb_samples=frameSize; out->format=audioEnc_->sample_fmt; out->sample_rate=audioEnc_->sample_rate; av_channel_layout_copy(&out->ch_layout,&audioEnc_->ch_layout);
        if(av_frame_get_buffer(out,0)<0){ av_frame_free(&out); return false; }
        if(take>0 && av_audio_fifo_read(audioFifo_,reinterpret_cast<void**>(out->data),take)<take){ av_frame_free(&out); return false; }
        if(take<frameSize){
            int bps=av_get_bytes_per_sample(audioEnc_->sample_fmt); bool planar=av_sample_fmt_is_planar(audioEnc_->sample_fmt);
            int planes=planar?audioEnc_->ch_layout.nb_channels:1; int chansPerPlane=planar?1:audioEnc_->ch_layout.nb_channels;
            for(int p=0;p<planes;++p) std::memset(out->data[p]+take*bps*chansPerPlane,0,(frameSize-take)*bps*chansPerPlane);
        }
        out->pts=audioPts_; audioPts_+=frameSize;
        int ret=avcodec_send_frame(audioEnc_,out); av_frame_free(&out); if(ret<0) return false;
        AVPacket* pkt=av_packet_alloc(); if(!pkt) return false; bool ok=true;
        while((ret=avcodec_receive_packet(audioEnc_,pkt))>=0){ if(!writeEncodedPacket(audioEnc_,audioStream_,pkt)) ok=false; av_packet_unref(pkt); if(!ok) break; }
        av_packet_free(&pkt); if(!ok) return false;
    }
    return true;
}

bool Recorder::writeAudio(const AVFrame* frame) {
    if(!started_ || !audioEnc_ || !audioFifo_ || !frame) return true;
    if(!ensureAudioResampler(frame)) return false;
    int outMax=av_rescale_rnd(swr_get_delay(audioSwr_,audioInRate_)+frame->nb_samples,audioEnc_->sample_rate,audioInRate_,AV_ROUND_UP);
    AVFrame* tmp=av_frame_alloc(); if(!tmp) return false;
    tmp->nb_samples=outMax; tmp->format=audioEnc_->sample_fmt; tmp->sample_rate=audioEnc_->sample_rate; av_channel_layout_copy(&tmp->ch_layout,&audioEnc_->ch_layout);
    if(av_frame_get_buffer(tmp,0)<0){ av_frame_free(&tmp); return false; }
    int converted=swr_convert(audioSwr_,tmp->data,outMax,const_cast<const uint8_t**>(frame->extended_data),frame->nb_samples);
    if(converted<0){ av_frame_free(&tmp); return false; }
    if(av_audio_fifo_realloc(audioFifo_,av_audio_fifo_size(audioFifo_)+converted)<0){ av_frame_free(&tmp); return false; }
    int written=av_audio_fifo_write(audioFifo_,reinterpret_cast<void**>(tmp->data),converted); av_frame_free(&tmp);
    if(written<converted) return false; return encodeAudioFromFifo(false);
}

void Recorder::stop() {
    if(!fmt_) return;
    if(started_ && audioEnc_){ encodeAudioFromFifo(true); avcodec_send_frame(audioEnc_,nullptr); AVPacket* p=av_packet_alloc(); if(p){ while(avcodec_receive_packet(audioEnc_,p)>=0){ writeEncodedPacket(audioEnc_,audioStream_,p); av_packet_unref(p);} av_packet_free(&p);} }
    if(started_ && videoEnc_){ avcodec_send_frame(videoEnc_,nullptr); AVPacket* p=av_packet_alloc(); if(p){ while(avcodec_receive_packet(videoEnc_,p)>=0){ writeEncodedPacket(videoEnc_,videoStream_,p); av_packet_unref(p);} av_packet_free(&p);} }
    cleanup(true);
}
