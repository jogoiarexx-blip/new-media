#include "video_player.hpp"
#include "offline_exporter.hpp"
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <SDL.h>
#ifdef _WIN32
#include <windows.h>
#include <shellapi.h>
#endif

static QualityPreset parsePreset(const std::string& s) {
    if (s == "economy") return QualityPreset::Economy;
    if (s == "quality") return QualityPreset::Quality;
    if (s == "ultra") return QualityPreset::Ultra;
    return QualityPreset::Balanced;
}

static void help() {
    std::cout << R"(NEO Video v0.21.0 - CPU/AI Enhance Player + HQ Export

PLAYER:
  neo_video <video-ou-stream> [opcoes]

EXPORTACAO OFFLINE (qualidade acima do tempo real):
  neo_video --export <entrada> --output <saida.mp4> [opcoes]

Resolucao:
  --1080p | --1440p | --4k

IA (opcional, build com ONNX Runtime):
  --ai-model caminho/model.onnx
  --ai-tile 192
  --ai

Player / gravacao em tempo real:
  --record saida.mp4
  --preset economy|balanced|quality|ultra
  --no-auto-performance
  --volume 0.0..1.5
  --mute

Exportacao HQ:
  --crf 16                 (menor = mais qualidade/arquivo maior)
  --encoder-preset slow    (ultrafast..veryslow, conforme encoder)
  --bitrate 12000000
  --no-audio
  --sharpen 0.30
  --denoise 0.20
  --deband 0.18
  --contrast 1.07
  --saturation 1.05
  --gamma 1.00
  --brightness 0.00

Exemplo:
  neo_video --export filme.mp4 --output filme_4k.mp4 --4k --preset ultra --ai-model models/upscale_x2.onnx --crf 15 --encoder-preset slow

Controles do player:
  ESPACO pausa | E melhorias | C antes/depois | P qualidade
  I cor | 0 reset | A auto performance | R REC | M mute
  +/- volume | setas imagem | X IA | F fullscreen | ESC sair
)";
}

static int neoMain(int argc, char** argv) {
    if (argc < 2) { help(); return 0; }
    if (std::string(argv[1])=="--audio-devices") {
        if(SDL_Init(SDL_INIT_AUDIO)!=0) return 1;
        for(int i=0;i<SDL_GetNumAudioDevices(0);++i) std::cout<<SDL_GetAudioDeviceName(i,0)<<std::endl;
        SDL_Quit(); return 0;
    }

    if (std::string(argv[1]) == "--export") {
        if (argc < 5) { help(); return 2; }
        ExportOptions opt;
        opt.input = argv[2];
        for (int i=3; i<argc; ++i) {
            std::string a=argv[i];
            if (a=="--output" && i+1<argc) opt.output=argv[++i];
            else if (a=="--1080p") { opt.targetW=1920; opt.targetH=1080; }
            else if (a=="--1440p") { opt.targetW=2560; opt.targetH=1440; }
            else if (a=="--4k") { opt.targetW=3840; opt.targetH=2160; }
            else if (a=="--preset" && i+1<argc) opt.preset=parsePreset(argv[++i]);
            else if (a=="--ai-model" && i+1<argc) { opt.aiModel=argv[++i]; opt.useAi=true; }
            else if (a=="--ai-tile" && i+1<argc) opt.aiTile=std::max(64,std::atoi(argv[++i]));
            else if (a=="--ai") opt.useAi=true;
            else if (a=="--no-audio") opt.copyAudio=false;
            else if (a=="--crf" && i+1<argc) opt.crf=std::atoi(argv[++i]);
            else if (a=="--encoder-preset" && i+1<argc) opt.encoderPreset=argv[++i];
            else if (a=="--bitrate" && i+1<argc) opt.bitrate=std::atoi(argv[++i]);
            else if (a=="--sharpen" && i+1<argc) opt.sharpen=std::strtof(argv[++i],nullptr);
            else if (a=="--denoise" && i+1<argc) opt.denoise=std::strtof(argv[++i],nullptr);
            else if (a=="--deband" && i+1<argc) opt.deband=std::strtof(argv[++i],nullptr);
            else if (a=="--contrast" && i+1<argc) opt.contrast=std::strtof(argv[++i],nullptr);
            else if (a=="--saturation" && i+1<argc) opt.saturation=std::strtof(argv[++i],nullptr);
            else if (a=="--gamma" && i+1<argc) opt.gamma=std::strtof(argv[++i],nullptr);
            else if (a=="--brightness" && i+1<argc) opt.brightness=std::strtof(argv[++i],nullptr);
        }
        if (opt.output.empty()) { std::cerr << "Use --output arquivo.mp4\n"; return 2; }
        OfflineExporter exporter;
        return exporter.run(opt);
    }

    PlayerOptions opt; opt.input=argv[1];
    for (int i=2; i<argc; ++i) {
        std::string a=argv[i];
        if (a=="--paused") opt.startPaused=true;
        else if (a=="--audio-stream" && i+1<argc) opt.audioStream=std::atoi(argv[++i]);
        else if (a=="--start" && i+1<argc) opt.startSeconds=std::max(0.0,std::strtod(argv[++i],nullptr));
        else if (a=="--audio-device" && i+1<argc) opt.audioDevice=argv[++i];
        else if (a=="--ipc") opt.ipc=true;
        else if (a=="--window-id" && i+1<argc) opt.windowId=static_cast<uintptr_t>(std::strtoull(argv[++i],nullptr,10));
        else if (a=="--record" && i+1<argc) opt.recordPath=argv[++i];
        else if (a=="--1080p") { opt.upscaleW=1920; opt.upscaleH=1080; }
        else if (a=="--1440p") { opt.upscaleW=2560; opt.upscaleH=1440; }
        else if (a=="--4k") { opt.upscaleW=3840; opt.upscaleH=2160; }
        else if (a=="--preset" && i+1<argc) opt.preset=parsePreset(argv[++i]);
        else if (a=="--no-auto-performance") opt.autoPerformance=false;
        else if (a=="--mute") opt.startMuted=true;
        else if (a=="--volume" && i+1<argc) opt.volume=std::strtof(argv[++i],nullptr);
        else if (a=="--ai-model" && i+1<argc) { opt.aiModel=argv[++i]; opt.aiEnabled=true; }
        else if (a=="--ai-tile" && i+1<argc) opt.aiTile=std::max(64,std::atoi(argv[++i]));
        else if (a=="--ai") opt.aiEnabled=true;
    }
    VideoPlayer p;
    return p.run(opt);
}

int main(int argc, char** argv) {
#ifdef _WIN32
    int count=0; LPWSTR* wide=CommandLineToArgvW(GetCommandLineW(),&count);
    if(!wide) return 2;
    std::vector<std::string> text; text.reserve(count);
    for(int i=0;i<count;++i){
        int size=WideCharToMultiByte(CP_UTF8,0,wide[i],-1,nullptr,0,nullptr,nullptr);
        std::string value(static_cast<size_t>(size),'\0');
        WideCharToMultiByte(CP_UTF8,0,wide[i],-1,value.data(),size,nullptr,nullptr);
        value.pop_back(); text.push_back(std::move(value));
    }
    LocalFree(wide); std::vector<char*> args;
    for(auto& value:text) args.push_back(value.data());
    return neoMain(count,args.data());
#else
    return neoMain(argc,argv);
#endif
}
