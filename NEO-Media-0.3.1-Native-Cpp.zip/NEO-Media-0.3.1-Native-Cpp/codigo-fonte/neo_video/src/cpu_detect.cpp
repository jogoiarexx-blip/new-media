#include "cpu_detect.hpp"
#include <thread>
#include <sstream>
#if defined(_MSC_VER)
#include <intrin.h>
#elif defined(__GNUC__) || defined(__clang__)
#include <cpuid.h>
#endif
std::string CpuCaps::summary() const {
    std::ostringstream s; s << logicalCores << "T";
    if (avx512f) s << " AVX512"; else if (avx2) s << " AVX2"; else if (avx) s << " AVX"; else if (sse42) s << " SSE4.2";
    return s.str();
}
CpuCaps detectCpuCaps() {
    CpuCaps c; c.logicalCores = std::max(1u, std::thread::hardware_concurrency());
#if defined(__GNUC__) || defined(__clang__)
#if defined(__x86_64__) || defined(__i386__)
    __builtin_cpu_init(); c.sse42=__builtin_cpu_supports("sse4.2"); c.avx=__builtin_cpu_supports("avx"); c.avx2=__builtin_cpu_supports("avx2"); c.avx512f=__builtin_cpu_supports("avx512f");
#endif
#elif defined(_MSC_VER) && (defined(_M_X64) || defined(_M_IX86))
    int r[4]{}; __cpuid(r,1); c.sse42=(r[2]&(1<<20))!=0; c.avx=(r[2]&(1<<28))!=0; __cpuidex(r,7,0); c.avx2=(r[1]&(1<<5))!=0; c.avx512f=(r[1]&(1<<16))!=0;
#endif
    return c;
}
